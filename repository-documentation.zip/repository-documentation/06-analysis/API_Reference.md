# API Reference

Declared routes are not proof of runtime payloads or access policy. Supporting examples are labelled explicitly.

## GET /api/health

Scope: Application.
Declared handler: create_app.health.
Evidence: EV-A61F2683D120

## GET /api/session

Scope: Application.
Declared handler: create_app.session_info.
Evidence: EV-FB9C3E876DFB

## POST /api/auth/pat

Scope: Application.
Declared handler: create_app.authenticate.
Evidence: EV-9D981D475B51

## POST /api/auth/logout

Scope: Application.
Declared handler: create_app.logout.
Evidence: EV-524A8084553C

## GET /api/auth/github/start

Scope: Application.
Declared handler: create_app.oauth_start.
Evidence: EV-9985B4B42280

## GET /api/auth/github/callback

Scope: Application.
Declared handler: create_app.oauth_callback.
Evidence: EV-0F6D0CA3CB32

## GET /api/repositories

Scope: Application.
Declared handler: create_app.repositories.
Evidence: EV-0A6F8BF3F634

## GET /api/repositories/{owner}/{name}

Scope: Application.
Declared handler: create_app.repository.
Evidence: EV-F7EB788309AD

## GET /api/repositories/{owner}/{name}/refs

Scope: Application.
Declared handler: create_app.refs.
Evidence: EV-A508170852F2

## POST /api/jobs

Scope: Application.
Declared handler: create_app.create_job.
Evidence: EV-68E83656D9AD

## POST /api/demo

Scope: Application.
Declared handler: create_app.demo.
Evidence: EV-81EB1AC9D3D7

## GET /api/jobs

Scope: Application.
Declared handler: create_app.list_jobs.
Evidence: EV-F2F3489C415F

## GET /api/jobs/{job_id}

Scope: Application.
Declared handler: create_app.get_job.
Evidence: EV-02DA59BFE2D0

## GET /api/jobs/{job_id}/collaborators

Scope: Application.
Declared handler: create_app.collaborators.
Evidence: EV-073F25C4C4FE

## POST /api/jobs/{job_id}/collaborators

Scope: Application.
Declared handler: create_app.grant_access.
Evidence: EV-0888B6E61750

## DELETE /api/jobs/{job_id}/collaborators/{login}

Scope: Application.
Declared handler: create_app.revoke_access.
Evidence: EV-C658AB9DFEAA

## GET /api/jobs/{job_id}/files

Scope: Application.
Declared handler: create_app.files.
Evidence: EV-5AC2398A5FEA

## GET /api/jobs/{job_id}/download

Scope: Application.
Declared handler: create_app.download.
Evidence: EV-22435B0ED175

## GET /api/jobs/{job_id}/preview

Scope: Application.
Declared handler: create_app.preview.
Evidence: EV-6ADED5183BF6

## GET /api/jobs/{job_id}/audit

Scope: Application.
Declared handler: create_app.audit.
Evidence: EV-46966887DC4B

## POST /api/jobs/{job_id}/reviews

Scope: Application.
Declared handler: create_app.review.
Evidence: EV-4DB69A451714

## POST /api/jobs/{job_id}/results

Scope: Application.
Declared handler: create_app.record_result.
Evidence: EV-7C38FD977886

## PATCH /api/jobs/{job_id}/requirements/{requirement_id}

Scope: Application.
Declared handler: create_app.edit_requirement.
Evidence: EV-8CB4A0A92FAA

## GET /

Scope: Application.
Declared handler: create_app.missing_frontend.
Evidence: EV-F141AC0E43FB

## GET /products

Scope: Supporting example or test.
Declared handler: list_products.
Evidence: EV-AC8AD8AB1C7C

## POST /reservations

Scope: Supporting example or test.
Declared handler: reserve_product.
Evidence: EV-2BE0E4A409EE
