# Implementation Reference

This appendix retains extracted declarations and conditions. These are implementation findings rather than approved application requirements.

## Dockerfile

Deployment configuration exists; deployment execution and environment are not verified.

Evidence: EV-450BC26B67F9

## FROM node:22-bookworm-slim AS frontend

Container declaration: FROM node:22-bookworm-slim AS frontend

Evidence: EV-69A4406A8ED6

## FROM python:3.12-slim-bookworm

Container declaration: FROM python:3.12-slim-bookworm

Evidence: EV-0A93A1326E99

## EXPOSE 8000

Container declaration: EXPOSE 8000

Evidence: EV-9562CF5CC04D

## CMD ["docagent", "serve", "--host", "0.0.0.0", "--port", "8000"]

Container declaration: CMD ["docagent", "serve", "--host", "0.0.0.0", "--port", "8000"]

Evidence: EV-ABAA0BA7A591

## Docker

Container build configuration exists.

Evidence: EV-9178BCF86255

## Repository stated purpose

# Folio Repository Documentation Agent

Folio is a Python and React application for turning a GitHub repository into a versioned, evidence-linked documentation package. It includes a working local demo, static analysis, optional AI synthesis, document exports and authenticated review workflows.

The repository is an initial implementation, not a certification of production readiness. The local workflow and automated checks are runnable without credentials. Live GitHub OAuth/private-repository access, provider calls and the Docker execution worker require deployment-specific validation before production rollout. See [implementation coverage](docs/coverage.md) for precise scope and limits.

## Run locally

Requires Python 3.12+ and Node.js 22+. Run from the project root.

Create the local configuration separately, once, if `.env` does not already exist:

```powershell
Copy-Item .env.example .env
```

Install the Python dependencies so the key-generation command is available:

```powershell
python -m pip install uv==0.9.18
python -m uv sync --frozen --extra dev
```

To generate an encryption key, run this command from the project root:

```powershell
./.venv/Scripts/python.exe -m doca

Evidence: EV-31B5FA99AB3E

## compose.yaml

Deployment configuration exists; deployment execution and environment are not verified.

Evidence: EV-3FAC64468601

## fastapi

HTTP API framework. Declared version or constraint: <1,>=0.115.

Evidence: EV-19F4DF50DEA1

## uvicorn

Declared dependency; usage requires module inspection. Declared version or constraint: <1,>=0.30.

Evidence: EV-22EE7E3301B2

## httpx

Declared dependency; usage requires module inspection. Declared version or constraint: <1,>=0.28.

Evidence: EV-DFB8375B7A1E

## pydantic

Declared dependency; usage requires module inspection. Declared version or constraint: <3,>=2.10.

Evidence: EV-59988F1BCE3B

## pydantic-settings

Declared dependency; usage requires module inspection. Declared version or constraint: <3,>=2.7.

Evidence: EV-6E96431C13B6

## sqlalchemy

SQL persistence toolkit. Declared version or constraint: <3,>=2.0.

Evidence: EV-4EB767FEF33F

## alembic

Declared dependency; usage requires module inspection. Declared version or constraint: <2,>=1.14.

Evidence: EV-62D8E5256CC6

## cryptography

Cryptographic primitives. Declared version or constraint: >=44.

Evidence: EV-1ADA686320F6

## python-docx

Declared dependency; usage requires module inspection. Declared version or constraint: <2,>=1.1.

Evidence: EV-5877419F81BC

## openpyxl

Declared dependency; usage requires module inspection. Declared version or constraint: <4,>=3.1.

Evidence: EV-B5612D1A5493

## reportlab

Declared dependency; usage requires module inspection. Declared version or constraint: <5,>=4.2.

Evidence: EV-E6CAD2809C74

## defusedxml

Declared dependency; usage requires module inspection. Declared version or constraint: <1,>=0.7.

Evidence: EV-BAD0F5918860

## packaging

Declared dependency; usage requires module inspection. Declared version or constraint: >=24.

Evidence: EV-2BC5F5B9FE44

## celery

Distributed tasks. Declared version or constraint: <6,>=5.4.

Evidence: EV-1B2F4DDE47C6

## psycopg

PostgreSQL driver. Declared version or constraint: <4,>=3.2.

Evidence: EV-5BB5E7FD44ED

## fakeredis

Declared dependency; usage requires module inspection. Declared version or constraint: <3,>=2.31.

Evidence: EV-36B0EDF37190

## redis

Redis client. Declared version or constraint: <9,>=5.

Evidence: EV-04297BF62645

## boto3

AWS API client. Declared version or constraint: <2,>=1.36.

Evidence: EV-1AAED348A189

## openai

OpenAI API client. Declared version or constraint: <3,>=2.0.

Evidence: EV-C9D47E96814A

## anthropic

Claude API client. Declared version or constraint: <2,>=0.75.

Evidence: EV-521645C26A5F

## google-genai

Gemini API client. Declared version or constraint: <3,>=1.50.

Evidence: EV-ABA9ADDBE78F

## tree-sitter

Declared dependency; usage requires module inspection. Declared version or constraint: <0.26,>=0.25.

Evidence: EV-59011F20025A

## tree-sitter-javascript

Declared dependency; usage requires module inspection. Declared version or constraint: <0.26,>=0.25.

Evidence: EV-742D8E167553

## tree-sitter-typescript

Declared dependency; usage requires module inspection. Declared version or constraint: <0.24,>=0.23.

Evidence: EV-3A18201329F0

## tree-sitter-java

Declared dependency; usage requires module inspection. Declared version or constraint: <0.24,>=0.23.

Evidence: EV-D916BCB1F194

## tree-sitter-go

Declared dependency; usage requires module inspection. Declared version or constraint: <0.26,>=0.25.

Evidence: EV-2EFB621F6C03

## PyYAML

Declared dependency; usage requires module inspection. Declared version or constraint: <7,>=6.

Evidence: EV-A5250D9FE69F

## pathspec

Declared dependency; usage requires module inspection. Declared version or constraint: <1,>=0.12.

Evidence: EV-671E2B3C389C

## pytest

Python testing. Declared version or constraint: <10,>=8.

Evidence: EV-59713D11F0BB

## pytest-cov

Declared dependency; usage requires module inspection. Declared version or constraint: <8,>=6.

Evidence: EV-E6C96C77030A

## ruff

Declared dependency; usage requires module inspection. Declared version or constraint: <1,>=0.11.

Evidence: EV-1FE4AE352615

## moto

Declared dependency; usage requires module inspection. Declared version or constraint: <6,>=5.

Evidence: EV-92BD9924A8BB

## docagent

Console entry point: docagent.cli:main

Evidence: EV-035E419975AE

## .github/workflows/ci.yml

Deployment configuration exists; deployment execution and environment are not verified.

Evidence: EV-F0F6AEDA68FE

## GitHub Actions

GitHub Actions configuration detected.

Evidence: EV-B0C5E999374E

## stable_id

Function declaration. Parameters: prefix. Return annotation: unspecified. No function description is provided.

Evidence: EV-1FADB2F70213

## classify

Function declaration. Parameters: path. Return annotation: unspecified. No function description is provided.

Evidence: EV-9FFC4AFB4155

## Collector

Class bases: none. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-C04A67D6F50B

## python_analysis

Function declaration. Parameters: c. Return annotation: unspecified. No function description is provided.

Evidence: EV-7A43073D2385

## tree_analysis

Function declaration. Parameters: c, extension. Return annotation: unspecified. Syntax tree extraction for JavaScript, TypeScript, Java and Go.

Evidence: EV-5FBCE3C964D9

## dependencies

Function declaration. Parameters: c. Return annotation: unspecified. No function description is provided.

Evidence: EV-EAE6296D47AB

## analyze_file

Function declaration. Parameters: path, text. Return annotation: unspecified. No function description is provided.

Evidence: EV-F7E4213C6607

## scan_repository

Function declaration. Parameters: root, commit, depth, db, cache_scope, progress. Return annotation: unspecified. No function description is provided.

Evidence: EV-EAC2D60C701C

## candidate_requirements

Function declaration. Parameters: findings, evidence. Return annotation: unspecified. No function description is provided.

Evidence: EV-4D7AA989DA1C

## generate_tests

Function declaration. Parameters: requirements. Return annotation: unspecified. No function description is provided.

Evidence: EV-AEF32B8A12CD

## Condition in classify

Code evaluates: p.name.startswith('test_') or p.name.endswith(('_test.py', '.test.ts', '.test.tsx', '.test.js', '.test.jsx', '.spec.ts', '.spec.tsx', '.spec.js', '.spec.jsx', '_test.go')) or any((x in {'tests', 'test', '__tests__'} for x in p.parts)). Business intent and supported input boundaries require review.

Evidence: EV-95989256F2F4

## Condition in classify

Code evaluates: '.github/workflows' in path or p.name in {'Dockerfile', 'Jenkinsfile', 'docker-compose.yml', 'compose.yaml', 'compose.yml'} or p.suffix == '.tf' or ('k8s' in p.parts) or ('helm' in p.parts). Business intent and supported input boundaries require review.

Evidence: EV-3534357B6039

## Condition in classify

Code evaluates: p.suffix in LANGUAGES. Business intent and supported input boundaries require review.

Evidence: EV-E8071F3A39A9

## Condition in classify

Code evaluates: p.suffix == '.md' or p.name.lower() in {'readme', 'license', 'notice', 'changelog', 'contributing'}. Business intent and supported input boundaries require review.

Evidence: EV-22C65DAE48EC

## Collector.__init__

Function declaration. Parameters: self, path, text. Return annotation: unspecified. No function description is provided.

Evidence: EV-FA58F8568509

## Collector.add

Function declaration. Parameters: self, kind, title, detail, line, end, symbol, confidence, metadata. Return annotation: unspecified. No function description is provided.

Evidence: EV-F24A1A8A4852

## Collector.dependency

Function declaration. Parameters: self, name, version, line. Return annotation: unspecified. No function description is provided.

Evidence: EV-6A42A9D2717D

## Collector.payload

Function declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-AFA5729DCE0D

## python_analysis.qualified

Function declaration. Parameters: node. Return annotation: unspecified. No function description is provided.

Evidence: EV-03E8BF40CA5B

## Condition in analyze_file

Code evaluates: p.name.lower() in {'readme', 'readme.md', 'readme.txt', 'readme.rst'}. Business intent and supported input boundaries require review.

Evidence: EV-AD8BF756B3D5

## Condition in analyze_file

Code evaluates: p.suffix == '.py'. Business intent and supported input boundaries require review.

Evidence: EV-9AF43684EA44

## Condition in analyze_file

Code evaluates: classify(path) == 'deployment'. Business intent and supported input boundaries require review.

Evidence: EV-2EC7A0DA0FA6

## Condition in analyze_file

Code evaluates: p.suffix == '.sql'. Business intent and supported input boundaries require review.

Evidence: EV-841C7FB3042B

## Condition in analyze_file

Code evaluates: p.suffix in {'.yaml', '.yml', '.json', '.toml', '.tf'}. Business intent and supported input boundaries require review.

Evidence: EV-66E2B77AFDC6

## Condition in analyze_file

Code evaluates: p.name == 'Dockerfile'. Business intent and supported input boundaries require review.

Evidence: EV-044F46AE082B, EV-287D4A22E2ED

## Condition in scan_repository

Code evaluates: not any((f['kind'] == 'test' for f in findings)). Business intent and supported input boundaries require review.

Evidence: EV-E370306142E1

## Condition in Collector.add

Code evaluates: not any((e['id'] == eid for e in self.evidence)). Business intent and supported input boundaries require review.

Evidence: EV-3C3AE7012E2F

## Condition in Collector.add

Code evaluates: existing. Business intent and supported input boundaries require review.

Evidence: EV-36A5DB668F88

## Condition in python_analysis

Code evaluates: isinstance(node, ast.Import). Business intent and supported input boundaries require review.

Evidence: EV-FE11E6B8369A

## Condition in python_analysis

Code evaluates: enclosing. Business intent and supported input boundaries require review.

Evidence: EV-C4C921774305

## Condition in python_analysis

Code evaluates: classes. Business intent and supported input boundaries require review.

Evidence: EV-615961932F2F

## Condition in tree_analysis

Code evaluates: extension in {'.js', '.jsx'}. Business intent and supported input boundaries require review.

Evidence: EV-FC855AB9F2BA

## Condition in tree_analysis

Code evaluates: tree.root_node.has_error. Business intent and supported input boundaries require review.

Evidence: EV-6DAE9C8F03F2

## Condition in dependencies

Code evaluates: name == 'package.json'. Business intent and supported input boundaries require review.

Evidence: EV-25CDBDDB58F4

## Condition in analyze_file

Code evaluates: p.suffix in {'.js', '.jsx', '.ts', '.tsx', '.java', '.go'}. Business intent and supported input boundaries require review.

Evidence: EV-59B963896CD7

## Condition in scan_repository

Code evaluates: path.is_file() and (not path.is_symlink()) and (path.stat().st_size < 100000). Business intent and supported input boundaries require review.

Evidence: EV-1D7E8F858FFE

## Condition in candidate_requirements

Code evaluates: finding['kind'] not in relevant. Business intent and supported input boundaries require review.

Evidence: EV-F2011063A624

## Condition in candidate_requirements

Code evaluates: classify(path) == 'test'. Business intent and supported input boundaries require review.

Evidence: EV-FC884F20A3AB

## Condition in candidate_requirements

Code evaluates: not scope and finding['kind'] in {'function', 'data_model'}. Business intent and supported input boundaries require review.

Evidence: EV-FC175FBB8A33

## Condition in candidate_requirements

Code evaluates: metadata.get('class_scope') and (not is_route). Business intent and supported input boundaries require review.

Evidence: EV-FB349F01303A

## Condition in candidate_requirements

Code evaluates: scope and (not is_route) and any((part.startswith('_') for part in scope.split('.'))). Business intent and supported input boundaries require review.

Evidence: EV-C2094953969C

## Condition in Collector.add

Code evaluates: eid not in existing['evidence_ids']. Business intent and supported input boundaries require review.

Evidence: EV-CDEADC36519B

## Condition in python_analysis.qualified

Code evaluates: isinstance(parent, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)). Business intent and supported input boundaries require review.

Evidence: EV-D25BCF15CC00

## Condition in python_analysis

Code evaluates: isinstance(node, ast.ImportFrom). Business intent and supported input boundaries require review.

Evidence: EV-33E5C2A8E3AA

## Condition in tree_analysis

Code evaluates: extension in {'.ts', '.tsx'}. Business intent and supported input boundaries require review.

Evidence: EV-CEFD523D8DC4

## Condition in tree_analysis

Code evaluates: node.type in {'function_declaration', 'method_definition', 'method_declaration', 'function_definition', 'class_declaration', 'interface_declaration', 'type_declaration'}. Business intent and supported input boundaries require review.

Evidence: EV-E0EFD4FC9396

## Condition in dependencies

Code evaluates: name == 'pyproject.toml'. Business intent and supported input boundaries require review.

Evidence: EV-BB2364CD5443

## Condition in analyze_file

Code evaluates: p.suffix in LANGUAGES and p.suffix not in {'.sql', '.html', '.css'}. Business intent and supported input boundaries require review.

Evidence: EV-A3F00053F493

## Condition in analyze_file

Code evaluates: re.search(pattern, text) and (name != 'GitHub Actions' or '.github/workflows' in path). Business intent and supported input boundaries require review.

Evidence: EV-223126DEF438

## Condition in scan_repository

Code evaluates: file.is_symlink() or secret_path(relative) or spec.match_file(relative). Business intent and supported input boundaries require review.

Evidence: EV-8671247BAD13

## Condition in scan_repository

Code evaluates: file.suffix.lower() not in TEXT_EXTENSIONS and filename.lower() not in {'dockerfile', 'jenkinsfile', 'go.mod', 'gemfile', 'readme', 'license', 'notice', 'changelog', 'contributing', '.gitignore', '.dockerignore', 'makefile', 'procfile', '.editorconfig'}. Business intent and supported input boundaries require review.

Evidence: EV-1AF0DFF3DCA4

## Condition in scan_repository

Code evaluates: size > cfg.max_file_bytes. Business intent and supported input boundaries require review.

Evidence: EV-2B0C8408FCEC

## Condition in scan_repository

Code evaluates: scanned >= limit or total_bytes + size > byte_limit. Business intent and supported input boundaries require review.

Evidence: EV-43425315490D

## Condition in scan_repository

Code evaluates: b'\x00' in raw. Business intent and supported input boundaries require review.

Evidence: EV-F488E5758236

## Condition in scan_repository

Code evaluates: cached. Business intent and supported input boundaries require review.

Evidence: EV-4280C2873086

## Condition in scan_repository

Code evaluates: progress and scanned % 100 == 0. Business intent and supported input boundaries require review.

Evidence: EV-6E78E5211187

## Condition in candidate_requirements

Code evaluates: item is not anchor and item['kind'] != 'function' and (item['detail'] not in details). Business intent and supported input boundaries require review.

Evidence: EV-776B47B544F3

## Condition in python_analysis

Code evaluates: isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)). Business intent and supported input boundaries require review.

Evidence: EV-1CA436C8346B

## Condition in tree_analysis

Code evaluates: extension == '.java'. Business intent and supported input boundaries require review.

Evidence: EV-DAED1A146C96

## Condition in tree_analysis

Code evaluates: name. Business intent and supported input boundaries require review.

Evidence: EV-68588D1A958A

## Condition in dependencies

Code evaluates: name.startswith('requirements') and name.endswith('.txt'). Business intent and supported input boundaries require review.

Evidence: EV-9615AAD59743

## Condition in analyze_file

Code evaluates: re.match('(?i)^(FROM|EXPOSE|ENTRYPOINT|CMD)\\s', line). Business intent and supported input boundaries require review.

Evidence: EV-2D9DF888A697

## Condition in scan_repository

Code evaluates: db is not None. Business intent and supported input boundaries require review.

Evidence: EV-991C7D3B4678

## Condition in python_analysis

Code evaluates: isinstance(node, ast.ClassDef). Business intent and supported input boundaries require review.

Evidence: EV-D5EC9F4BDFA3

## Condition in tree_analysis

Code evaluates: classify(c.path) == 'test'. Business intent and supported input boundaries require review.

Evidence: EV-3A8E3C690096

## Condition in dependencies

Code evaluates: name == 'cargo.toml'. Business intent and supported input boundaries require review.

Evidence: EV-479C191B3F3B

## Condition in python_analysis

Code evaluates: isinstance(deco, ast.Call) and isinstance(deco.func, ast.Attribute). Business intent and supported input boundaries require review.

Evidence: EV-51D29A2CC1A5

## Condition in python_analysis

Code evaluates: isinstance(node, (ast.If, ast.Assert)) and classify(c.path) != 'test'. Business intent and supported input boundaries require review.

Evidence: EV-EAC42E96EEA8

## Condition in dependencies

Code evaluates: name == 'go.mod'. Business intent and supported input boundaries require review.

Evidence: EV-E45319DDBCCA

## Condition in python_analysis

Code evaluates: method in {'get', 'post', 'put', 'patch', 'delete', 'options', 'head', 'route', 'websocket'} and deco.args and isinstance(deco.args[0], ast.Constant) and isinstance(deco.args[0].value, str). Business intent and supported input boundaries require review.

Evidence: EV-73CE8BFF6C45

## Condition in python_analysis

Code evaluates: owner. Business intent and supported input boundaries require review.

Evidence: EV-D9790A4496C1

## Condition in python_analysis

Code evaluates: isinstance(node, ast.Call). Business intent and supported input boundaries require review.

Evidence: EV-FCB77EDC4B49

## Condition in dependencies

Code evaluates: name == 'pom.xml'. Business intent and supported input boundaries require review.

Evidence: EV-3B8BAC62A01F

## Condition in python_analysis

Code evaluates: method == 'route'. Business intent and supported input boundaries require review.

Evidence: EV-00A4DC732935

## Condition in python_analysis

Code evaluates: name.split('.')[-1] in {'Depends', 'Security'} and node.args. Business intent and supported input boundaries require review.

Evidence: EV-E185F91A0773

## Condition in python_analysis

Code evaluates: name.split('.')[-1] in {'Field', 'Column', 'mapped_column', 'relationship', 'ForeignKey'}. Business intent and supported input boundaries require review.

Evidence: EV-F6E8EF69BA3C

## Condition in python_analysis

Code evaluates: isinstance(node.func, ast.Attribute) and node.func.attr in {'execute', 'query', 'commit', 'flush', 'save', 'insert_one', 'find_one', 'bulk_write'}. Business intent and supported input boundaries require review.

Evidence: EV-FAAD80868B11

## Condition in python_analysis

Code evaluates: any((word in name.lower() for word in ('authenticate', 'authorize', 'require_user', 'require_role', 'hashpw', 'jwt.decode', 'verify_password'))). Business intent and supported input boundaries require review.

Evidence: EV-C4AD50B1CA41

## Condition in python_analysis

Code evaluates: re.search('(?:requests|httpx|client|session)\\.(get|post|put|delete|patch|request)$', name) and node.args. Business intent and supported input boundaries require review.

Evidence: EV-D8F483B6D29F

## Condition in dependencies

Code evaluates: m. Business intent and supported input boundaries require review.

Evidence: EV-CC9E1536880F

## Condition in python_analysis

Code evaluates: isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str) and node.args[0].value.startswith('https://'). Business intent and supported input boundaries require review.

Evidence: EV-C6570A454D37

## Condition in dependencies

Code evaluates: artifact. Business intent and supported input boundaries require review.

Evidence: EV-2BF1FE1640C2

## Condition in python_analysis

Code evaluates: kw.arg == 'methods' and isinstance(kw.value, (ast.List, ast.Tuple)). Business intent and supported input boundaries require review.

Evidence: EV-5D6A3BDA7EA1

## lifespan

Function declaration. Parameters: app. Return annotation: unspecified. No function description is provided.

Evidence: EV-D22453B5F87D

## get_db

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-DA1F96D99C74

## user_session

Function declaration. Parameters: request, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-D5769066A95B

## owner_job

Function declaration. Parameters: db, user, job_id, lock. Return annotation: unspecified. No function description is provided.

Evidence: EV-EC94F9E62B6E

## require_complete

Function declaration. Parameters: job. Return annotation: unspecified. No function description is provided.

Evidence: EV-883962E5F64D

## can_review

Function declaration. Parameters: user, db, job. Return annotation: unspecified. No function description is provided.

Evidence: EV-3822461701CE

## require_reviewer

Function declaration. Parameters: user, db, job. Return annotation: unspecified. No function description is provided.

Evidence: EV-82A20ADC73B2

## set_cookie

Function declaration. Parameters: response, token. Return annotation: unspecified. No function description is provided.

Evidence: EV-86EE08D58D5C

## create_session

Function declaration. Parameters: db, response. Return annotation: unspecified. No function description is provided.

Evidence: EV-A484F47246DC

## connect_user

Function declaration. Parameters: db, session, token, identity, response. Return annotation: unspecified. No function description is provided.

Evidence: EV-4CE5D4B06B5D

## job_view

Function declaration. Parameters: db, job, full, user. Return annotation: unspecified. No function description is provided.

Evidence: EV-C459A6FB8876

## PATInput

Class bases: StrictModel. Annotated fields: token. Persistence cannot be concluded from class naming alone.

Evidence: EV-7246DA27B3B2

## create_app

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-ED4A8475DF1E

## Condition in lifespan

Code evaluates: settings().env == 'production'. Business intent and supported input boundaries require review.

Evidence: EV-AD122B118A4A

## Condition in lifespan

Code evaluates: settings().job_backend == 'local'. Business intent and supported input boundaries require review.

Evidence: EV-5DFDC6E8196F

## Condition in lifespan

Code evaluates: local. Business intent and supported input boundaries require review.

Evidence: EV-BFC3BABEC92D, EV-BD55FDEB031D

## Condition in user_session

Code evaluates: session is None or session.expires < now(). Business intent and supported input boundaries require review.

Evidence: EV-34C7300F59A0

## Condition in user_session

Code evaluates: request.method not in {'GET', 'HEAD', 'OPTIONS'}. Business intent and supported input boundaries require review.

Evidence: EV-1D78914EB6EF

## Condition in owner_job

Code evaluates: lock. Business intent and supported input boundaries require review.

Evidence: EV-A16F720E461E

## Condition in owner_job

Code evaluates: job is None. Business intent and supported input boundaries require review.

Evidence: EV-1373931991FE

## Condition in require_complete

Code evaluates: job.status != 'completed'. Business intent and supported input boundaries require review.

Evidence: EV-F840BF5C1046

## Condition in can_review

Code evaluates: not user.login or user.login.casefold() not in names. Business intent and supported input boundaries require review.

Evidence: EV-8E73D0B71C3D

## Condition in require_reviewer

Code evaluates: not can_review(user, db, job). Business intent and supported input boundaries require review.

Evidence: EV-3100548286D9

## Condition in connect_user

Code evaluates: session.owner.startswith('anonymous:'). Business intent and supported input boundaries require review.

Evidence: EV-E94863AAAC86

## Condition in job_view

Code evaluates: full. Business intent and supported input boundaries require review.

Evidence: EV-B2F1DFA1368D

## create_app.security_headers

Function declaration. Parameters: request, call_next. Return annotation: unspecified. No function description is provided.

Evidence: EV-CEE60806FE0A

## create_app.validation_error

Function declaration. Parameters: request, exc. Return annotation: unspecified. No function description is provided.

Evidence: EV-C931D4B17A06

## create_app.github_error

Function declaration. Parameters: request, exc. Return annotation: unspecified. No function description is provided.

Evidence: EV-74B43C9C8489

## create_app.storage_error

Function declaration. Parameters: request, exc. Return annotation: unspecified. No function description is provided.

Evidence: EV-CAE937DE3809

## create_app.invalid_artifact_path

Function declaration. Parameters: request, exc. Return annotation: unspecified. No function description is provided.

Evidence: EV-AF4A575C030D

## create_app.health

Function declaration. Parameters: db. Return annotation: unspecified. No function description is provided.

Evidence: EV-D934B6CC2F8B

## GET /api/health

Decorator declares GET /api/health, handled by create_app.health. Router mount prefixes and runtime middleware require verification.

Evidence: EV-A61F2683D120

## create_app.session_info

Function declaration. Parameters: request, response, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-AA8C4F518310

## GET /api/session

Decorator declares GET /api/session, handled by create_app.session_info. Router mount prefixes and runtime middleware require verification.

Evidence: EV-FB9C3E876DFB

## create_app.authenticate

Function declaration. Parameters: data, user, db, response. Return annotation: unspecified. No function description is provided.

Evidence: EV-02A3FFE410DB

## POST /api/auth/pat

Decorator declares POST /api/auth/pat, handled by create_app.authenticate. Router mount prefixes and runtime middleware require verification.

Evidence: EV-9D981D475B51

## create_app.logout

Function declaration. Parameters: user, db, response. Return annotation: unspecified. No function description is provided.

Evidence: EV-5E76C8CA69AC

## POST /api/auth/logout

Decorator declares POST /api/auth/logout, handled by create_app.logout. Router mount prefixes and runtime middleware require verification.

Evidence: EV-524A8084553C

## create_app.oauth_start

Function declaration. Parameters: user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-C79DEC7861D5

## GET /api/auth/github/start

Decorator declares GET /api/auth/github/start, handled by create_app.oauth_start. Router mount prefixes and runtime middleware require verification.

Evidence: EV-9985B4B42280

## create_app.oauth_callback

Function declaration. Parameters: code, state, user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-FD52A6490417

## GET /api/auth/github/callback

Decorator declares GET /api/auth/github/callback, handled by create_app.oauth_callback. Router mount prefixes and runtime middleware require verification.

Evidence: EV-0F6D0CA3CB32

## create_app.repositories

Function declaration. Parameters: user, page. Return annotation: unspecified. No function description is provided.

Evidence: EV-D1D6DBED4E8E

## GET /api/repositories

Decorator declares GET /api/repositories, handled by create_app.repositories. Router mount prefixes and runtime middleware require verification.

Evidence: EV-0A6F8BF3F634

## create_app.repository

Function declaration. Parameters: owner, name, user. Return annotation: unspecified. No function description is provided.

Evidence: EV-EDF5F7A9C5A2

## GET /api/repositories/{owner}/{name}

Decorator declares GET /api/repositories/{owner}/{name}, handled by create_app.repository. Router mount prefixes and runtime middleware require verification.

Evidence: EV-F7EB788309AD

## create_app.refs

Function declaration. Parameters: owner, name, user, kind, page. Return annotation: unspecified. No function description is provided.

Evidence: EV-8DACC9A157BE

## GET /api/repositories/{owner}/{name}/refs

Decorator declares GET /api/repositories/{owner}/{name}/refs, handled by create_app.refs. Router mount prefixes and runtime middleware require verification.

Evidence: EV-A508170852F2

## create_app.start_job

Function declaration. Parameters: config, user, db, demo. Return annotation: unspecified. No function description is provided.

Evidence: EV-6642A081F458

## create_app.create_job

Function declaration. Parameters: config, user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-4B8493C1F5AD

## POST /api/jobs

Decorator declares POST /api/jobs, handled by create_app.create_job. Router mount prefixes and runtime middleware require verification.

Evidence: EV-68E83656D9AD

## create_app.demo

Function declaration. Parameters: user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-02537AB1105D

## POST /api/demo

Decorator declares POST /api/demo, handled by create_app.demo. Router mount prefixes and runtime middleware require verification.

Evidence: EV-81EB1AC9D3D7

## create_app.list_jobs

Function declaration. Parameters: user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-AFECD7C7FFB1

## GET /api/jobs

Decorator declares GET /api/jobs, handled by create_app.list_jobs. Router mount prefixes and runtime middleware require verification.

Evidence: EV-F2F3489C415F

## create_app.get_job

Function declaration. Parameters: job_id, user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-F5EA31350D81

## GET /api/jobs/{job_id}

Decorator declares GET /api/jobs/{job_id}, handled by create_app.get_job. Router mount prefixes and runtime middleware require verification.

Evidence: EV-02DA59BFE2D0

## create_app.collaborators

Function declaration. Parameters: job_id, user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-47B621ADFC28

## GET /api/jobs/{job_id}/collaborators

Decorator declares GET /api/jobs/{job_id}/collaborators, handled by create_app.collaborators. Router mount prefixes and runtime middleware require verification.

Evidence: EV-073F25C4C4FE

## create_app.grant_access

Function declaration. Parameters: job_id, data, user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-C61F024FD0EF

## POST /api/jobs/{job_id}/collaborators

Decorator declares POST /api/jobs/{job_id}/collaborators, handled by create_app.grant_access. Router mount prefixes and runtime middleware require verification.

Evidence: EV-0888B6E61750

## create_app.revoke_access

Function declaration. Parameters: job_id, login, user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-9A1D2988354A

## DELETE /api/jobs/{job_id}/collaborators/{login}

Decorator declares DELETE /api/jobs/{job_id}/collaborators/{login}, handled by create_app.revoke_access. Router mount prefixes and runtime middleware require verification.

Evidence: EV-C658AB9DFEAA

## create_app.files

Function declaration. Parameters: job_id, user, db, version. Return annotation: unspecified. No function description is provided.

Evidence: EV-07B4ADE29F9E

## GET /api/jobs/{job_id}/files

Decorator declares GET /api/jobs/{job_id}/files, handled by create_app.files. Router mount prefixes and runtime middleware require verification.

Evidence: EV-5AC2398A5FEA

## create_app.download

Function declaration. Parameters: job_id, user, db, path, version. Return annotation: unspecified. No function description is provided.

Evidence: EV-DF04D13D1BD6

## GET /api/jobs/{job_id}/download

Decorator declares GET /api/jobs/{job_id}/download, handled by create_app.download. Router mount prefixes and runtime middleware require verification.

Evidence: EV-22435B0ED175

## create_app.preview

Function declaration. Parameters: job_id, path, user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-7B07CB44AD66

## GET /api/jobs/{job_id}/preview

Decorator declares GET /api/jobs/{job_id}/preview, handled by create_app.preview. Router mount prefixes and runtime middleware require verification.

Evidence: EV-6ADED5183BF6

## create_app.audit

Function declaration. Parameters: job_id, user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-CBFD6BB7D2D3

## GET /api/jobs/{job_id}/audit

Decorator declares GET /api/jobs/{job_id}/audit, handled by create_app.audit. Router mount prefixes and runtime middleware require verification.

Evidence: EV-46966887DC4B

## create_app.review

Function declaration. Parameters: job_id, data, user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-78DE396A252D

## POST /api/jobs/{job_id}/reviews

Decorator declares POST /api/jobs/{job_id}/reviews, handled by create_app.review. Router mount prefixes and runtime middleware require verification.

Evidence: EV-4DB69A451714

## create_app.record_result

Function declaration. Parameters: job_id, data, user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-CBFE467043A9

## POST /api/jobs/{job_id}/results

Decorator declares POST /api/jobs/{job_id}/results, handled by create_app.record_result. Router mount prefixes and runtime middleware require verification.

Evidence: EV-7C38FD977886

## create_app.edit_requirement

Function declaration. Parameters: job_id, requirement_id, data, user, db. Return annotation: unspecified. No function description is provided.

Evidence: EV-2DAB44E37092

## PATCH /api/jobs/{job_id}/requirements/{requirement_id}

Decorator declares PATCH /api/jobs/{job_id}/requirements/{requirement_id}, handled by create_app.edit_requirement. Router mount prefixes and runtime middleware require verification.

Evidence: EV-8CB4A0A92FAA

## Condition in create_app

Code evaluates: cfg.frontend_dir.is_dir(). Business intent and supported input boundaries require review.

Evidence: EV-32F177851483

## Condition in user_session

Code evaluates: not secrets.compare_digest(csrf, session.csrf). Business intent and supported input boundaries require review.

Evidence: EV-64977BD4D273

## Condition in user_session

Code evaluates: origin and origin.rstrip('/') != settings().public_url.rstrip('/'). Business intent and supported input boundaries require review.

Evidence: EV-1694F0736C9F

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-9E15D2B75F76

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-FDD65DF48871

## Condition in job_view

Code evaluates: user. Business intent and supported input boundaries require review.

Evidence: EV-CDBA75164FD0

## Field

Schema or validation declaration: Field(min_length=10, max_length=300)

Evidence: EV-376E3B9BA4BD

## Condition in create_app.security_headers

Code evaluates: request.method in {'POST', 'PUT', 'PATCH'}. Business intent and supported input boundaries require review.

Evidence: EV-4625BB116C01

## Condition in create_app.security_headers

Code evaluates: request.url.path in {'/docs', '/redoc'}. Business intent and supported input boundaries require review.

Evidence: EV-DDAA86921ACB

## Condition in create_app.security_headers

Code evaluates: cfg.env == 'production'. Business intent and supported input boundaries require review.

Evidence: EV-D6FD6D43E5C2

## Condition in create_app.storage_error

Code evaluates: isinstance(exc, ArtifactNotFound). Business intent and supported input boundaries require review.

Evidence: EV-E79EDA750A91

## Condition in create_app.session_info

Code evaluates: user is None or user.expires < now(). Business intent and supported input boundaries require review.

Evidence: EV-AFD32C317396

## Condition in create_app.oauth_start

Code evaluates: not cfg.github_client_id. Business intent and supported input boundaries require review.

Evidence: EV-2AFFB1388A4E

## Condition in create_app.oauth_callback

Code evaluates: not user.oauth_state or not secrets.compare_digest(state, user.oauth_state) or (not user.oauth_started) or (now() - user.oauth_started > timedelta(minutes=10)). Business intent and supported input boundaries require review.

Evidence: EV-E90FB0D1866E

## Condition in create_app.repositories

Code evaluates: not user.token. Business intent and supported input boundaries require review.

Evidence: EV-5C7869A1A4B9

## Condition in create_app.start_job

Code evaluates: config.repository == 'demo/inventory' and (not demo). Business intent and supported input boundaries require review.

Evidence: EV-A82897F5D34C

## Condition in create_app.start_job

Code evaluates: config.execute_tests and (not cfg.test_execution_enabled). Business intent and supported input boundaries require review.

Evidence: EV-2C30728D6F6C

## Condition in create_app.start_job

Code evaluates: not demo. Business intent and supported input boundaries require review.

Evidence: EV-6882C4D601E9

## Condition in create_app.start_job

Code evaluates: admission.rowcount != 1. Business intent and supported input boundaries require review.

Evidence: EV-E7D2AF1A350D

## Condition in create_app.start_job

Code evaluates: active >= 16 or owned >= cfg.max_concurrent_jobs. Business intent and supported input boundaries require review.

Evidence: EV-CA0E095112EE

## Condition in create_app.collaborators

Code evaluates: job.owner != user.owner. Business intent and supported input boundaries require review.

Evidence: EV-0CF2D24E9496

## Condition in create_app.grant_access

Code evaluates: job.owner != user.owner or not user.login. Business intent and supported input boundaries require review.

Evidence: EV-2D7FD192E2D3

## Condition in create_app.grant_access

Code evaluates: not data.acknowledged. Business intent and supported input boundaries require review.

Evidence: EV-A1CA528D58E2

## Condition in create_app.grant_access

Code evaluates: grant is None. Business intent and supported input boundaries require review.

Evidence: EV-C271A5E850CD

## Condition in create_app.revoke_access

Code evaluates: job.owner != user.owner. Business intent and supported input boundaries require review.

Evidence: EV-DC975731A3F0

## Condition in create_app.revoke_access

Code evaluates: row. Business intent and supported input boundaries require review.

Evidence: EV-F4A36C21FDD3

## Condition in create_app.files

Code evaluates: db.get(DocumentVersion, (job.id, version)) is None. Business intent and supported input boundaries require review.

Evidence: EV-A507A9809E1D

## Condition in create_app.files

Code evaluates: version > job.version. Business intent and supported input boundaries require review.

Evidence: EV-3DB615C9FF85

## Condition in create_app.download

Code evaluates: db.get(DocumentVersion, (job.id, version)) is None. Business intent and supported input boundaries require review.

Evidence: EV-49C57FF9016E

## Condition in create_app.download

Code evaluates: version > job.version. Business intent and supported input boundaries require review.

Evidence: EV-CEC685CEDDD9

## Condition in create_app.preview

Code evaluates: db.get(DocumentVersion, (job.id, job.version)) is None. Business intent and supported input boundaries require review.

Evidence: EV-992E948B6E67

## Condition in create_app.preview

Code evaluates: not path.endswith('.md'). Business intent and supported input boundaries require review.

Evidence: EV-7F48D429F4EA

## Condition in create_app.review

Code evaluates: data.baseline_hash != expected_hash. Business intent and supported input boundaries require review.

Evidence: EV-892E02E08DFC

## Condition in create_app.review

Code evaluates: data.decision == 'approved' and (not data.acknowledged). Business intent and supported input boundaries require review.

Evidence: EV-5E72E0C403CB

## Condition in create_app.review

Code evaluates: data.stage == 'requirements' and data.decision == 'approved' and (not job.analysis['requirements']). Business intent and supported input boundaries require review.

Evidence: EV-25B826F4748E

## Condition in create_app.review

Code evaluates: data.stage == 'uat' and data.decision == 'approved' and (not state['ready_for_acceptance']). Business intent and supported input boundaries require review.

Evidence: EV-91071281693A

## Condition in create_app.record_result

Code evaluates: not data.attested. Business intent and supported input boundaries require review.

Evidence: EV-0908E386217B

## Condition in create_app.record_result

Code evaluates: data.baseline_hash != job.baseline_hash. Business intent and supported input boundaries require review.

Evidence: EV-E0C8D653F9F1

## Condition in create_app.record_result

Code evaluates: not any((t['id'] == data.test_case_id for t in job.analysis['test_cases'])). Business intent and supported input boundaries require review.

Evidence: EV-30720496EA8A

## Condition in create_app.record_result

Code evaluates: data.status == 'passed' and data.severity != 'none'. Business intent and supported input boundaries require review.

Evidence: EV-49E95EAA88A5

## Condition in create_app.edit_requirement

Code evaluates: data.baseline_hash != job.baseline_hash. Business intent and supported input boundaries require review.

Evidence: EV-A7E9E35E49CB

## Condition in create_app.edit_requirement

Code evaluates: requirement is None. Business intent and supported input boundaries require review.

Evidence: EV-6F53F986988E

## create_app.missing_frontend

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-30B711749481

## GET /

Decorator declares GET /, handled by create_app.missing_frontend. Router mount prefixes and runtime middleware require verification.

Evidence: EV-F141AC0E43FB

## Dependency get_db

Dependency injection references get_db. Review this dependency to establish authentication and permissions.

Evidence: EV-5DC191F2CE31

## Dependency user_session

Dependency injection references user_session. Review this dependency to establish authentication and permissions.

Evidence: EV-3ABE0B20F41E

## Condition in create_app.security_headers

Code evaluates: request.headers.get('content-type', '').split(';')[0] != 'application/json'. Business intent and supported input boundaries require review.

Evidence: EV-6F847F35DE83

## db.execute

Call to db.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-742B01FCB4B8

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-EA6FDB14592E

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-3F7F05F84380

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-8E62418C5A43

## Condition in create_app.oauth_callback

Code evaluates: not token. Business intent and supported input boundaries require review.

Evidence: EV-9065A7DB7566

## Condition in create_app.start_job

Code evaluates: metadata['private'] and any((p.provider not in config.consent_providers for p in config.providers)). Business intent and supported input boundaries require review.

Evidence: EV-8CF963BDF1AC

## db.execute

Call to db.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-A4AC724A262A

## db.flush

Call to db.flush may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-04185E4753E3

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-B84C9DFB9ADA

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-C260A1D28061

## db.flush

Call to db.flush may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-3ADB8A9FC5BD

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-C7257497C655

## db.flush

Call to db.flush may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-96D84FF8128D

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-7A46E28394F5

## db.flush

Call to db.flush may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-1F2126D408DB

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-AE2D67423C32

## db.execute

Call to db.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-84D05C3B28B4

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-099672642A7B

## Condition in create_app.security_headers

Code evaluates: len(body) > 128000. Business intent and supported input boundaries require review.

Evidence: EV-D6F2B5F69486

## HTTPS call to github.com

httpx.post is called with an HTTPS URL on github.com.

Evidence: EV-2139B2CCD5E2

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-A729D13EED26

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-3B1F48CE020E

## CheckFailure

Class bases: Exception. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-A98AB5FAAF12

## postgres_check

Function declaration. Parameters: cfg. Return annotation: unspecified. No function description is provided.

Evidence: EV-84F979603F69

## redis_check

Function declaration. Parameters: cfg, write_probe. Return annotation: unspecified. No function description is provided.

Evidence: EV-B95194AEE50F

## storage_check

Function declaration. Parameters: cfg, write_probe. Return annotation: unspecified. No function description is provided.

Evidence: EV-EE2B70391D68

## encryption_check

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-5FACC9A789BF

## api_check

Function declaration. Parameters: cfg, api_url, timeout, package_output. Return annotation: unspecified. No function description is provided.

Evidence: EV-F349E888BBF1

## run_checks

Function declaration. Parameters: write_probe, api_url, timeout, output. Return annotation: unspecified. No function description is provided.

Evidence: EV-66E2AEA66784

## Condition in postgres_check

Code evaluates: not cfg.database_url.startswith('postgresql'). Business intent and supported input boundaries require review.

Evidence: EV-51D646C892A4

## Condition in redis_check

Code evaluates: cfg.redis_backend != 'real'. Business intent and supported input boundaries require review.

Evidence: EV-0BE7D70CC2BB

## Condition in storage_check

Code evaluates: cfg.storage_backend != 's3'. Business intent and supported input boundaries require review.

Evidence: EV-FDFB8A4CCC3C

## Condition in encryption_check

Code evaluates: decrypt(encrypt(probe)) != probe. Business intent and supported input boundaries require review.

Evidence: EV-0C59764208DD

## run_checks.run

Function declaration. Parameters: name, action. Return annotation: unspecified. No function description is provided.

Evidence: EV-D2A035362599

## Condition in run_checks

Code evaluates: api_url. Business intent and supported input boundaries require review.

Evidence: EV-A456ABE4FA3F

## Condition in redis_check

Code evaluates: not client.ping(). Business intent and supported input boundaries require review.

Evidence: EV-2428FCE64696

## Condition in redis_check

Code evaluates: write_probe. Business intent and supported input boundaries require review.

Evidence: EV-E4418F2F0182

## Condition in storage_check

Code evaluates: not write_probe. Business intent and supported input boundaries require review.

Evidence: EV-FD1E2CF6717A

## Condition in storage_check

Code evaluates: storage.version_exists(probe_id, 1). Business intent and supported input boundaries require review.

Evidence: EV-DAF3EF97EA5C

## api_check.request

Function declaration. Parameters: method, path, expected. Return annotation: unspecified. No function description is provided.

Evidence: EV-2A239BE7C405

## Condition in api_check

Code evaluates: individual.replace('\r\n', '\n') != preview. Business intent and supported input boundaries require review.

Evidence: EV-CFA4F996DD54

## Condition in api_check

Code evaluates: job['config']['providers'] or job['analysis']['execution'] is not None. Business intent and supported input boundaries require review.

Evidence: EV-4877BF744386

## Condition in api_check

Code evaluates: job['workflow']['counts']['passed'] != 0. Business intent and supported input boundaries require review.

Evidence: EV-6F97BE9C09C9

## Condition in api_check

Code evaluates: package_output. Business intent and supported input boundaries require review.

Evidence: EV-EB22F94CB947

## Condition in run_checks

Code evaluates: all((item['status'] == 'passed' for item in checks.values())). Business intent and supported input boundaries require review.

Evidence: EV-0BBBFC651731

## Condition in postgres_check

Code evaluates: not inspect(connection).has_table('alembic_version'). Business intent and supported input boundaries require review.

Evidence: EV-B16B3A2CC1D0

## Condition in postgres_check

Code evaluates: compare_metadata(MigrationContext.configure(connection), Base.metadata). Business intent and supported input boundaries require review.

Evidence: EV-9CD546315FEF

## Condition in redis_check

Code evaluates: not created or client.get(key) != 'roundtrip-ok'. Business intent and supported input boundaries require review.

Evidence: EV-1799930688AA

## Condition in redis_check

Code evaluates: created. Business intent and supported input boundaries require review.

Evidence: EV-901C9561186F

## Condition in storage_check

Code evaluates: storage.read_text(probe_id, 1, 'probe.txt') != payload. Business intent and supported input boundaries require review.

Evidence: EV-AA2E6BB564FB

## Condition in api_check.request

Code evaluates: response.status_code != expected. Business intent and supported input boundaries require review.

Evidence: EV-5092435A55F2

## Condition in api_check

Code evaluates: job['status'] == 'completed'. Business intent and supported input boundaries require review.

Evidence: EV-6A5AA4FEE212

## Condition in api_check

Code evaluates: job['status'] == 'failed'. Business intent and supported input boundaries require review.

Evidence: EV-F9046D9A9A7B

## Condition in api_check

Code evaluates: time.monotonic() >= deadline. Business intent and supported input boundaries require review.

Evidence: EV-63F2943D1066

## Condition in api_check

Code evaluates: archive.testzip() is not None. Business intent and supported input boundaries require review.

Evidence: EV-1319BA313C0C

## Condition in api_check

Code evaluates: counts != {'docx': 7, 'pdf': 7, 'xlsx': 1, 'svg': 4, 'png': 4}. Business intent and supported input boundaries require review.

Evidence: EV-CEB504753155

## Condition in api_check

Code evaluates: other.get('/api/session').status_code != 200 or other.get(path).status_code != 404. Business intent and supported input boundaries require review.

Evidence: EV-DF0F8B25A89B

## Condition in storage_check

Code evaluates: hashlib.sha256(download.path.read_bytes()).hexdigest() != expected_hash. Business intent and supported input boundaries require review.

Evidence: EV-4194377E517A

## Condition in storage_check

Code evaluates: download.cleanup. Business intent and supported input boundaries require review.

Evidence: EV-FAC073CB8FB5

## Condition in api_check

Code evaluates: not record or record.status != 'completed' or (not stored) or (stored.package_sha256 != checksum). Business intent and supported input boundaries require review.

Evidence: EV-DCF4D07E44FA

## Condition in api_check

Code evaluates: hashlib.sha256(downloaded.path.read_bytes()).hexdigest() != checksum. Business intent and supported input boundaries require review.

Evidence: EV-D27C3193B1C5

## Condition in api_check

Code evaluates: downloaded.cleanup. Business intent and supported input boundaries require review.

Evidence: EV-1315C21CE8A4

## Condition in run_checks.run

Code evaluates: isinstance(exc, CheckFailure). Business intent and supported input boundaries require review.

Evidence: EV-E0C29DF62CF8

## Condition in run_checks.run

Code evaluates: original is not None and getattr(original, 'sqlstate', None). Business intent and supported input boundaries require review.

Evidence: EV-E552E71DB4B7

## connection.execute

Call to connection.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-A066A2AE4009

## connection.execute

Call to connection.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-1C1BAB3823B5

## main

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-97E1A9B7E661

## Condition in main

Code evaluates: args.command == 'compose-env'. Business intent and supported input boundaries require review.

Evidence: EV-95FCE0FDB8DC

## Condition in main

Code evaluates: args.command == 'check-services'. Business intent and supported input boundaries require review.

Evidence: EV-DE0855E37A40

## Condition in main

Code evaluates: args.command == 'key'. Business intent and supported input boundaries require review.

Evidence: EV-58CC9123F0D1

## Condition in main

Code evaluates: args.timeout < 1. Business intent and supported input boundaries require review.

Evidence: EV-1FE93DACE448

## Condition in main

Code evaluates: args.output and args.output.suffix.lower() != '.json'. Business intent and supported input boundaries require review.

Evidence: EV-D7621306E19F

## Condition in main

Code evaluates: args.output. Business intent and supported input boundaries require review.

Evidence: EV-FC59B9DD4CAC

## Condition in main

Code evaluates: args.command == 'init-db'. Business intent and supported input boundaries require review.

Evidence: EV-2F8E5B094121

## Condition in main

Code evaluates: args.command in {'serve', 'worker', 'scheduler'}. Business intent and supported input boundaries require review.

Evidence: EV-74D0ECFB4F62

## Condition in main

Code evaluates: args.log_level. Business intent and supported input boundaries require review.

Evidence: EV-F1D0B8052BB9

## Condition in main

Code evaluates: args.command == 'serve'. Business intent and supported input boundaries require review.

Evidence: EV-00904884BA2B

## Condition in main

Code evaluates: args.command == 'cleanup'. Business intent and supported input boundaries require review.

Evidence: EV-79BEA169459C

## Condition in main

Code evaluates: args.command == 'worker' and args.concurrency < 1. Business intent and supported input boundaries require review.

Evidence: EV-6979F66C8D9A

## Condition in main

Code evaluates: args.command == 'worker'. Business intent and supported input boundaries require review.

Evidence: EV-DC5466C98EA4

## Condition in main

Code evaluates: args.command == 'scan'. Business intent and supported input boundaries require review.

Evidence: EV-792B5D336C2A

## Condition in main

Code evaluates: args.pool. Business intent and supported input boundaries require review.

Evidence: EV-D3024A4AF9FF

## Condition in main

Code evaluates: args.schedule. Business intent and supported input boundaries require review.

Evidence: EV-53BF34A2AD79

## Condition in main

Code evaluates: not args.path.is_dir(). Business intent and supported input boundaries require review.

Evidence: EV-F0DE816C1F0C

## Condition in main

Code evaluates: args.output.resolve().is_relative_to(args.path.resolve()). Business intent and supported input boundaries require review.

Evidence: EV-F7B1F701C597

## Condition in main

Code evaluates: args.output.exists() or package_path(args.output).exists(). Business intent and supported input boundaries require review.

Evidence: EV-05B4EAA7EDC9

## service_url

Function declaration. Parameters: value, host, port. Return annotation: str. No function description is provided.

Evidence: EV-6F5A6CCD8D12

## write_compose_env

Function declaration. Parameters: cfg, output, database_host, redis_host, minio_host. Return annotation: unspecified. No function description is provided.

Evidence: EV-149FA05A9147

## Condition in service_url

Code evaluates: not parsed.hostname or not host or any((c in host for c in '/\\@?#\r\n')). Business intent and supported input boundaries require review.

Evidence: EV-CFCC25EBF29C

## Condition in write_compose_env

Code evaluates: output.resolve() == Path('.env').resolve(). Business intent and supported input boundaries require review.

Evidence: EV-837A6F72CEAB

## Condition in write_compose_env

Code evaluates: not database.drivername.startswith('postgresql'). Business intent and supported input boundaries require review.

Evidence: EV-6A8E8E0A21E0

## Condition in write_compose_env

Code evaluates: not database_host or any((c in database_host for c in '/\\@?#\r\n')). Business intent and supported input boundaries require review.

Evidence: EV-5ED256BCB305

## Condition in write_compose_env

Code evaluates: cfg.storage_backend == 's3' and cfg.s3_endpoint_url. Business intent and supported input boundaries require review.

Evidence: EV-317288F74BB1

## Condition in write_compose_env

Code evaluates: any(('\n' in value or '\r' in value for value in values.values())). Business intent and supported input boundaries require review.

Evidence: EV-F5A8387BCFAA

## Condition in write_compose_env

Code evaluates: temporary is not None and temporary.exists(). Business intent and supported input boundaries require review.

Evidence: EV-D5BE88DF2B31

## Settings

Class bases: BaseSettings. Annotated fields: env, log_level, public_url, allowed_hosts, database_url, data_dir, storage_backend, s3_bucket, s3_region, s3_endpoint_url, s3_prefix, s3_access_key_id, s3_secret_access_key, s3_session_token, s3_addressing_style, encryption_key, job_backend, redis_backend, redis_url, github_client_id, github_client_secret, github_oauth_scopes, reviewers, openai_api_key, anthropic_api_key, gemini_api_key, openai_model, anthropic_model, gemini_model, retention_days, session_hours, max_archive_bytes, max_expanded_bytes, max_archive_files, max_file_bytes, max_concurrent_jobs, test_execution_enabled, test_image, test_timeout, frontend_dir. Persistence cannot be concluded from class naming alone.

Evidence: EV-7D8F7BF36CEA

## settings

Function declaration. Parameters: none. Return annotation: Settings. No function description is provided.

Evidence: EV-F4F1ED44CFE4

## Settings.normalize_log_level

Function declaration. Parameters: cls, value. Return annotation: unspecified. No function description is provided.

Evidence: EV-7A04632D6C90

## Settings.storage

Function declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-82D7E520B177

## Settings.production

Function declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-36D82B1EC1AF

## Condition in Settings.storage

Code evaluates: self.storage_backend == 's3'. Business intent and supported input boundaries require review.

Evidence: EV-9D64A2E5D5A7

## Condition in Settings.production

Code evaluates: self.env == 'production'. Business intent and supported input boundaries require review.

Evidence: EV-EA663AF4AC5D

## Condition in Settings.production

Code evaluates: self.job_backend == 'celery' and self.redis_backend != 'real'. Business intent and supported input boundaries require review.

Evidence: EV-824ED0DA7C55

## Condition in Settings.production

Code evaluates: self.max_concurrent_jobs < 1. Business intent and supported input boundaries require review.

Evidence: EV-F70841EA66C0

## Condition in Settings.storage

Code evaluates: not self.s3_bucket.strip() or any((c in self.s3_bucket for c in '/\\:')). Business intent and supported input boundaries require review.

Evidence: EV-E288344AD447

## Condition in Settings.storage

Code evaluates: self.s3_prefix and (any((part in {'', '.', '..'} for part in self.s3_prefix.split('/'))) or any((c in self.s3_prefix for c in '\\:')) or any((ord(c) < 32 for c in self.s3_prefix))). Business intent and supported input boundaries require review.

Evidence: EV-916E73866B83

## Condition in Settings.storage

Code evaluates: self.s3_endpoint_url. Business intent and supported input boundaries require review.

Evidence: EV-0DF7ABD3A3B6

## Condition in Settings.storage

Code evaluates: bool(access_key) != bool(secret_key). Business intent and supported input boundaries require review.

Evidence: EV-5D09FBCDDFE0

## Condition in Settings.storage

Code evaluates: self.s3_session_token.get_secret_value() and (not access_key). Business intent and supported input boundaries require review.

Evidence: EV-089DC5DD5E77

## Condition in Settings.production

Code evaluates: not self.encryption_key.get_secret_value(). Business intent and supported input boundaries require review.

Evidence: EV-21C50E25E1CB

## Condition in Settings.production

Code evaluates: not self.public_url.startswith('https://'). Business intent and supported input boundaries require review.

Evidence: EV-87F71139CF19

## Condition in Settings.production

Code evaluates: not self.database_url.startswith('postgresql') or self.job_backend != 'celery'. Business intent and supported input boundaries require review.

Evidence: EV-651FDAE813DC

## Condition in Settings.storage

Code evaluates: endpoint.scheme not in {'http', 'https'} or not endpoint.hostname or endpoint.username or endpoint.password or endpoint.query or endpoint.fragment or (endpoint.path not in {'', '/'}). Business intent and supported input boundaries require review.

Evidence: EV-E56B5E3C5FD8

## now

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-05ECBF6BB2A2

## Base

Class bases: DeclarativeBase. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-FDDB1BB935C5

## JobAdmission

Class bases: Base. Annotated fields: id. Persistence cannot be concluded from class naming alone.

Evidence: EV-12C5F1F1B8AF

## UserSession

Class bases: Base. Annotated fields: id, owner, login, token, csrf, oauth_state, oauth_verifier, oauth_started, expires. Persistence cannot be concluded from class naming alone.

Evidence: EV-A9B89FBBB448

## Job

Class bases: Base. Annotated fields: id, owner, repository, status, progress, message, config, analysis, baseline_hash, version, created, updated, credential, worker_id, resolved_commit, lease_until. Persistence cannot be concluded from class naming alone.

Evidence: EV-C78667A2DB1D

## JobAccess

Class bases: Base. Annotated fields: job_id, principal, login, role, created. Persistence cannot be concluded from class naming alone.

Evidence: EV-49260818223C

## DocumentVersion

Class bases: Base. Annotated fields: job_id, version, baseline_hash, package_sha256, created. Persistence cannot be concluded from class naming alone.

Evidence: EV-992E64D8AFC2

## Review

Class bases: Base. Annotated fields: id, job_id, baseline_hash, stage, decision, reviewer, comment, created. Persistence cannot be concluded from class naming alone.

Evidence: EV-8BD1CD83834F

## TestResult

Class bases: Base. Annotated fields: id, job_id, baseline_hash, test_case_id, status, source, actual, evidence_reference, severity, reviewer, created. Persistence cannot be concluded from class naming alone.

Evidence: EV-471EEC5899CD

## Audit

Class bases: Base. Annotated fields: id, job_id, actor, action, detail, created. Persistence cannot be concluded from class naming alone.

Evidence: EV-AD5BBF3312D9

## ScanCache

Class bases: Base. Annotated fields: key, payload, updated. Persistence cannot be concluded from class naming alone.

Evidence: EV-56B5E014BE46

## engine

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-8539AE7F1C10

## session_factory

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-AFFDA8B2E692

## init_db

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-E00AB9F27E83

## digest

Function declaration. Parameters: value. Return annotation: str. No function description is provided.

Evidence: EV-4BE1625E93E5

## save_cache

Function declaration. Parameters: db, key, payload. Return annotation: unspecified. Concurrent jobs may discover the same content; writes must be idempotent.

Evidence: EV-C4A57D4F0BF6

## Condition in engine

Code evaluates: cfg.database_url.startswith('sqlite'). Business intent and supported input boundaries require review.

Evidence: EV-03976B92323E

## Condition in save_cache

Code evaluates: db.bind.dialect.name == 'postgresql'. Business intent and supported input boundaries require review.

Evidence: EV-B4ABB8B1E057

## mapped_column

Schema or validation declaration: mapped_column(Integer, primary_key=True)

Evidence: EV-4CB045DD29D7, EV-B3744BC7C6FA

## mapped_column

Schema or validation declaration: mapped_column(String(64), primary_key=True)

Evidence: EV-399E37FD0E1E, EV-600A3B894462

## mapped_column

Schema or validation declaration: mapped_column(String(100), index=True)

Evidence: EV-3F01586D2687, EV-A761CC6B33C5

## mapped_column

Schema or validation declaration: mapped_column(String(100), default='')

Evidence: EV-9FF40361EA2F, EV-37DAEB9224B8

## mapped_column

Schema or validation declaration: mapped_column(Text, default='')

Evidence: EV-2AD62D0D8092, EV-0DA06AC84039

## mapped_column

Schema or validation declaration: mapped_column(String(100))

Evidence: EV-73DD231AEEB4, EV-9AD64C71C6A4, EV-5F28B573DAD0, EV-53BD3BE19CF3, EV-307646C4804A, EV-3B5CEEBCEE9E

## mapped_column

Schema or validation declaration: mapped_column(String(150), default='')

Evidence: EV-05C714C48B91

## mapped_column

Schema or validation declaration: mapped_column(DateTime, nullable=True)

Evidence: EV-E163EEFDCDAF, EV-D627647E3031

## mapped_column

Schema or validation declaration: mapped_column(DateTime)

Evidence: EV-6BA00102528A

## mapped_column

Schema or validation declaration: mapped_column(String(36), primary_key=True)

Evidence: EV-D8CE01CE245F

## mapped_column

Schema or validation declaration: mapped_column(String(200))

Evidence: EV-BB77FC1204AA

## mapped_column

Schema or validation declaration: mapped_column(String(30), default='queued')

Evidence: EV-9818DA0D4C61

## mapped_column

Schema or validation declaration: mapped_column(Integer, default=0)

Evidence: EV-D54306838181

## mapped_column

Schema or validation declaration: mapped_column(Text, default='Waiting for worker')

Evidence: EV-18DE0276EA1A

## mapped_column

Schema or validation declaration: mapped_column(JSON)

Evidence: EV-1107D6E74751, EV-8F92B26CE7C6

## mapped_column

Schema or validation declaration: mapped_column(JSON, nullable=True)

Evidence: EV-9F235BCB70D9

## mapped_column

Schema or validation declaration: mapped_column(String(64), default='')

Evidence: EV-E9849C568C6A

## mapped_column

Schema or validation declaration: mapped_column(Integer, default=1)

Evidence: EV-5B8640498097

## mapped_column

Schema or validation declaration: mapped_column(DateTime, default=now)

Evidence: EV-B4056F501988, EV-00E02F4E7A0F, EV-27278EA7D389, EV-B04D50B3D7EC, EV-185DB2AF7399, EV-4E9444776E69

## mapped_column

Schema or validation declaration: mapped_column(DateTime, default=now, onupdate=now)

Evidence: EV-432C2E8B992B, EV-43DFD08A46B4

## mapped_column

Schema or validation declaration: mapped_column(String(36), default='')

Evidence: EV-CEC4549764E5

## mapped_column

Schema or validation declaration: mapped_column(String(40), default='', server_default='')

Evidence: EV-38E7E261D48D

## mapped_column

Schema or validation declaration: mapped_column(ForeignKey('jobs.id', ondelete='CASCADE'), primary_key=True)

Evidence: EV-18543ADA6BA4, EV-036407D9D038

## mapped_column

Schema or validation declaration: mapped_column(String(100), primary_key=True)

Evidence: EV-4B493D667D77

## mapped_column

Schema or validation declaration: mapped_column(String(20))

Evidence: EV-8D2961F594E1, EV-7A400789427B

## mapped_column

Schema or validation declaration: mapped_column(String(64))

Evidence: EV-EAA2F9B099DF, EV-251BF43552A1, EV-AF9FAB808146, EV-64856C3D6C33

## mapped_column

Schema or validation declaration: mapped_column(primary_key=True)

Evidence: EV-AAFFF79B66D1, EV-8DA509B4190D, EV-8533EE700285

## mapped_column

Schema or validation declaration: mapped_column(ForeignKey('jobs.id', ondelete='CASCADE'), index=True)

Evidence: EV-E79A07ECD48C, EV-9FD39125C5E7, EV-D34085882DD8

## mapped_column

Schema or validation declaration: mapped_column(String(30))

Evidence: EV-F597D151A0AF, EV-302E9AF0136C, EV-6B78F90A29C9, EV-23D9D2D7BE15

## mapped_column

Schema or validation declaration: mapped_column(Text)

Evidence: EV-5C0BA33C9FC5, EV-235877258D2D, EV-D8474D91EAF6

## mapped_column

Schema or validation declaration: mapped_column(String(80))

Evidence: EV-B08DE3083B64

## mapped_column

Schema or validation declaration: mapped_column(JSON, default=dict)

Evidence: EV-AE7A1F5483CE

## engine.sqlite_pragmas

Function declaration. Parameters: connection, _. Return annotation: unspecified. No function description is provided.

Evidence: EV-BB4DFB4B72E4

## db.execute

Call to db.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-FCAE850F72DA

## ForeignKey

Schema or validation declaration: ForeignKey('jobs.id', ondelete='CASCADE')

Evidence: EV-97F7D5B97244, EV-F626543048A0, EV-F27C8D389658, EV-9F220FDC910F, EV-65580A63D36A

## connection.execute

Call to connection.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-D9A4E4653EFF

## connection.execute

Call to connection.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-2CAA1451CFB2

## label

Function declaration. Parameters: value. Return annotation: unspecified. No function description is provided.

Evidence: EV-D539EF909DD6

## graph_sets

Function declaration. Parameters: analysis. Return annotation: unspecified. No function description is provided.

Evidence: EV-B965CFD7FD10

## mermaid

Function declaration. Parameters: nodes, edges, note. Return annotation: unspecified. No function description is provided.

Evidence: EV-21DAC680B1D6

## export_graph

Function declaration. Parameters: directory, name, graph. Return annotation: unspecified. No function description is provided.

Evidence: EV-DA01A6A6CB61

## Condition in graph_sets

Code evaluates: not nodes. Business intent and supported input boundaries require review.

Evidence: EV-858EEC593BD0

## Condition in graph_sets

Code evaluates: api. Business intent and supported input boundaries require review.

Evidence: EV-393860204399

## Condition in mermaid

Code evaluates: not nodes. Business intent and supported input boundaries require review.

Evidence: EV-27E97E770CDA

## Condition in export_graph

Code evaluates: not nodes. Business intent and supported input boundaries require review.

Evidence: EV-B6BD2C22B50B

## Condition in export_graph

Code evaluates: shutil.which('dot'). Business intent and supported input boundaries require review.

Evidence: EV-6B9362113934

## Condition in export_graph

Code evaluates: not rows. Business intent and supported input boundaries require review.

Evidence: EV-1867848CEB98

## Condition in graph_sets

Code evaluates: not handler. Business intent and supported input boundaries require review.

Evidence: EV-4EE79B59D8C2

## Condition in export_graph

Code evaluates: target. Business intent and supported input boundaries require review.

Evidence: EV-8E8ED7A3E809

## image.save

Call to image.save may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-BF8DEFAD293F

## Condition in graph_sets

Code evaluates: item['category'] == 'source'. Business intent and supported input boundaries require review.

Evidence: EV-7E2EEE2A73F8

## Condition in export_graph

Code evaluates: not value. Business intent and supported input boundaries require review.

Evidence: EV-25E2FABEFFD6

## evidence_text

Function declaration. Parameters: ids, evidence, repository. Return annotation: unspecified. No function description is provided.

Evidence: EV-9E67F0EFBB14

## build_sections

Function declaration. Parameters: kind, analysis, state. Return annotation: unspecified. No function description is provided.

Evidence: EV-C4A81A5314FF

## approval_lines

Function declaration. Parameters: state, stage. Return annotation: unspecified. No function description is provided.

Evidence: EV-86AC6DE98F71

## markdown

Function declaration. Parameters: title, metadata, sections. Return annotation: unspecified. No function description is provided.

Evidence: EV-55620050CF05

## write_docx

Function declaration. Parameters: path, title, metadata, sections. Return annotation: unspecified. No function description is provided.

Evidence: EV-246F2DEE2E27

## write_pdf

Function declaration. Parameters: path, title, metadata, sections. Return annotation: unspecified. No function description is provided.

Evidence: EV-0537068BAE4F

## write_rtm

Function declaration. Parameters: path, analysis, state. Return annotation: unspecified. No function description is provided.

Evidence: EV-C3D85A7CF1B8

## package_path

Function declaration. Parameters: root. Return annotation: Path. No function description is provided.

Evidence: EV-548D0B15D94F

## export_package

Function declaration. Parameters: root, analysis, config, state, version. Return annotation: unspecified. No function description is provided.

Evidence: EV-626774756A09

## build_sections.section

Function declaration. Parameters: title, body. Return annotation: unspecified. No function description is provided.

Evidence: EV-52C74E69FA7B

## build_sections.findings

Function declaration. Parameters: title, kinds. Return annotation: unspecified. No function description is provided.

Evidence: EV-F47EC54F2B0F

## Condition in build_sections

Code evaluates: kind == 'srs'. Business intent and supported input boundaries require review.

Evidence: EV-CCCAF6A1A09A

## Condition in approval_lines

Code evaluates: not records. Business intent and supported input boundaries require review.

Evidence: EV-B2ED9AD7FFA2

## write_pdf.safe

Function declaration. Parameters: text. Return annotation: unspecified. No function description is provided.

Evidence: EV-8D1D7FC5D66F

## write_pdf.footer

Function declaration. Parameters: canvas, doc. Return annotation: unspecified. No function description is provided.

Evidence: EV-33F2D51E1D4A

## Condition in write_rtm

Code evaluates: sheet.max_row > 1. Business intent and supported input boundaries require review.

Evidence: EV-E3723DC5F80B

## Condition in export_package

Code evaluates: package_path(root).exists(). Business intent and supported input boundaries require review.

Evidence: EV-3AFD5E94293C

## Condition in export_package

Code evaluates: 'architecture' in config.documents. Business intent and supported input boundaries require review.

Evidence: EV-BA32B7232D3D

## Condition in export_package

Code evaluates: 'data_flow' in config.documents. Business intent and supported input boundaries require review.

Evidence: EV-18BEA8DF5439

## Condition in export_package

Code evaluates: 'test_cases' in config.documents or 'uat_signoff' in config.documents. Business intent and supported input boundaries require review.

Evidence: EV-CA6132A02117

## Condition in evidence_text

Code evaluates: repository.startswith(('local/', 'demo/')). Business intent and supported input boundaries require review.

Evidence: EV-E124D9F909D8

## Condition in build_sections

Code evaluates: kind == 'requirements_signoff'. Business intent and supported input boundaries require review.

Evidence: EV-3DAA6B71B3D0

## document.save

Call to document.save may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-F419A856BBD3

## workbook.save

Call to workbook.save may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-99CE91629190

## Condition in export_package

Code evaluates: 'docx' in config.formats. Business intent and supported input boundaries require review.

Evidence: EV-BFA82A63A3A3

## Condition in export_package

Code evaluates: 'pdf' in config.formats. Business intent and supported input boundaries require review.

Evidence: EV-9409AA8FCDBC

## Condition in build_sections.findings

Code evaluates: f['kind'] in kinds. Business intent and supported input boundaries require review.

Evidence: EV-6D57DBB9BAFE

## Condition in build_sections

Code evaluates: kind == 'test_cases'. Business intent and supported input boundaries require review.

Evidence: EV-20D7F17DB778

## Condition in export_package

Code evaluates: file.is_file(). Business intent and supported input boundaries require review.

Evidence: EV-FEE57686FD4E

## Condition in build_sections

Code evaluates: kind == 'uat_signoff'. Business intent and supported input boundaries require review.

Evidence: EV-3C627943822C

## Condition in build_sections

Code evaluates: kind == 'architecture'. Business intent and supported input boundaries require review.

Evidence: EV-29597948FC8F

## Condition in build_sections

Code evaluates: kind == 'data_flow'. Business intent and supported input boundaries require review.

Evidence: EV-2D6A25642BD5

## Condition in build_sections

Code evaluates: kind == 'technology'. Business intent and supported input boundaries require review.

Evidence: EV-EFAC61A9196C

## junit_summary

Function declaration. Parameters: path. Return annotation: unspecified. No function description is provided.

Evidence: EV-F6779719A44F

## execute_tests

Function declaration. Parameters: root, commit, profile. Return annotation: unspecified. No function description is provided.

Evidence: EV-C1714CE92E4B

## Condition in junit_summary

Code evaluates: path.is_symlink() or path.stat().st_size > 5000000. Business intent and supported input boundaries require review.

Evidence: EV-EF6850E036D8

## Condition in execute_tests

Code evaluates: not cfg.test_execution_enabled. Business intent and supported input boundaries require review.

Evidence: EV-4763AB772547

## Condition in execute_tests

Code evaluates: not re.fullmatch('[\\w./:-]+@sha256:[a-f0-9]{64}', cfg.test_image). Business intent and supported input boundaries require review.

Evidence: EV-5BFE70C54740

## Condition in execute_tests

Code evaluates: not shutil.which('docker'). Business intent and supported input boundaries require review.

Evidence: EV-920B45F07654

## Condition in junit_summary

Code evaluates: case.find('failure') is not None or case.find('error') is not None. Business intent and supported input boundaries require review.

Evidence: EV-2DCCB8EEEE0C

## execute_tests.exclude

Function declaration. Parameters: directory, names. Return annotation: unspecified. No function description is provided.

Evidence: EV-EB58F38D2B01

## Condition in junit_summary

Code evaluates: case.find('skipped') is not None. Business intent and supported input boundaries require review.

Evidence: EV-5FB666AD1864

## Condition in execute_tests

Code evaluates: started.returncode. Business intent and supported input boundaries require review.

Evidence: EV-EDB2E2C17264

## Condition in execute_tests

Code evaluates: profile == 'pytest'. Business intent and supported input boundaries require review.

Evidence: EV-96C2229CA3BA

## Condition in execute_tests

Code evaluates: check.returncode == 0. Business intent and supported input boundaries require review.

Evidence: EV-4B1281AF57B5

## GitHubError

Class bases: Exception. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-F762521FF183

## GitHub

Class bases: none. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-23113678431B

## safe_extract

Function declaration. Parameters: archive, destination, max_bytes, max_files. Return annotation: unspecified. Reject archive traversal, symlinks, Windows device/ADS paths, duplicates and zip bombs.

Evidence: EV-3C6DD9F144C3

## GitHubError.__init__

Function declaration. Parameters: self, message, status. Return annotation: unspecified. No function description is provided.

Evidence: EV-6BF9876B6E4F

## GitHub.__init__

Function declaration. Parameters: self, token, transport. Return annotation: unspecified. No function description is provided.

Evidence: EV-7BEB396B57DA

## GitHub.__enter__

Function declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-C6A38DA91429

## GitHub.__exit__

Function declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-BD15A95483E9

## GitHub.request

Function declaration. Parameters: self, path, params. Return annotation: unspecified. No function description is provided.

Evidence: EV-361987E1EA33

## GitHub.user

Function declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-318E1092B0CB

## GitHub.repositories

Function declaration. Parameters: self, page. Return annotation: unspecified. No function description is provided.

Evidence: EV-B7495F8E4BB2

## GitHub.metadata

Function declaration. Parameters: repo. Return annotation: unspecified. No function description is provided.

Evidence: EV-4E37C9DFF93B

## GitHub.repository

Function declaration. Parameters: self, full_name. Return annotation: unspecified. No function description is provided.

Evidence: EV-B076B402C610

## GitHub.refs

Function declaration. Parameters: self, full_name, kind, page. Return annotation: unspecified. No function description is provided.

Evidence: EV-56A7066BAC50

## GitHub.resolve

Function declaration. Parameters: self, full_name, ref. Return annotation: unspecified. No function description is provided.

Evidence: EV-D69FA530A7CC

## GitHub.download

Function declaration. Parameters: self, full_name, commit, destination. Return annotation: unspecified. No function description is provided.

Evidence: EV-0248256D5ACB

## Condition in GitHub.__init__

Code evaluates: token. Business intent and supported input boundaries require review.

Evidence: EV-DDFD61DBE9A5

## Condition in GitHub.resolve

Code evaluates: not re.fullmatch('[a-f0-9]{40}', value). Business intent and supported input boundaries require review.

Evidence: EV-31DE4DB71309

## Condition in GitHub.download

Code evaluates: response.status_code not in {301, 302, 307}. Business intent and supported input boundaries require review.

Evidence: EV-DFB195D01908

## Condition in GitHub.download

Code evaluates: parsed.scheme != 'https' or parsed.hostname != 'codeload.github.com' or parsed.username or (parsed.port not in {None, 443}). Business intent and supported input boundaries require review.

Evidence: EV-846913BDC484

## Condition in safe_extract

Code evaluates: len(members) > max_files. Business intent and supported input boundaries require review.

Evidence: EV-603E6235B453

## Condition in safe_extract

Code evaluates: len(prefixes) != 1. Business intent and supported input boundaries require review.

Evidence: EV-DB7B5E52B814

## Condition in GitHub.request

Code evaluates: response.status_code in {429, 500, 502, 503, 504} and attempt < 2. Business intent and supported input boundaries require review.

Evidence: EV-2BA780A39D5B

## Condition in GitHub.request

Code evaluates: response.status_code in {403, 429}. Business intent and supported input boundaries require review.

Evidence: EV-3BCFD5977BA4

## Condition in GitHub.request

Code evaluates: response.status_code == 401. Business intent and supported input boundaries require review.

Evidence: EV-15A35DFF3478

## Condition in GitHub.request

Code evaluates: response.status_code == 404. Business intent and supported input boundaries require review.

Evidence: EV-8A9C7BA084B9

## Condition in GitHub.request

Code evaluates: response.status_code >= 400. Business intent and supported input boundaries require review.

Evidence: EV-022B0F3E03B5

## Condition in safe_extract

Code evaluates: not parts or entry.orig_filename.startswith(('/', '\\')) or '\\' in entry.orig_filename or any((p in {'..', '.'} or ':' in p or p.endswith(('.', ' ')) or any((ord(c) < 32 for c in p)) or re.fullmatch('(?i)(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\\..*)?', p) for p in parts)). Business intent and supported input boundaries require review.

Evidence: EV-D905F072D68E

## Condition in safe_extract

Code evaluates: stat.S_ISLNK(entry.external_attr >> 16). Business intent and supported input boundaries require review.

Evidence: EV-38F72CF1D679

## Condition in safe_extract

Code evaluates: total > max_bytes or (entry.file_size > 1000000 and entry.file_size > max(entry.compress_size, 1) * 500). Business intent and supported input boundaries require review.

Evidence: EV-B3D6BFB84FA7

## Condition in safe_extract

Code evaluates: len(parts) == 1 or entry.is_dir(). Business intent and supported input boundaries require review.

Evidence: EV-C3E01D27B747

## Condition in safe_extract

Code evaluates: relative.casefold() in seen. Business intent and supported input boundaries require review.

Evidence: EV-320E52D6000B

## Condition in safe_extract

Code evaluates: not target.resolve().is_relative_to(root). Business intent and supported input boundaries require review.

Evidence: EV-0F87017C4981

## Condition in GitHub.download

Code evaluates: stream.status_code != 200. Business intent and supported input boundaries require review.

Evidence: EV-B9F185D7B84A

## Condition in GitHub.request

Code evaluates: attempt < 2. Business intent and supported input boundaries require review.

Evidence: EV-756504C94C9A

## Condition in GitHub.download

Code evaluates: archive.tell() + len(chunk) > cfg.max_archive_bytes. Business intent and supported input boundaries require review.

Evidence: EV-7CFC20F142F6

## import_edges

Function declaration. Parameters: root, inventory, imports. Return annotation: unspecified. No function description is provided.

Evidence: EV-DC6B53FEDA75

## Condition in import_edges

Code evaluates: 'pyproject.toml' in paths. Business intent and supported input boundaries require review.

Evidence: EV-0E1E44B30AA4

## import_edges.python_target

Function declaration. Parameters: module. Return annotation: unspecified. No function description is provided.

Evidence: EV-6FC02C03AF67

## Condition in import_edges

Code evaluates: package.name in {'src', 'backend', 'lib'}. Business intent and supported input boundaries require review.

Evidence: EV-401822895A60

## Condition in import_edges

Code evaluates: PurePosixPath(path).name == '__init__.py'. Business intent and supported input boundaries require review.

Evidence: EV-B9A2E9349BEA

## Condition in import_edges

Code evaluates: isinstance(packages, dict). Business intent and supported input boundaries require review.

Evidence: EV-5235CD4642FD

## Condition in import_edges

Code evaluates: parent.name in {'src', 'backend', 'lib'}. Business intent and supported input boundaries require review.

Evidence: EV-2C0CBB04E619

## Condition in import_edges.python_target

Code evaluates: candidate in python_paths. Business intent and supported input boundaries require review.

Evidence: EV-6EFA98C59B1F

## Condition in import_edges

Code evaluates: source.endswith('.py'). Business intent and supported input boundaries require review.

Evidence: EV-164CF42F8359

## Condition in import_edges

Code evaluates: isinstance(value, str). Business intent and supported input boundaries require review.

Evidence: EV-90BA7147A367

## Condition in import_edges

Code evaluates: level. Business intent and supported input boundaries require review.

Evidence: EV-8B40C028EA88

## Condition in import_edges

Code evaluates: not targets and (not level). Business intent and supported input boundaries require review.

Evidence: EV-AE1B2BCD85C6

## Condition in import_edges

Code evaluates: module.startswith('.'). Business intent and supported input boundaries require review.

Evidence: EV-6E1D2FB5FEC2

## Condition in import_edges

Code evaluates: source != target and identity not in seen. Business intent and supported input boundaries require review.

Evidence: EV-E379D9C86139

## Condition in import_edges

Code evaluates: not base.is_absolute() and '..' not in base.parts and ('\\' not in value) and (':' not in value). Business intent and supported input boundaries require review.

Evidence: EV-38281310F763

## Condition in import_edges

Code evaluates: level > len(parent.parts). Business intent and supported input boundaries require review.

Evidence: EV-B7C61E1A5697

## Condition in import_edges

Code evaluates: found. Business intent and supported input boundaries require review.

Evidence: EV-903D2CBC466B

## Condition in import_edges

Code evaluates: len(matches) == 1. Business intent and supported input boundaries require review.

Evidence: EV-4041C64DCBD8

## Condition in import_edges

Code evaluates: target.is_relative_to(root). Business intent and supported input boundaries require review.

Evidence: EV-7D2B28B87054

## Condition in import_edges

Code evaluates: any(found). Business intent and supported input boundaries require review.

Evidence: EV-5F54F8673600

## start_local_queue

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-40FC982544FD

## stop_local_queue

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-2DA94864B7A3

## output_root

Function declaration. Parameters: job_id, version. Return annotation: unspecified. Legacy local layout, also used when migrating existing artifacts to S3.

Evidence: EV-948916CF6FF2

## export_job

Function declaration. Parameters: db, job. Return annotation: unspecified. No function description is provided.

Evidence: EV-3617236689C5

## next_version

Function declaration. Parameters: job. Return annotation: unspecified. Skip orphaned exports after a failed transaction without overwriting any version.

Evidence: EV-5F93C7A86C2B

## WorkerLeaseLost

Class bases: Exception. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-33DF68ED1D4B

## set_progress

Function declaration. Parameters: job_id, worker_id, value, message. Return annotation: unspecified. No function description is provided.

Evidence: EV-140C75DDE56D

## pin_commit

Function declaration. Parameters: job_id, worker_id, commit. Return annotation: unspecified. No function description is provided.

Evidence: EV-3F93482218E0

## run_job

Function declaration. Parameters: job_id. Return annotation: unspecified. No function description is provided.

Evidence: EV-C5605AC49E91

## enqueue

Function declaration. Parameters: job_id. Return annotation: unspecified. No function description is provided.

Evidence: EV-D5269F7DA2C3

## cleanup

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-83A622ADB217

## recover_jobs

Function declaration. Parameters: none. Return annotation: unspecified. Celery Beat re-delivers expired leases and queued IDs; atomic claim prevents duplicate work.

Evidence: EV-05280CAF4E32

## Condition in start_local_queue

Code evaluates: local_queue is not None. Business intent and supported input boundaries require review.

Evidence: EV-E52AE37FD94B

## Condition in stop_local_queue

Code evaluates: queue is not None. Business intent and supported input boundaries require review.

Evidence: EV-09D2FBF6B2C6

## run_job.heartbeat

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-71ED16C3835E

## Condition in enqueue

Code evaluates: settings().job_backend == 'celery'. Business intent and supported input boundaries require review.

Evidence: EV-B001DF9F2BD4

## Condition in set_progress

Code evaluates: not changed.rowcount. Business intent and supported input boundaries require review.

Evidence: EV-36B05A79550B

## Condition in pin_commit

Code evaluates: not resolved. Business intent and supported input boundaries require review.

Evidence: EV-AB0F1FB0C854

## Condition in run_job

Code evaluates: not claimed.rowcount. Business intent and supported input boundaries require review.

Evidence: EV-92419F6051C8

## Condition in enqueue

Code evaluates: local_queue is None. Business intent and supported input boundaries require review.

Evidence: EV-1D94DEAD557F

## db.execute

Call to db.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-F052B543ECB8

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-28A2DD905F46

## db.execute

Call to db.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-0E61713AA144

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-805753E81214

## db.execute

Call to db.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-95AACAFCF316

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-60247E4EFD28

## Condition in run_job

Code evaluates: config.repository == 'demo/inventory'. Business intent and supported input boundaries require review.

Evidence: EV-C555458D82CE, EV-C6B037C8661D

## Condition in run_job

Code evaluates: config.execute_tests. Business intent and supported input boundaries require review.

Evidence: EV-A6BA680859FA

## db.execute

Call to db.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-F261F2408070

## db.execute

Call to db.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-5DA7C6DF02B7

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-06BBA748CBA6

## Condition in recover_jobs

Code evaluates: job.status == 'running'. Business intent and supported input boundaries require review.

Evidence: EV-2F62590F29D6

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-C189B781189D

## Condition in run_job

Code evaluates: job.worker_id != worker_id or job.status != 'running'. Business intent and supported input boundaries require review.

Evidence: EV-55B488499D9D

## Condition in run_job

Code evaluates: previous and previous.analysis. Business intent and supported input boundaries require review.

Evidence: EV-A1CA71AD64EA

## Condition in run_job

Code evaluates: artifact_storage().version_exists(job.id, job.version). Business intent and supported input boundaries require review.

Evidence: EV-EF199AFD130B

## Condition in run_job

Code evaluates: job and job.worker_id == worker_id. Business intent and supported input boundaries require review.

Evidence: EV-AFFDED72154F

## Condition in run_job

Code evaluates: private and any((p.provider not in config.consent_providers for p in config.providers)). Business intent and supported input boundaries require review.

Evidence: EV-79037F44AE24

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-803814B656EA

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-537BFE3F18A8

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-8EB15A3A6D55

## heartbeat_db.execute

Call to heartbeat_db.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-0F766EB9A791

## heartbeat_db.commit

Call to heartbeat_db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-65F1DB0C4B9D

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-B2087F8C9967

## ProviderFailure

Class bases: Exception. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-E580624F253F

## call_provider

Function declaration. Parameters: provider, model, prompt. Return annotation: unspecified. No function description is provided.

Evidence: EV-41AE6E18932F

## evidence_batches

Function declaration. Parameters: evidence, max_chars. Return annotation: unspecified. Whole evidence records only; no truncation that silently invalidates a citation.

Evidence: EV-5EF9DDEE90F5

## enrich

Function declaration. Parameters: analysis, config, private, invoke, sleep, db, cache_scope. Return annotation: unspecified. No function description is provided.

Evidence: EV-44FBA0645AB5

## Condition in call_provider

Code evaluates: not key. Business intent and supported input boundaries require review.

Evidence: EV-3647B3D5777F

## Condition in call_provider

Code evaluates: provider == 'openai'. Business intent and supported input boundaries require review.

Evidence: EV-A1DEBD9F5582

## Condition in call_provider

Code evaluates: provider == 'anthropic'. Business intent and supported input boundaries require review.

Evidence: EV-706B8DD2923F

## Condition in call_provider

Code evaluates: provider == 'gemini'. Business intent and supported input boundaries require review.

Evidence: EV-FB1FB9ECE521

## Condition in evidence_batches

Code evaluates: chunk. Business intent and supported input boundaries require review.

Evidence: EV-7E432E69C895

## Condition in enrich

Code evaluates: not config.providers. Business intent and supported input boundaries require review.

Evidence: EV-B372A9B20BC7

## Condition in enrich

Code evaluates: private and any((p.provider not in allowed for p in config.providers)). Business intent and supported input boundaries require review.

Evidence: EV-B3E1DD42FB76

## Condition in enrich

Code evaluates: len(all_batches) > max_batches. Business intent and supported input boundaries require review.

Evidence: EV-FB96CDF50558

## Condition in evidence_batches

Code evaluates: chunk and size + length > max_chars. Business intent and supported input boundaries require review.

Evidence: EV-BD831DA6A15F

## Condition in enrich

Code evaluates: cached. Business intent and supported input boundaries require review.

Evidence: EV-3C8191318CE4

## Condition in enrich

Code evaluates: result is None. Business intent and supported input boundaries require review.

Evidence: EV-7A2495DD58E6

## Condition in enrich

Code evaluates: db is not None and (not cached). Business intent and supported input boundaries require review.

Evidence: EV-CF3334E017A4

## Condition in call_provider

Code evaluates: result.status != 'completed' or result.output_parsed is None. Business intent and supported input boundaries require review.

Evidence: EV-85A808E3157F

## Condition in call_provider

Code evaluates: result.stop_reason != 'end_turn' or result.parsed_output is None. Business intent and supported input boundaries require review.

Evidence: EV-FF8EBC5CA35F

## Condition in call_provider

Code evaluates: not result.text. Business intent and supported input boundaries require review.

Evidence: EV-4FBE705917A2

## Condition in enrich

Code evaluates: result is not None. Business intent and supported input boundaries require review.

Evidence: EV-89283088F9E2

## Condition in enrich

Code evaluates: not req.evidence_ids or any((e not in valid for e in req.evidence_ids)). Business intent and supported input boundaries require review.

Evidence: EV-60D6C3EF5CB6

## Condition in enrich

Code evaluates: not scenario.steps or not scenario.expected.strip(). Business intent and supported input boundaries require review.

Evidence: EV-CFA85107F665

## Condition in enrich

Code evaluates: not retryable or attempt == 2. Business intent and supported input boundaries require review.

Evidence: EV-277FE92B2B03

## configure_logging

Function declaration. Parameters: level. Return annotation: unspecified. No function description is provided.

Evidence: EV-FC2EBA81B8C4

## create_redis_client

Function declaration. Parameters: config. Return annotation: unspecified. No function description is provided.

Evidence: EV-9771B970BF60

## LocalJobQueue

Class bases: none. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-F87D9885E780

## Condition in create_redis_client

Code evaluates: config.redis_backend == 'fake'. Business intent and supported input boundaries require review.

Evidence: EV-031127C9D371

## LocalJobQueue.__init__

Function declaration. Parameters: self, config, handler. Return annotation: unspecified. No function description is provided.

Evidence: EV-E57BE018214D

## LocalJobQueue.enqueue

Function declaration. Parameters: self, job_id. Return annotation: unspecified. No function description is provided.

Evidence: EV-1856DEAEC0E3

## LocalJobQueue._consume_one

Function declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-E009DE9AA2A2

## LocalJobQueue.close

Function declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-875CC75DB5CD

## Condition in LocalJobQueue.enqueue

Code evaluates: self.closed. Business intent and supported input boundaries require review.

Evidence: EV-D696C00496B8

## Condition in LocalJobQueue._consume_one

Code evaluates: job_id is not None. Business intent and supported input boundaries require review.

Evidence: EV-6310FCBC9A2C

## Condition in LocalJobQueue.close

Code evaluates: self.closed. Business intent and supported input boundaries require review.

Evidence: EV-6BF685A0003D

## StrictModel

Class bases: BaseModel. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-A1EDF1FA09E4

## Confidence

Class bases: StrEnum. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-69553C54F1F3

## Evidence

Class bases: StrictModel. Annotated fields: id, path, start_line, end_line, symbol, snippet, commit. Persistence cannot be concluded from class naming alone.

Evidence: EV-BE191E96FE9C

## Finding

Class bases: StrictModel. Annotated fields: id, kind, title, detail, confidence, evidence_ids, metadata. Persistence cannot be concluded from class naming alone.

Evidence: EV-35A404DAB01E

## Requirement

Class bases: StrictModel. Annotated fields: id, title, statement, confidence, evidence_ids, module, source. Persistence cannot be concluded from class naming alone.

Evidence: EV-36EB88ECC405

## TestCase

Class bases: StrictModel. Annotated fields: id, requirement_id, title, category, preconditions, steps, expected, status, source. Persistence cannot be concluded from class naming alone.

Evidence: EV-CF7387EF9EE0

## ProviderSelection

Class bases: StrictModel. Annotated fields: provider, model. Persistence cannot be concluded from class naming alone.

Evidence: EV-32BD2DBF85AD

## AnalysisConfig

Class bases: StrictModel. Annotated fields: repository, ref, depth, documents, formats, providers, consent_providers, execute_tests, test_profile. Persistence cannot be concluded from class naming alone.

Evidence: EV-A5E907126942

## LLMScenario

Class bases: StrictModel. Annotated fields: title, category, preconditions, steps, expected. Persistence cannot be concluded from class naming alone.

Evidence: EV-199D1FC6B600

## LLMRequirement

Class bases: StrictModel. Annotated fields: title, statement, evidence_ids, scenarios. Persistence cannot be concluded from class naming alone.

Evidence: EV-6E64E43BEF0B

## LLMOutput

Class bases: StrictModel. Annotated fields: requirements, gaps. Persistence cannot be concluded from class naming alone.

Evidence: EV-D5FA304BAAE5

## ReviewInput

Class bases: StrictModel. Annotated fields: stage, decision, comment, baseline_hash, acknowledged. Persistence cannot be concluded from class naming alone.

Evidence: EV-377D52964F06

## ResultInput

Class bases: StrictModel. Annotated fields: baseline_hash, test_case_id, status, actual, evidence_reference, source, severity, attested. Persistence cannot be concluded from class naming alone.

Evidence: EV-6892A1468A52

## RequirementEdit

Class bases: StrictModel. Annotated fields: statement, rationale, baseline_hash. Persistence cannot be concluded from class naming alone.

Evidence: EV-B06ED9F0115D

## CollaboratorInput

Class bases: StrictModel. Annotated fields: login, role, acknowledged. Persistence cannot be concluded from class naming alone.

Evidence: EV-9B3FE3AA5FEB

## AnalysisConfig.valid_repository

Function declaration. Parameters: cls, value. Return annotation: unspecified. No function description is provided.

Evidence: EV-A28DC1C8A5B3

## AnalysisConfig.valid_ref

Function declaration. Parameters: cls, value. Return annotation: unspecified. No function description is provided.

Evidence: EV-A3E4354179F9

## AnalysisConfig.unique

Function declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-5C17BDFA00F3

## Field

Schema or validation declaration: Field(default_factory=dict)

Evidence: EV-D1CCDAE14BB8

## Field

Schema or validation declaration: Field(min_length=1, max_length=120, pattern='^[a-zA-Z0-9._:/-]+$')

Evidence: EV-5C99779A32C6

## Field

Schema or validation declaration: Field(pattern='^[A-Za-z0-9][A-Za-z0-9-]{0,38}/[A-Za-z0-9_.-]{1,100}$', max_length=140)

Evidence: EV-981BA12DBDA4

## Field

Schema or validation declaration: Field(default='', max_length=250)

Evidence: EV-0D1E7662029A

## Field

Schema or validation declaration: Field(default_factory=lambda: DOCUMENTS.copy(), min_length=1)

Evidence: EV-B7A8B4E73A77

## Field

Schema or validation declaration: Field(default_factory=lambda: ['md', 'docx'], min_length=1)

Evidence: EV-2F600140343B

## Field

Schema or validation declaration: Field(default_factory=list, max_length=3)

Evidence: EV-B5B597E446F0

## Field

Schema or validation declaration: Field(default_factory=list)

Evidence: EV-36A33AD5B519, EV-C804B96901A5

## Condition in AnalysisConfig.valid_repository

Code evaluates: value.split('/')[1] in {'.', '..'}. Business intent and supported input boundaries require review.

Evidence: EV-B2B4BD1120DB

## Condition in AnalysisConfig.valid_ref

Code evaluates: any((ord(c) < 32 for c in value)) or value.startswith('-'). Business intent and supported input boundaries require review.

Evidence: EV-8DBAAA308AA5

## Condition in AnalysisConfig.unique

Code evaluates: len({p.provider for p in self.providers}) != len(self.providers). Business intent and supported input boundaries require review.

Evidence: EV-D26C6E22BE51

## Field

Schema or validation declaration: Field(min_length=1, max_length=4000)

Evidence: EV-D1B158605584

## Field

Schema or validation declaration: Field(min_length=64, max_length=64)

Evidence: EV-4E760EA3C64E, EV-7DABE7605632

## Field

Schema or validation declaration: Field(min_length=10, max_length=5000)

Evidence: EV-9D146E30B276

## Field

Schema or validation declaration: Field(min_length=5, max_length=1000)

Evidence: EV-BC5C38085A6F

## Field

Schema or validation declaration: Field(min_length=10, max_length=4000)

Evidence: EV-14BC959388AF

## Field

Schema or validation declaration: Field(min_length=5, max_length=2000)

Evidence: EV-A5E042D1C971

## Field

Schema or validation declaration: Field(pattern='^[A-Za-z0-9][A-Za-z0-9-]{0,38}$')

Evidence: EV-1301296CA324

## redact

Function declaration. Parameters: text. Return annotation: str. No function description is provided.

Evidence: EV-5B82008377BC

## redact_object

Function declaration. Parameters: value. Return annotation: unspecified. No function description is provided.

Evidence: EV-7673861DBB46

## secret_path

Function declaration. Parameters: path. Return annotation: bool. No function description is provided.

Evidence: EV-26D4E8C30639

## cipher

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-3433BB1D0359

## encrypt

Function declaration. Parameters: value. Return annotation: str. No function description is provided.

Evidence: EV-190F4F21B72D

## decrypt

Function declaration. Parameters: value. Return annotation: str. No function description is provided.

Evidence: EV-597A8BE15A4D

## token_hash

Function declaration. Parameters: value. Return annotation: unspecified. No function description is provided.

Evidence: EV-33DC9F9993E2

## new_token

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-DE656DDEBA0D

## Condition in redact_object

Code evaluates: isinstance(value, str). Business intent and supported input boundaries require review.

Evidence: EV-4FE158B6E08A

## Condition in redact_object

Code evaluates: isinstance(value, list). Business intent and supported input boundaries require review.

Evidence: EV-C1AD1965B88F

## Condition in redact_object

Code evaluates: isinstance(value, dict). Business intent and supported input boundaries require review.

Evidence: EV-825530503161

## Condition in cipher

Code evaluates: not key. Business intent and supported input boundaries require review.

Evidence: EV-F79BB5F5BEB6

## StorageError

Class bases: Exception. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-A70F5DEEFEC1

## ArtifactNotFound

Class bases: StorageError. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-974A4EF9EB91

## InvalidArtifactPath

Class bases: ValueError. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-09309A1FD595

## storage_errors

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-A1FED8CFC0C3

## version_name

Function declaration. Parameters: version. Return annotation: str. No function description is provided.

Evidence: EV-754DF011F6EB

## validate_path

Function declaration. Parameters: path. Return annotation: str. No function description is provided.

Evidence: EV-B4D8759803E4

## artifact_key

Function declaration. Parameters: job_id, version, path. Return annotation: str. No function description is provided.

Evidence: EV-C768A4F4A33D

## Download

Class bases: none. Annotated fields: path, filename, cleanup. Persistence cannot be concluded from class naming alone.

Evidence: EV-C040888A19AB

## LocalArtifactStorage

Class bases: none. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-3A96EE52080D

## S3ArtifactStorage

Class bases: none. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-36DD4FD45C3D

## artifact_storage

Function declaration. Parameters: none. Return annotation: LocalArtifactStorage | S3ArtifactStorage. No function description is provided.

Evidence: EV-0405A6A9F2AB

## Condition in version_name

Code evaluates: not isinstance(version, int) or version < 1. Business intent and supported input boundaries require review.

Evidence: EV-27E737A02018

## Condition in validate_path

Code evaluates: not path or any((part in {'', '.', '..'} for part in path.split('/'))) or any((c in path for c in '\\:')) or any((ord(c) < 32 for c in path)). Business intent and supported input boundaries require review.

Evidence: EV-8041C86F5B1F

## LocalArtifactStorage.__init__

Function declaration. Parameters: self, cfg. Return annotation: unspecified. No function description is provided.

Evidence: EV-CB7B24D5B51F

## LocalArtifactStorage.root

Function declaration. Parameters: self, job_id, version. Return annotation: Path. No function description is provided.

Evidence: EV-9A47F6014F97

## LocalArtifactStorage._path

Function declaration. Parameters: self, job_id, version, path. Return annotation: Path. No function description is provided.

Evidence: EV-708738A1938E

## LocalArtifactStorage.export_directory

Function declaration. Parameters: self, job_id, version. Return annotation: unspecified. No function description is provided.

Evidence: EV-A4FC2EFF7BF8

## LocalArtifactStorage.version_exists

Function declaration. Parameters: self, job_id, version. Return annotation: bool. No function description is provided.

Evidence: EV-476B8DC72249

## LocalArtifactStorage.read_text

Function declaration. Parameters: self, job_id, version, path. Return annotation: str. No function description is provided.

Evidence: EV-6D224007E9C0

## LocalArtifactStorage.download

Function declaration. Parameters: self, job_id, version, path. Return annotation: Download. No function description is provided.

Evidence: EV-2A2F5D9AF0C3

## LocalArtifactStorage.delete_job

Function declaration. Parameters: self, job_id. Return annotation: unspecified. No function description is provided.

Evidence: EV-DE4A28596070

## S3ArtifactStorage.__init__

Function declaration. Parameters: self, cfg. Return annotation: unspecified. No function description is provided.

Evidence: EV-C1F4F121BAF1

## S3ArtifactStorage._key

Function declaration. Parameters: self, job_id, version, path. Return annotation: str. No function description is provided.

Evidence: EV-D1DF6E750341

## S3ArtifactStorage.version_exists

Function declaration. Parameters: self, job_id, version. Return annotation: bool. No function description is provided.

Evidence: EV-714832036B08

## S3ArtifactStorage.export_directory

Function declaration. Parameters: self, job_id, version. Return annotation: unspecified. No function description is provided.

Evidence: EV-DF66E82D1EEF

## S3ArtifactStorage.read_text

Function declaration. Parameters: self, job_id, version, path. Return annotation: str. No function description is provided.

Evidence: EV-6E51A4602A62

## S3ArtifactStorage.download

Function declaration. Parameters: self, job_id, version, path. Return annotation: Download. No function description is provided.

Evidence: EV-A03C3C235B82

## S3ArtifactStorage.delete_job

Function declaration. Parameters: self, job_id. Return annotation: unspecified. No function description is provided.

Evidence: EV-D5A97EB7C8D8

## Condition in LocalArtifactStorage.root

Code evaluates: version is not None. Business intent and supported input boundaries require review.

Evidence: EV-1C8E70566379

## Condition in LocalArtifactStorage.root

Code evaluates: root.resolve() != root. Business intent and supported input boundaries require review.

Evidence: EV-D8A9F1E95AE3

## Condition in LocalArtifactStorage._path

Code evaluates: not path. Business intent and supported input boundaries require review.

Evidence: EV-52ADE0C491D7

## Condition in LocalArtifactStorage._path

Code evaluates: target.is_symlink() or not target.resolve().is_relative_to(boundary.resolve()). Business intent and supported input boundaries require review.

Evidence: EV-FEC8447A2EB0

## Condition in LocalArtifactStorage.download

Code evaluates: not target.is_file(). Business intent and supported input boundaries require review.

Evidence: EV-AFC411A60E61

## Condition in S3ArtifactStorage.__init__

Code evaluates: cfg.s3_access_key_id.get_secret_value(). Business intent and supported input boundaries require review.

Evidence: EV-B4AA3DD399BD

## Condition in storage_errors

Code evaluates: exc.response.get('Error', {}).get('Code') in {'NoSuchKey', '404', 'NotFound'}. Business intent and supported input boundaries require review.

Evidence: EV-0717922ECB8F

## Condition in LocalArtifactStorage.export_directory

Code evaluates: self.version_exists(job_id, version). Business intent and supported input boundaries require review.

Evidence: EV-2C4642156ECA

## Condition in LocalArtifactStorage.delete_job

Code evaluates: root.exists(). Business intent and supported input boundaries require review.

Evidence: EV-68264F56C677

## Condition in S3ArtifactStorage.version_exists

Code evaluates: self.client.list_objects_v2(Bucket=self.bucket, Prefix=prefix, MaxKeys=1).get('Contents'). Business intent and supported input boundaries require review.

Evidence: EV-B1F6B5D06FD7

## Condition in S3ArtifactStorage.export_directory

Code evaluates: self.version_exists(job_id, version). Business intent and supported input boundaries require review.

Evidence: EV-A653545BE035

## Condition in S3ArtifactStorage.delete_job

Code evaluates: objects. Business intent and supported input boundaries require review.

Evidence: EV-825FBA36638F

## Condition in S3ArtifactStorage.export_directory

Code evaluates: file.is_file(). Business intent and supported input boundaries require review.

Evidence: EV-A88E0AD83A2F

## Condition in S3ArtifactStorage.delete_job

Code evaluates: result.get('Errors'). Business intent and supported input boundaries require review.

Evidence: EV-38ACE9BC7356

## analyze_task

Function declaration. Parameters: job_id. Return annotation: unspecified. No function description is provided.

Evidence: EV-EBF97153B1F9

## cleanup_task

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-3872B9AD15E1

## recover_task

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-5BD1A314236F

## baseline

Function declaration. Parameters: analysis. Return annotation: unspecified. No function description is provided.

Evidence: EV-3BDF183FC2AA

## workflow

Function declaration. Parameters: db, job. Return annotation: unspecified. No function description is provided.

Evidence: EV-B10DD1FCC616

## Condition in workflow

Code evaluates: result.baseline_hash == job.baseline_hash. Business intent and supported input boundaries require review.

Evidence: EV-85E27A06F1D7

## Condition in workflow

Code evaluates: review.stage == 'requirements' and review.baseline_hash == job.baseline_hash and (review.decision != 'comment'). Business intent and supported input boundaries require review.

Evidence: EV-04AA73A5A431

## Condition in workflow

Code evaluates: review.stage == 'uat' and review.baseline_hash == acceptance_hash and (review.decision != 'comment'). Business intent and supported input boundaries require review.

Evidence: EV-13F10C93925B

## upgrade

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-9C8E460438A5

## downgrade

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-BB2ADBCEE990

## sa.Column

Schema or validation declaration: sa.Column('id', sa.String(64), primary_key=True)

Evidence: EV-2BF1EE29CBD4

## sa.Column

Schema or validation declaration: sa.Column('owner', sa.String(100), nullable=False)

Evidence: EV-D8C50DB19C2C, EV-61343276FE97

## sa.Column

Schema or validation declaration: sa.Column('login', sa.String(100), nullable=False)

Evidence: EV-B02932125E31, EV-C8655FC643BB

## sa.Column

Schema or validation declaration: sa.Column('token', sa.Text(), nullable=False)

Evidence: EV-540519E37A9A

## sa.Column

Schema or validation declaration: sa.Column('csrf', sa.String(100), nullable=False)

Evidence: EV-52F499CADB32

## sa.Column

Schema or validation declaration: sa.Column('oauth_state', sa.String(100), nullable=False)

Evidence: EV-543A9D39BAEA

## sa.Column

Schema or validation declaration: sa.Column('oauth_verifier', sa.String(150), nullable=False)

Evidence: EV-D6E506CDDCF6

## sa.Column

Schema or validation declaration: sa.Column('oauth_started', sa.DateTime())

Evidence: EV-1EACD2C63DA2

## sa.Column

Schema or validation declaration: sa.Column('expires', sa.DateTime(), nullable=False)

Evidence: EV-70D5B4AE0368

## sa.Column

Schema or validation declaration: sa.Column('id', sa.String(36), primary_key=True)

Evidence: EV-395680D066C2

## sa.Column

Schema or validation declaration: sa.Column('repository', sa.String(200), nullable=False)

Evidence: EV-65954083C368

## sa.Column

Schema or validation declaration: sa.Column('status', sa.String(30), nullable=False)

Evidence: EV-DC77CA3343F9, EV-C329BEC12BC7

## sa.Column

Schema or validation declaration: sa.Column('progress', sa.Integer(), nullable=False)

Evidence: EV-1F8755643A58

## sa.Column

Schema or validation declaration: sa.Column('message', sa.Text(), nullable=False)

Evidence: EV-42C802C3E5DD

## sa.Column

Schema or validation declaration: sa.Column('config', sa.JSON(), nullable=False)

Evidence: EV-085C5EEC1D1D

## sa.Column

Schema or validation declaration: sa.Column('analysis', sa.JSON())

Evidence: EV-0ADBEBBC6A28

## sa.Column

Schema or validation declaration: sa.Column('baseline_hash', sa.String(64), nullable=False)

Evidence: EV-51CF5BFD5F3B, EV-04655794F0FA, EV-3112CF30EF34

## sa.Column

Schema or validation declaration: sa.Column('version', sa.Integer(), nullable=False)

Evidence: EV-C2CA6C8826CE

## sa.Column

Schema or validation declaration: sa.Column('created', sa.DateTime(), nullable=False)

Evidence: EV-7D49CD7389E7, EV-D44B94CE8513, EV-1A6EF9F48321, EV-7576DC2BB62E, EV-75D98340551D

## sa.Column

Schema or validation declaration: sa.Column('updated', sa.DateTime(), nullable=False)

Evidence: EV-FB388A59997E, EV-AD1E452F835C

## sa.Column

Schema or validation declaration: sa.Column('credential', sa.Text(), nullable=False)

Evidence: EV-8F8DB9BF9746

## sa.Column

Schema or validation declaration: sa.Column('worker_id', sa.String(36), nullable=False)

Evidence: EV-4D1F1FBC8B04

## sa.Column

Schema or validation declaration: sa.Column('lease_until', sa.DateTime())

Evidence: EV-297DC946B12D

## sa.Column

Schema or validation declaration: sa.Column('job_id', sa.String(36), sa.ForeignKey('jobs.id', ondelete='CASCADE'), primary_key=True)

Evidence: EV-C6BEA3395AF9

## sa.Column

Schema or validation declaration: sa.Column('principal', sa.String(100), primary_key=True)

Evidence: EV-775DA5802147

## sa.Column

Schema or validation declaration: sa.Column('role', sa.String(20), nullable=False)

Evidence: EV-895539B56D4E

## sa.Column

Schema or validation declaration: sa.Column('id', sa.Integer(), primary_key=True)

Evidence: EV-519D779EDE61, EV-94616B0DBB48, EV-996CF623C337

## sa.Column

Schema or validation declaration: sa.Column('job_id', sa.String(36), sa.ForeignKey('jobs.id', ondelete='CASCADE'), nullable=False)

Evidence: EV-BAEF9513AADB, EV-E4B22C78E1D2, EV-E17155C9F49F

## sa.Column

Schema or validation declaration: sa.Column('stage', sa.String(30), nullable=False)

Evidence: EV-DD54492ACB5A

## sa.Column

Schema or validation declaration: sa.Column('decision', sa.String(30), nullable=False)

Evidence: EV-1C3167B3FA90

## sa.Column

Schema or validation declaration: sa.Column('reviewer', sa.String(100), nullable=False)

Evidence: EV-B11A03F9C66A, EV-36B965C86121

## sa.Column

Schema or validation declaration: sa.Column('comment', sa.Text(), nullable=False)

Evidence: EV-0C705FD85586

## sa.Column

Schema or validation declaration: sa.Column('test_case_id', sa.String(80), nullable=False)

Evidence: EV-E7D0DD7328DF

## sa.Column

Schema or validation declaration: sa.Column('source', sa.String(30), nullable=False)

Evidence: EV-17382FC9B50B

## sa.Column

Schema or validation declaration: sa.Column('actual', sa.Text(), nullable=False)

Evidence: EV-ED04147D7D07

## sa.Column

Schema or validation declaration: sa.Column('evidence_reference', sa.Text(), nullable=False)

Evidence: EV-B65A9FCD2AB4

## sa.Column

Schema or validation declaration: sa.Column('severity', sa.String(20), nullable=False)

Evidence: EV-BBD49ECD4647

## sa.Column

Schema or validation declaration: sa.Column('actor', sa.String(100), nullable=False)

Evidence: EV-2478794A1F64

## sa.Column

Schema or validation declaration: sa.Column('action', sa.String(100), nullable=False)

Evidence: EV-88972F2AACCA

## sa.Column

Schema or validation declaration: sa.Column('detail', sa.JSON(), nullable=False)

Evidence: EV-1A50EE194E24

## sa.Column

Schema or validation declaration: sa.Column('key', sa.String(64), primary_key=True)

Evidence: EV-AAB54CA1DB75

## sa.Column

Schema or validation declaration: sa.Column('payload', sa.JSON(), nullable=False)

Evidence: EV-B8C8311C4C4B

## sa.ForeignKey

Schema or validation declaration: sa.ForeignKey('jobs.id', ondelete='CASCADE')

Evidence: EV-B10A08B7DD3A, EV-43BAE26E9A8F, EV-D546D1D4F045, EV-A671E15BD708

## upgrade

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-A56B291D52D4

## downgrade

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-F9F49CAF6930

## op.execute

Call to op.execute may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-5AD35729C964

## sa.Column

Schema or validation declaration: sa.Column('job_id', sa.String(36), sa.ForeignKey('jobs.id', ondelete='CASCADE'), primary_key=True)

Evidence: EV-AE448CB2D80E

## sa.Column

Schema or validation declaration: sa.Column('version', sa.Integer(), primary_key=True)

Evidence: EV-1F978955B9B2

## sa.Column

Schema or validation declaration: sa.Column('baseline_hash', sa.String(64), nullable=False)

Evidence: EV-BA7280D56FEB

## sa.Column

Schema or validation declaration: sa.Column('package_sha256', sa.String(64), nullable=False)

Evidence: EV-8F7552D9D705

## sa.Column

Schema or validation declaration: sa.Column('created', sa.DateTime(), nullable=False)

Evidence: EV-6FCB8BB4C9F6

## sa.ForeignKey

Schema or validation declaration: sa.ForeignKey('jobs.id', ondelete='CASCADE')

Evidence: EV-55674BCB1046

## upgrade

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-71C851914463

## downgrade

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-292A86A3BDD7

## sa.Column

Schema or validation declaration: sa.Column('resolved_commit', sa.String(40), nullable=False, server_default='')

Evidence: EV-84BE369B4E84

## upgrade

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-C732E53F55EB

## downgrade

Function declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-2F29A65D13DA

## sa.Column

Schema or validation declaration: sa.Column('id', sa.Integer(), primary_key=True)

Evidence: EV-0CD185A9C208

## examples/inventory/Dockerfile

Deployment configuration exists; deployment execution and environment are not verified.

Evidence: EV-601EE49876A7

## FROM python:3.12-slim

Container declaration: FROM python:3.12-slim

Evidence: EV-533B043EB4E6

## EXPOSE 8000

Container declaration: EXPOSE 8000

Evidence: EV-0B39940B306C

## CMD ["uvicorn", "app:app", "--host", "0.0.0.0"]

Container declaration: CMD ["uvicorn", "app:app", "--host", "0.0.0.0"]

Evidence: EV-567CD7E72698

## Docker

Container build configuration exists.

Evidence: EV-B75DCBACB7E8

## Repository stated purpose

# Inventory service demo

This small fixture models a stock catalogue. Staff can list products and reserve
available stock. A reservation must have a positive quantity and cannot exceed
available stock. It is deliberately incomplete: persistence is in memory and
production authorization is not implemented. It is used to demonstrate the
documentation agent without GitHub credentials or an LLM API key.


Evidence: EV-21A1142E8766

## Reservation

Class bases: BaseModel. Annotated fields: sku, quantity. Persistence cannot be concluded from class naming alone.

Evidence: EV-200BBFE2C65A

## list_products

Function declaration. Parameters: none. Return annotation: dict[str, int]. Return the catalogue and available quantity for each product.

Evidence: EV-CA16855F18C4

## GET /products

Decorator declares GET /products, handled by list_products. Router mount prefixes and runtime middleware require verification.

Evidence: EV-AC8AD8AB1C7C

## reserve_product

Function declaration. Parameters: request. Return annotation: unspecified. Reserve stock when the product exists and enough quantity is available.

Evidence: EV-345CF8F4F422

## POST /reservations

Decorator declares POST /reservations, handled by reserve_product. Router mount prefixes and runtime middleware require verification.

Evidence: EV-2BE0E4A409EE

## Condition in reserve_product

Code evaluates: request.sku not in stock. Business intent and supported input boundaries require review.

Evidence: EV-5A2E606F392B

## Condition in reserve_product

Code evaluates: request.quantity > stock[request.sku]. Business intent and supported input boundaries require review.

Evidence: EV-35467BDCCC7F

## Field

Schema or validation declaration: Field(gt=0)

Evidence: EV-F40E1895D36A

## fastapi

HTTP API framework. Declared version or constraint: >=0.115.

Evidence: EV-18A3F654CFA3

## pydantic

Declared dependency; usage requires module inspection. Declared version or constraint: >=2.10.

Evidence: EV-7DC00B9E8618

## pytest

Python testing. Declared version or constraint: >=8.

Evidence: EV-0B33ACCEA6A8

## test_catalog_contains_products

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-659D70CBFA5B

## lucide-react

Declared dependency; usage requires module inspection. Declared version or constraint: ^0.468.0.

Evidence: EV-1DC6229F6D93

## react

User interface. Declared version or constraint: ^19.0.0.

Evidence: EV-3A3E28901B0A

## react-dom

Declared dependency; usage requires module inspection. Declared version or constraint: ^19.0.0.

Evidence: EV-4B9289E5DBDA

## react-markdown

Declared dependency; usage requires module inspection. Declared version or constraint: ^10.0.0.

Evidence: EV-C53CA2AFA97B

## remark-gfm

Declared dependency; usage requires module inspection. Declared version or constraint: ^4.0.0.

Evidence: EV-E13CCAD40C43

## @testing-library/jest-dom

Declared dependency; usage requires module inspection. Declared version or constraint: ^7.0.1.

Evidence: EV-FE132CEE8653

## @testing-library/react

Declared dependency; usage requires module inspection. Declared version or constraint: ^16.3.3.

Evidence: EV-DB871E70F0A8

## @testing-library/user-event

Declared dependency; usage requires module inspection. Declared version or constraint: ^14.6.12.

Evidence: EV-B0C00281EF28

## @types/react

Declared dependency; usage requires module inspection. Declared version or constraint: ^19.0.0.

Evidence: EV-A4B544753895

## @types/react-dom

Declared dependency; usage requires module inspection. Declared version or constraint: ^19.0.0.

Evidence: EV-B857FE2FB376

## @vitejs/plugin-react

Declared dependency; usage requires module inspection. Declared version or constraint: ^4.4.0.

Evidence: EV-AC4723660053

## jsdom

Declared dependency; usage requires module inspection. Declared version or constraint: ^26.1.0.

Evidence: EV-3E3F600036B7

## prettier

Declared dependency; usage requires module inspection. Declared version or constraint: ^3.5.0.

Evidence: EV-6BF46E504F0B

## typescript

Declared dependency; usage requires module inspection. Declared version or constraint: ~5.8.0.

Evidence: EV-82FCA2D0021F

## vite

Declared dependency; usage requires module inspection. Declared version or constraint: ^6.2.0.

Evidence: EV-EDF5329227A1

## vitest

JavaScript testing. Declared version or constraint: ^3.0.0.

Evidence: EV-6758AF8AA44D

## npm run dev

Declared script: vite --host 127.0.0.1

Evidence: EV-38DF9E132199

## npm run build

Declared script: tsc -b && vite build

Evidence: EV-7027CA0CE3CF

## npm run preview

Declared script: vite preview --host 127.0.0.1

Evidence: EV-C812BE2678EB

## npm run test

Declared script: vitest run

Evidence: EV-1745ED584C04

## App

function declaration found by syntax parser.

Evidence: EV-219CFA07936B

## act

function declaration found by syntax parser.

Evidence: EV-E80B16EC7CA3

## openJob

function declaration found by syntax parser.

Evidence: EV-14A54721B458

## demo

function declaration found by syntax parser.

Evidence: EV-E32C7E53EA90

## choose

function declaration found by syntax parser.

Evidence: EV-463AD9602143

## openRepository

function declaration found by syntax parser.

Evidence: EV-4EF1BB88041D

## account

function declaration found by syntax parser.

Evidence: EV-19605DFEACF1

## setCsrf

function declaration found by syntax parser.

Evidence: EV-F24E72B3EFCE

## api

function declaration found by syntax parser.

Evidence: EV-8A3B0646FA3F

## repositoryName

function declaration found by syntax parser.

Evidence: EV-78C69687E76A

## Session

interface declaration found by syntax parser.

Evidence: EV-024CDC5D5D2C

## Repository

interface declaration found by syntax parser.

Evidence: EV-2D8D708DD940

## Evidence

interface declaration found by syntax parser.

Evidence: EV-72448CFF5C29

## Requirement

interface declaration found by syntax parser.

Evidence: EV-F863B15C3C52

## Case

interface declaration found by syntax parser.

Evidence: EV-0394B66DAC40

## Finding

interface declaration found by syntax parser.

Evidence: EV-5C2C1E5A8C7F

## TestResult

interface declaration found by syntax parser.

Evidence: EV-28E9932C002F

## Workflow

interface declaration found by syntax parser.

Evidence: EV-C60B723C3ED3

## Analysis

interface declaration found by syntax parser.

Evidence: EV-66BA1702ACFF

## Job

interface declaration found by syntax parser.

Evidence: EV-571A2FBB08B0

## Artifact

interface declaration found by syntax parser.

Evidence: EV-8DF534F1227B

## AuditEntry

interface declaration found by syntax parser.

Evidence: EV-12580CD493D6

## AccessPanel

function declaration found by syntax parser.

Evidence: EV-7165A82E8C2B

## AppShell

function declaration found by syntax parser.

Evidence: EV-AD43EB8873B0

## AuthDialog

function declaration found by syntax parser.

Evidence: EV-2637070F4FE9

## Configure

function declaration found by syntax parser.

Evidence: EV-017942286ED4

## EditModal

function declaration found by syntax parser.

Evidence: EV-1C7B84F7675E

## EvidenceList

function declaration found by syntax parser.

Evidence: EV-FC0E3FA411B8

## Modal

function declaration found by syntax parser.

Evidence: EV-48F97AA590D2

## reportJob

function declaration found by syntax parser.

Evidence: EV-C92A442C9399

## Report

function declaration found by syntax parser.

Evidence: EV-91EB36056591

## mutate

function declaration found by syntax parser.

Evidence: EV-15451DFC4D2C

## ResultModal

function declaration found by syntax parser.

Evidence: EV-48F1C1F68C93

## ReviewModal

function declaration found by syntax parser.

Evidence: EV-EDE6D4E3279C

## ActivityTab

function declaration found by syntax parser.

Evidence: EV-239316FEFF4F

## AnalysisProgress

function declaration found by syntax parser.

Evidence: EV-A26BBBAE4AC4

## DiagramsTab

function declaration found by syntax parser.

Evidence: EV-51BB247E1687

## DocumentsTab

function declaration found by syntax parser.

Evidence: EV-84DA533F6AA8

## OverviewTab

function declaration found by syntax parser.

Evidence: EV-B6C49F2D09E2

## RecordControls

interface declaration found by syntax parser.

Evidence: EV-90C30FB9EA15

## RecordsPanel

function declaration found by syntax parser.

Evidence: EV-374B7239E1A3

## ReportHeader

function declaration found by syntax parser.

Evidence: EV-27FCA5C2E5CB

## RequirementsTab

function declaration found by syntax parser.

Evidence: EV-B6542F03A1E2

## TestsTab

function declaration found by syntax parser.

Evidence: EV-A83F31BDE67F

## RepositoryFilters

interface declaration found by syntax parser.

Evidence: EV-9354D1731984

## RepositoryPicker

function declaration found by syntax parser.

Evidence: EV-FF0191341242

## WorkspaceFooter

function declaration found by syntax parser.

Evidence: EV-D337FF57A046

## WorkspaceIntro

function declaration found by syntax parser.

Evidence: EV-F4A641557521

## useJobPolling

function declaration found by syntax parser.

Evidence: EV-4F9F72A1D4D3

## poll

function declaration found by syntax parser.

Evidence: EV-70573A1F7F24

## useReportArtifacts

function declaration found by syntax parser.

Evidence: EV-0CB0F65B94D8

## useRepositories

function declaration found by syntax parser.

Evidence: EV-A3573C076530

## isolated

Test declaration. Parameters: tmp_path, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-AAA9A2E18AFC

## client

Test declaration. Parameters: isolated, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-7DDEC46D10C1

## completed

Test declaration. Parameters: client. Return annotation: unspecified. No function description is provided.

Evidence: EV-2FF782F02D84

## reviewer

Test declaration. Parameters: client. Return annotation: unspecified. No function description is provided.

Evidence: EV-018A557FFB07

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-8167811A6B26

## test_concurrent_admission_cannot_exceed_limits

Test declaration. Parameters: client, monkeypatch, limit. Return annotation: unspecified. No function description is provided.

Evidence: EV-5D2C291D6A9C

## test_concurrent_admission_cannot_exceed_limits.GitHub

Class bases: none. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-9C7608AB0520

## test_concurrent_admission_cannot_exceed_limits.GitHub.__init__

Test declaration. Parameters: self, token. Return annotation: unspecified. No function description is provided.

Evidence: EV-7584831BFB66

## test_concurrent_admission_cannot_exceed_limits.GitHub.__enter__

Test declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-687F20B28F68

## test_concurrent_admission_cannot_exceed_limits.GitHub.__exit__

Test declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-D20F5B80FE96

## test_concurrent_admission_cannot_exceed_limits.GitHub.repository

Test declaration. Parameters: self, name. Return annotation: unspecified. No function description is provided.

Evidence: EV-6AAB72BC9A1A

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-646F8946AC48

## archive

Test declaration. Parameters: name, data, mode. Return annotation: unspecified. No function description is provided.

Evidence: EV-83A2EFBCF865

## test_archive_rejects_unsafe_paths

Test declaration. Parameters: tmp_path, name. Return annotation: unspecified. No function description is provided.

Evidence: EV-8C715B1F2F72

## test_archive_rejects_links_and_expansion

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-0140DFE6C4F0

## test_archive_valid

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-FE565F4355C1

## test_redaction

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-47AEFA255292

## test_python_evidence_and_no_execution

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-2FCD37B89A59

## test_tree_sitter_typescript

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-5D9BDEFCCDCA

## test_extensionless_readme_is_analyzed

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-5B46637B1E44

## test_incremental_and_stable_ids

Test declaration. Parameters: isolated. Return annotation: unspecified. No function description is provided.

Evidence: EV-814C5C2C5A55

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-E42735EE18BC

## test_csrf_and_secret_validation

Test declaration. Parameters: client. Return annotation: unspecified. No function description is provided.

Evidence: EV-BCD088D62E6A

## test_demo_exports_and_isolation

Test declaration. Parameters: client, completed. Return annotation: unspecified. No function description is provided.

Evidence: EV-12F9EFE00A83

## test_no_automatic_approval

Test declaration. Parameters: client, completed. Return annotation: unspecified. No function description is provided.

Evidence: EV-51401D06CED4

## test_baseline_edit_invalidates_approval

Test declaration. Parameters: client, completed, reviewer. Return annotation: unspecified. No function description is provided.

Evidence: EV-758800B8CBF7

## test_uat_cannot_approve_without_evidence

Test declaration. Parameters: client, completed, reviewer. Return annotation: unspecified. No function description is provided.

Evidence: EV-09738607FE32

## test_recorded_result_needs_attestation

Test declaration. Parameters: client, completed, reviewer. Return annotation: unspecified. No function description is provided.

Evidence: EV-C4A89D1C7EBD

## test_uncommitted_version_is_not_downloadable

Test declaration. Parameters: client, completed. Return annotation: unspecified. No function description is provided.

Evidence: EV-52A29F65A1A2

## test_sibling_cli_scans_have_independent_packages

Test declaration. Parameters: isolated, monkeypatch, capsys. Return annotation: unspecified. No function description is provided.

Evidence: EV-54C6366C09C5

## test_cli_does_not_overwrite_an_existing_zip

Test declaration. Parameters: isolated, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-FE76D601CD6A

## test_github_resolves_refs_and_sends_token_only_in_header

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-472DF5C7A053

## test_untrusted_archive_redirect_is_rejected

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-6AB451061CA1

## test_errors_do_not_echo_provider_response

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-2C8A42A252EC

## test_private_consent_prevents_job_creation

Test declaration. Parameters: client, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-051DD202C6EA

## test_pat_login_rotates_session_and_encrypts_token

Test declaration. Parameters: client, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-35D755BF36B9

## test_oauth_state_is_single_use_and_expires

Test declaration. Parameters: client. Return annotation: unspecified. No function description is provided.

Evidence: EV-D778CEE15C45

## test_github_resolves_refs_and_sends_token_only_in_header.handler

Test declaration. Parameters: request. Return annotation: unspecified. No function description is provided.

Evidence: EV-3261DB0C13F0

## test_python_package_roots

Test declaration. Parameters: tmp_path, source_root. Return annotation: unspecified. No function description is provided.

Evidence: EV-59F2251C716E

## test_all_relative_modules_and_package_initializers_are_retained

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-89D4DF62D28D

## test_declared_namespace_source_root

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-3EE1DE2541AE

## test_ambiguous_packages_are_not_falsely_linked

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-FEB2F1E0C927

## test_repository_root_initializer_and_source_root_precedence

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-D09187AD6055

## test_worker_recovery_reuses_the_persisted_commit

Test declaration. Parameters: isolated, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-D4760EA618C3

## test_replaced_workers_cannot_pin_commits_or_change_progress

Test declaration. Parameters: isolated. Return annotation: unspecified. No function description is provided.

Evidence: EV-E484DFCA4CAB

## test_worker_recovery_reuses_the_persisted_commit.GitHub

Class bases: none. Annotated fields: none. Persistence cannot be concluded from class naming alone.

Evidence: EV-77E4BE55A555

## test_worker_recovery_reuses_the_persisted_commit.GitHub.__init__

Test declaration. Parameters: self, token. Return annotation: unspecified. No function description is provided.

Evidence: EV-9BF8BE94D875

## test_worker_recovery_reuses_the_persisted_commit.GitHub.__enter__

Test declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-D07E990955A0

## test_worker_recovery_reuses_the_persisted_commit.GitHub.__exit__

Test declaration. Parameters: self. Return annotation: unspecified. No function description is provided.

Evidence: EV-BE72E5A29F03

## test_worker_recovery_reuses_the_persisted_commit.GitHub.repository

Test declaration. Parameters: self, repository. Return annotation: unspecified. No function description is provided.

Evidence: EV-56A9574B1E1E

## test_worker_recovery_reuses_the_persisted_commit.GitHub.resolve

Test declaration. Parameters: self, repository, ref. Return annotation: unspecified. No function description is provided.

Evidence: EV-BD5BFD1318B9

## test_worker_recovery_reuses_the_persisted_commit.GitHub.download

Test declaration. Parameters: self, repository, commit, root. Return annotation: unspecified. No function description is provided.

Evidence: EV-FB8702786012

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-DFB0596D1025

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-ACEB083AAFE0

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-04DCA0D6715E

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-C0CE1B3AAD5A

## test_compose_overrides_preserve_credentials_and_host_configuration

Test declaration. Parameters: tmp_path, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-88D492970CDF

## test_compose_generator_refuses_to_replace_host_env

Test declaration. Parameters: tmp_path, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-5E947AD528B5

## test_compose_reuses_external_infrastructure

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-F1735610A324

## test_service_errors_do_not_expose_credentials

Test declaration. Parameters: monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-5DBAA12F0504

## test_redis_probe_preserves_unrelated_keys

Test declaration. Parameters: monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-6701D6B370D7

## test_storage_probe_preserves_unrelated_artifacts

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-A3134CA89C2C

## test_service_errors_do_not_expose_credentials.fail

Test declaration. Parameters: _. Return annotation: unspecified. No function description is provided.

Evidence: EV-39E41752508E

## sample

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-1A398DC0B09A

## test_private_consent_blocks_before_call

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-BC6F73C3AAEA

## test_fallback_and_invalid_citations

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-A4A508294194

## test_unchanged_evidence_reuses_ai_cache

Test declaration. Parameters: isolated. Return annotation: unspecified. No function description is provided.

Evidence: EV-E51E48EA606E

## test_ai_scenarios_are_traceable_and_never_executed

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-D961B15392E6

## test_fallback_and_invalid_citations.invoke

Test declaration. Parameters: provider, model, prompt. Return annotation: unspecified. No function description is provided.

Evidence: EV-51F87A20AB37

## test_unchanged_evidence_reuses_ai_cache.invoke

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-D4A18B8104C1

## test_ai_scenarios_are_traceable_and_never_executed.invoke

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-86C8AA3434A8

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-740BA0E9BB82

## restore_logging

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-5A470A050F17

## test_log_level_environment_is_case_insensitive

Test declaration. Parameters: monkeypatch, value, expected. Return annotation: unspecified. No function description is provided.

Evidence: EV-372F6BF1F168

## test_invalid_log_level_is_rejected

Test declaration. Parameters: monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-2DB10BBBC7A3

## test_debug_logs_application_without_enabling_sdk_request_logging

Test declaration. Parameters: caplog. Return annotation: unspecified. No function description is provided.

Evidence: EV-6B9BA1C5FB68

## test_serve_passes_effective_level_and_keeps_access_logs_disabled

Test declaration. Parameters: isolated, monkeypatch, override, expected. Return annotation: unspecified. No function description is provided.

Evidence: EV-9F2FA56D1BC2

## test_worker_and_scheduler_forward_configured_level

Test declaration. Parameters: isolated, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-E46010316E8F

## forbid_real_redis

Test declaration. Parameters: monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-A3EB787BAF4F

## test_default_fake_client_ignores_real_url

Test declaration. Parameters: monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-1D41D0898AD8

## test_fake_queue_consumes_fifo_and_drains_on_shutdown

Test declaration. Parameters: monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-F8AE7EBB1692

## test_real_client_uses_configured_url

Test declaration. Parameters: monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-DCE6C5CAFEB6

## test_unavailable_real_redis_fails_without_silent_fallback

Test declaration. Parameters: monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-C62D16363358

## test_invalid_queue_configuration

Test declaration. Parameters: options. Return annotation: unspecified. No function description is provided.

Evidence: EV-1417E86B5D5A

## test_production_requires_real_redis

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-A66391FBEA68

## test_demo_runs_through_fake_queue_without_redis

Test declaration. Parameters: isolated, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-7FCD67673018

## forbid_real_redis.fail

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-0BB9D2AFCEC2

## test_fake_queue_consumes_fifo_and_drains_on_shutdown.handle

Test declaration. Parameters: job_id. Return annotation: unspecified. No function description is provided.

Evidence: EV-D13A002BF1FE

## test_demo_runs_through_fake_queue_without_redis.run_and_signal

Test declaration. Parameters: job_id. Return annotation: unspecified. No function description is provided.

Evidence: EV-C526D96EA61C

## test_handler_guards_form_one_traceable_requirement

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-74A538504B72

## test_models_group_constraints_and_keep_internal_helpers_in_findings

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-13886BE840A8

## test_group_ids_survive_unrelated_declarations

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-E93BCD137F7A

## test_frontend_component_tests_are_not_acceptance_requirements

Test declaration. Parameters: tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-48440F20CD38

## s3

Test declaration. Parameters: isolated, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-FBD74888A56F

## config

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-E202D46D3F82

## test_invalid_s3_settings

Test declaration. Parameters: kwargs. Return annotation: unspecified. No function description is provided.

Evidence: EV-734ECEB4ED7C

## test_minio_configuration_and_credential_chain

Test declaration. Parameters: monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-5E80B21D44ED

## test_storage_roundtrip_and_isolation

Test declaration. Parameters: backend, s3, tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-FE68650AEB64

## test_s3_generation_previews_downloads_history_and_retention

Test declaration. Parameters: s3, client, completed, reviewer, tmp_path. Return annotation: unspecified. No function description is provided.

Evidence: EV-C38C97146A15

## test_partial_upload_is_not_committed_and_retry_skips_it

Test declaration. Parameters: s3, client, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-5DDA7412E5F9

## test_s3_error_is_sanitized_and_download_scratch_is_removed

Test declaration. Parameters: s3, client, completed. Return annotation: unspecified. No function description is provided.

Evidence: EV-4461BC00049C

## test_s3_failed_review_preserves_committed_version

Test declaration. Parameters: s3, client, completed, reviewer, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-F98CBF06B81D

## test_cleanup_failure_retains_records_for_retry

Test declaration. Parameters: s3, client, completed, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-EA097B0A1FF2

## test_s3_cleanup_paginates_and_stays_in_job_prefix

Test declaration. Parameters: s3. Return annotation: unspecified. No function description is provided.

Evidence: EV-976AA7E17A17

## test_orphan_zip_reserves_version

Test declaration. Parameters: s3. Return annotation: unspecified. No function description is provided.

Evidence: EV-6096337884D4

## test_s3_version_check_uses_only_prefix_scoped_listing

Test declaration. Parameters: s3, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-C2AC809D0811

## test_partial_upload_is_not_committed_and_retry_skips_it.fail_zip

Test declaration. Parameters: filename, bucket, key. Return annotation: unspecified. No function description is provided.

Evidence: EV-A5C5D301D359

## test_s3_failed_review_preserves_committed_version.unavailable

Test declaration. Parameters: none. Return annotation: unspecified. No function description is provided.

Evidence: EV-5BCD6BB97058

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-2311B6110D0E

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-32739FBB9E38

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-4BAC91C350EC

## test_acceptance_invalidates_when_evidence_changes

Test declaration. Parameters: client, completed, reviewer. Return annotation: unspecified. No function description is provided.

Evidence: EV-28C5861FA77A

## test_shared_viewer_cannot_approve

Test declaration. Parameters: client, completed, reviewer. Return annotation: unspecified. No function description is provided.

Evidence: EV-F88CFD1DEC21

## test_stale_result_is_rejected

Test declaration. Parameters: client, completed, reviewer. Return annotation: unspecified. No function description is provided.

Evidence: EV-25AA2654774A

## test_recorded_result_and_document_versions

Test declaration. Parameters: client, completed, reviewer. Return annotation: unspecified. No function description is provided.

Evidence: EV-6C9F9D450068

## test_migrations_match_models

Test declaration. Parameters: isolated. Return annotation: unspecified. No function description is provided.

Evidence: EV-715B80CB0941

## test_expired_job_lease_is_requeued

Test declaration. Parameters: client, completed, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-540245CC25F5

## test_retention_removes_artifacts_and_records

Test declaration. Parameters: client, completed. Return annotation: unspecified. No function description is provided.

Evidence: EV-0CFDF1072481

## db.flush

Call to db.flush may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-7B053A0C1650

## db.flush

Call to db.flush may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-1E70D4A5CB3C

## db.flush

Call to db.flush may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-0E998BEA48F0

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-59A80763A514

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-C1E7C6CDD366

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-031F6029B741

## test_postgres_redis_and_celery_worker

Test declaration. Parameters: isolated, monkeypatch. Return annotation: unspecified. No function description is provided.

Evidence: EV-2953B3D158C9

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-6DB93AFEEF51

## db.commit

Call to db.commit may participate in data access. Receiver type, transaction boundaries and runtime store require verification.

Evidence: EV-5B56EB5D6C28
