# Source Evidence Register

Source citations are pinned to the inspected commit. Private repository links require access.

## EV-450BC26B67F9

EV-450BC26B67F9: Dockerfile:1-15 (file) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/Dockerfile#L1-L15]

## EV-69A4406A8ED6

EV-69A4406A8ED6: Dockerfile:1-1 (FROM node:22-bookworm-slim AS frontend) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/Dockerfile#L1-L1]

## EV-0A93A1326E99

EV-0A93A1326E99: Dockerfile:8-8 (FROM python:3.12-slim-bookworm) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/Dockerfile#L8-L8]

## EV-9562CF5CC04D

EV-9562CF5CC04D: Dockerfile:22-22 (EXPOSE 8000) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/Dockerfile#L22-L22]

## EV-ABAA0BA7A591

EV-ABAA0BA7A591: Dockerfile:24-24 (CMD ["docagent", "serve", "--host", "0.0.0.0", "--port", "8000"]) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/Dockerfile#L24-L24]

## EV-9178BCF86255

EV-9178BCF86255: Dockerfile:1-1 (file) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/Dockerfile#L1-L1]

## EV-31B5FA99AB3E

EV-31B5FA99AB3E: README.md:1-15 (file) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/README.md#L1-L15]

## EV-3FAC64468601

EV-3FAC64468601: compose.yaml:1-15 (file) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/compose.yaml#L1-L15]

## EV-19F4DF50DEA1

EV-19F4DF50DEA1: pyproject.toml:11-11 (fastapi) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L11-L11]

## EV-22EE7E3301B2

EV-22EE7E3301B2: pyproject.toml:11-11 (uvicorn) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L11-L11]

## EV-DFB8375B7A1E

EV-DFB8375B7A1E: pyproject.toml:11-11 (httpx) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L11-L11]

## EV-59988F1BCE3B

EV-59988F1BCE3B: pyproject.toml:12-12 (pydantic) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L12-L12]

## EV-6E96431C13B6

EV-6E96431C13B6: pyproject.toml:12-12 (pydantic-settings) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L12-L12]

## EV-4EB767FEF33F

EV-4EB767FEF33F: pyproject.toml:12-12 (sqlalchemy) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L12-L12]

## EV-62D8E5256CC6

EV-62D8E5256CC6: pyproject.toml:12-12 (alembic) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L12-L12]

## EV-1ADA686320F6

EV-1ADA686320F6: pyproject.toml:13-13 (cryptography) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L13-L13]

## EV-5877419F81BC

EV-5877419F81BC: pyproject.toml:13-13 (python-docx) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L13-L13]

## EV-B5612D1A5493

EV-B5612D1A5493: pyproject.toml:13-13 (openpyxl) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L13-L13]

## EV-E6CAD2809C74

EV-E6CAD2809C74: pyproject.toml:14-14 (reportlab) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L14-L14]

## EV-BAD0F5918860

EV-BAD0F5918860: pyproject.toml:14-14 (defusedxml) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L14-L14]

## EV-2BC5F5B9FE44

EV-2BC5F5B9FE44: pyproject.toml:14-14 (packaging) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L14-L14]

## EV-1B2F4DDE47C6

EV-1B2F4DDE47C6: pyproject.toml:15-15 (celery) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L15-L15]

## EV-5BB5E7FD44ED

EV-5BB5E7FD44ED: pyproject.toml:15-15 (psycopg) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L15-L15]

## EV-36B0EDF37190

EV-36B0EDF37190: pyproject.toml:16-16 (fakeredis) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L16-L16]

## EV-04297BF62645

EV-04297BF62645: pyproject.toml:15-15 (redis) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L15-L15]

## EV-1AAED348A189

EV-1AAED348A189: pyproject.toml:17-17 (boto3) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L17-L17]

## EV-C9D47E96814A

EV-C9D47E96814A: pyproject.toml:18-18 (openai) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L18-L18]

## EV-521645C26A5F

EV-521645C26A5F: pyproject.toml:18-18 (anthropic) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L18-L18]

## EV-ABA9ADDBE78F

EV-ABA9ADDBE78F: pyproject.toml:18-18 (google-genai) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L18-L18]

## EV-59011F20025A

EV-59011F20025A: pyproject.toml:19-19 (tree-sitter) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L19-L19]

## EV-742D8E167553

EV-742D8E167553: pyproject.toml:19-19 (tree-sitter-javascript) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L19-L19]

## EV-3A18201329F0

EV-3A18201329F0: pyproject.toml:20-20 (tree-sitter-typescript) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L20-L20]

## EV-D916BCB1F194

EV-D916BCB1F194: pyproject.toml:19-19 (tree-sitter-java) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L19-L19]

## EV-2EFB621F6C03

EV-2EFB621F6C03: pyproject.toml:21-21 (tree-sitter-go) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L21-L21]

## EV-A5250D9FE69F

EV-A5250D9FE69F: pyproject.toml:21-21 (PyYAML) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L21-L21]

## EV-671E2B3C389C

EV-671E2B3C389C: pyproject.toml:21-21 (pathspec) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L21-L21]

## EV-59713D11F0BB

EV-59713D11F0BB: pyproject.toml:25-25 (pytest) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L25-L25]

## EV-E6C96C77030A

EV-E6C96C77030A: pyproject.toml:25-25 (pytest-cov) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L25-L25]

## EV-1FE4AE352615

EV-1FE4AE352615: pyproject.toml:25-25 (ruff) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L25-L25]

## EV-92BD9924A8BB

EV-92BD9924A8BB: pyproject.toml:25-25 (moto) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L25-L25]

## EV-035E419975AE

EV-035E419975AE: pyproject.toml:1-1 (docagent) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/pyproject.toml#L1-L1]

## EV-F0F6AEDA68FE

EV-F0F6AEDA68FE: .github/workflows/ci.yml:1-15 (file) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/.github/workflows/ci.yml#L1-L15]

## EV-B0C5E999374E

EV-B0C5E999374E: .github/workflows/ci.yml:1-1 (file) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/.github/workflows/ci.yml#L1-L1]

## EV-1FADB2F70213

EV-1FADB2F70213: backend/docagent/analysis.py:120-121 (stable_id) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L120-L121]

## EV-9FFC4AFB4155

EV-9FFC4AFB4155: backend/docagent/analysis.py:124-138 (classify) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L124-L138]

## EV-C04A67D6F50B

EV-C04A67D6F50B: backend/docagent/analysis.py:150-164 (Collector) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L150-L164]

## EV-7A43073D2385

EV-7A43073D2385: backend/docagent/analysis.py:216-230 (python_analysis) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L216-L230]

## EV-5FBCE3C964D9

EV-5FBCE3C964D9: backend/docagent/analysis.py:436-450 (tree_analysis) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L436-L450]

## EV-EAE6296D47AB

EV-EAE6296D47AB: backend/docagent/analysis.py:512-526 (dependencies) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L512-L526]

## EV-F7E4213C6607

EV-F7E4213C6607: backend/docagent/analysis.py:573-587 (analyze_file) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L573-L587]

## EV-EAC2D60C701C

EV-EAC2D60C701C: backend/docagent/analysis.py:647-661 (scan_repository) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L647-L661]

## EV-4D7AA989DA1C

EV-4D7AA989DA1C: backend/docagent/analysis.py:775-789 (candidate_requirements) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L775-L789]

## EV-AEF32B8A12CD

EV-AEF32B8A12CD: backend/docagent/analysis.py:821-835 (generate_tests) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L821-L835]

## EV-95989256F2F4

EV-95989256F2F4: backend/docagent/analysis.py:126-134 (classify:p.name.startswith('test_') or p.name.endswith(('_test.py', '.test.ts', '.test.tsx', '.test.js', '.test.jsx', '.spec.ts', '.spec.tsx', '.spec.js', '.spec.jsx', '_test.go')) or any((x in {'tests', 'test', '__tests__'} for x in p.parts))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L126-L134]

## EV-3534357B6039

EV-3534357B6039: backend/docagent/analysis.py:135-142 (classify:'.github/workflows' in path or p.name in {'Dockerfile', 'Jenkinsfile', 'docker-compose.yml', 'compose.yaml', 'compose.yml'} or p.suffix == '.tf' or ('k8s' in p.parts) or ('helm' in p.parts)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L135-L142]

## EV-E8071F3A39A9

EV-E8071F3A39A9: backend/docagent/analysis.py:143-144 (classify:p.suffix in LANGUAGES) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L143-L144]

## EV-22C65DAE48EC

EV-22C65DAE48EC: backend/docagent/analysis.py:145-146 (classify:p.suffix == '.md' or p.name.lower() in {'readme', 'license', 'notice', 'changelog', 'contributing'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L145-L146]

## EV-FA58F8568509

EV-FA58F8568509: backend/docagent/analysis.py:151-158 (Collector.__init__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L151-L158]

## EV-F24A1A8A4852

EV-F24A1A8A4852: backend/docagent/analysis.py:160-174 (Collector.add) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L160-L174]

## EV-6A42A9D2717D

EV-6A42A9D2717D: backend/docagent/analysis.py:191-205 (Collector.dependency) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L191-L205]

## EV-AFA5729DCE0D

EV-AFA5729DCE0D: backend/docagent/analysis.py:210-213 (Collector.payload) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L210-L213]

## EV-03E8BF40CA5B

EV-03E8BF40CA5B: backend/docagent/analysis.py:227-234 (python_analysis.qualified) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L227-L234]

## EV-AD8BF756B3D5

EV-AD8BF756B3D5: backend/docagent/analysis.py:576-579 (analyze_file:p.name.lower() in {'readme', 'readme.md', 'readme.txt', 'readme.rst'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L576-L579]

## EV-9AF43684EA44

EV-9AF43684EA44: backend/docagent/analysis.py:580-585 (analyze_file:p.suffix == '.py') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L580-L585]

## EV-2EC7A0DA0FA6

EV-2EC7A0DA0FA6: backend/docagent/analysis.py:587-600 (analyze_file:classify(path) == 'deployment') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L587-L600]

## EV-841C7FB3042B

EV-841C7FB3042B: backend/docagent/analysis.py:601-611 (analyze_file:p.suffix == '.sql') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L601-L611]

## EV-66E2B77AFDC6

EV-66E2B77AFDC6: backend/docagent/analysis.py:612-626 (analyze_file:p.suffix in {'.yaml', '.yml', '.json', '.toml', '.tf'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L612-L626]

## EV-044F46AE082B

EV-044F46AE082B: backend/docagent/analysis.py:631-643 (analyze_file:p.name == 'Dockerfile') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L631-L643]

## EV-E370306142E1

EV-E370306142E1: backend/docagent/analysis.py:740-741 (scan_repository:not any((f['kind'] == 'test' for f in findings))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L740-L741]

## EV-3C3AE7012E2F

EV-3C3AE7012E2F: backend/docagent/analysis.py:165-170 (Collector.add:not any((e['id'] == eid for e in self.evidence))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L165-L170]

## EV-36A5DB668F88

EV-36A5DB668F88: backend/docagent/analysis.py:175-178 (Collector.add:existing) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L175-L178]

## EV-FE11E6B8369A

EV-FE11E6B8369A: backend/docagent/analysis.py:237-251 (python_analysis:isinstance(node, ast.Import)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L237-L251]

## EV-C4C921774305

EV-C4C921774305: backend/docagent/analysis.py:426-428 (python_analysis:enclosing) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L426-L428]

## EV-615961932F2F

EV-615961932F2F: backend/docagent/analysis.py:430-433 (python_analysis:classes) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L430-L433]

## EV-FC855AB9F2BA

EV-FC855AB9F2BA: backend/docagent/analysis.py:441-455 (tree_analysis:extension in {'.js', '.jsx'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L441-L455]

## EV-6DAE9C8F03F2

EV-6DAE9C8F03F2: backend/docagent/analysis.py:458-459 (tree_analysis:tree.root_node.has_error) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L458-L459]

## EV-25CDBDDB58F4

EV-25CDBDDB58F4: backend/docagent/analysis.py:515-529 (dependencies:name == 'package.json') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L515-L529]

## EV-59B963896CD7

EV-59B963896CD7: backend/docagent/analysis.py:582-585 (analyze_file:p.suffix in {'.js', '.jsx', '.ts', '.tsx', '.java', '.go'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L582-L585]

## EV-287D4A22E2ED

EV-287D4A22E2ED: backend/docagent/analysis.py:595-600 (analyze_file:p.name == 'Dockerfile') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L595-L600]

## EV-1D7E8F858FFE

EV-1D7E8F858FFE: backend/docagent/analysis.py:655-656 (scan_repository:path.is_file() and (not path.is_symlink()) and (path.stat().st_size < 100000)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L655-L656]

## EV-F2011063A624

EV-F2011063A624: backend/docagent/analysis.py:784-785 (candidate_requirements:finding['kind'] not in relevant) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L784-L785]

## EV-FC884F20A3AB

EV-FC884F20A3AB: backend/docagent/analysis.py:788-789 (candidate_requirements:classify(path) == 'test') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L788-L789]

## EV-FC175FBB8A33

EV-FC175FBB8A33: backend/docagent/analysis.py:792-793 (candidate_requirements:not scope and finding['kind'] in {'function', 'data_model'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L792-L793]

## EV-FB349F01303A

EV-FB349F01303A: backend/docagent/analysis.py:795-796 (candidate_requirements:metadata.get('class_scope') and (not is_route)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L795-L796]

## EV-C2094953969C

EV-C2094953969C: backend/docagent/analysis.py:797-798 (candidate_requirements:scope and (not is_route) and any((part.startswith('_') for part in scope.split('.')))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L797-L798]

## EV-CDEADC36519B

EV-CDEADC36519B: backend/docagent/analysis.py:176-177 (Collector.add:eid not in existing['evidence_ids']) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L176-L177]

## EV-D25BCF15CC00

EV-D25BCF15CC00: backend/docagent/analysis.py:231-232 (python_analysis.qualified:isinstance(parent, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L231-L232]

## EV-33E5C2A8E3AA

EV-33E5C2A8E3AA: backend/docagent/analysis.py:240-254 (python_analysis:isinstance(node, ast.ImportFrom)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L240-L254]

## EV-CEFD523D8DC4

EV-CEFD523D8DC4: backend/docagent/analysis.py:445-456 (tree_analysis:extension in {'.ts', '.tsx'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L445-L456]

## EV-E0EFD4FC9396

EV-E0EFD4FC9396: backend/docagent/analysis.py:464-478 (tree_analysis:node.type in {'function_declaration', 'method_definition', 'method_declaration', 'function_definition', 'class_declaration', 'interface_declaration', 'type_declaration'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L464-L478]

## EV-BB2364CD5443

EV-BB2364CD5443: backend/docagent/analysis.py:523-537 (dependencies:name == 'pyproject.toml') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L523-L537]

## EV-A3F00053F493

EV-A3F00053F493: backend/docagent/analysis.py:584-585 (analyze_file:p.suffix in LANGUAGES and p.suffix not in {'.sql', '.html', '.css'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L584-L585]

## EV-223126DEF438

EV-223126DEF438: backend/docagent/analysis.py:618-630 (analyze_file:re.search(pattern, text) and (name != 'GitHub Actions' or '.github/workflows' in path)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L618-L630]

## EV-8671247BAD13

EV-8671247BAD13: backend/docagent/analysis.py:675-677 (scan_repository:file.is_symlink() or secret_path(relative) or spec.match_file(relative)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L675-L677]

## EV-1AF0DFF3DCA4

EV-1AF0DFF3DCA4: backend/docagent/analysis.py:678-692 (scan_repository:file.suffix.lower() not in TEXT_EXTENSIONS and filename.lower() not in {'dockerfile', 'jenkinsfile', 'go.mod', 'gemfile', 'readme', 'license', 'notice', 'changelog', 'contributing', '.gitignore', '.dockerignore', 'makefile', 'procfile', '.editorconfig'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L678-L692]

## EV-2B0C8408FCEC

EV-2B0C8408FCEC: backend/docagent/analysis.py:697-699 (scan_repository:size > cfg.max_file_bytes) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L697-L699]

## EV-43425315490D

EV-43425315490D: backend/docagent/analysis.py:700-705 (scan_repository:scanned >= limit or total_bytes + size > byte_limit) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L700-L705]

## EV-F488E5758236

EV-F488E5758236: backend/docagent/analysis.py:707-709 (scan_repository:b'\x00' in raw) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L707-L709]

## EV-4280C2873086

EV-4280C2873086: backend/docagent/analysis.py:725-731 (scan_repository:cached) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L725-L731]

## EV-6E78E5211187

EV-6E78E5211187: backend/docagent/analysis.py:736-737 (scan_repository:progress and scanned % 100 == 0) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L736-L737]

## EV-776B47B544F3

EV-776B47B544F3: backend/docagent/analysis.py:806-807 (candidate_requirements:item is not anchor and item['kind'] != 'function' and (item['detail'] not in details)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L806-L807]

## EV-1CA436C8346B

EV-1CA436C8346B: backend/docagent/analysis.py:249-263 (python_analysis:isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L249-L263]

## EV-DAED1A146C96

EV-DAED1A146C96: backend/docagent/analysis.py:449-456 (tree_analysis:extension == '.java') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L449-L456]

## EV-68588D1A958A

EV-68588D1A958A: backend/docagent/analysis.py:474-488 (tree_analysis:name) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L474-L488]

## EV-9615AAD59743

EV-9615AAD59743: backend/docagent/analysis.py:541-555 (dependencies:name.startswith('requirements') and name.endswith('.txt')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L541-L555]

## EV-2D9DF888A697

EV-2D9DF888A697: backend/docagent/analysis.py:597-600 (analyze_file:re.match('(?i)^(FROM|EXPOSE|ENTRYPOINT|CMD)\\s', line)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L597-L600]

## EV-991C7D3B4678

EV-991C7D3B4678: backend/docagent/analysis.py:730-731 (scan_repository:db is not None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L730-L731]

## EV-D5EC9F4BDFA3

EV-D5EC9F4BDFA3: backend/docagent/analysis.py:301-315 (python_analysis:isinstance(node, ast.ClassDef)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L301-L315]

## EV-3A8E3C690096

EV-3A8E3C690096: backend/docagent/analysis.py:481-482 (tree_analysis:classify(c.path) == 'test') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L481-L482]

## EV-479C191B3F3B

EV-479C191B3F3B: backend/docagent/analysis.py:548-562 (dependencies:name == 'cargo.toml') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L548-L562]

## EV-51D29A2CC1A5

EV-51D29A2CC1A5: backend/docagent/analysis.py:265-279 (python_analysis:isinstance(deco, ast.Call) and isinstance(deco.func, ast.Attribute)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L265-L279]

## EV-EAC42E96EEA8

EV-EAC42E96EEA8: backend/docagent/analysis.py:318-332 (python_analysis:isinstance(node, (ast.If, ast.Assert)) and classify(c.path) != 'test') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L318-L332]

## EV-E45319DDBCCA

EV-E45319DDBCCA: backend/docagent/analysis.py:553-567 (dependencies:name == 'go.mod') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L553-L567]

## EV-73CE8BFF6C45

EV-73CE8BFF6C45: backend/docagent/analysis.py:267-281 (python_analysis:method in {'get', 'post', 'put', 'patch', 'delete', 'options', 'head', 'route', 'websocket'} and deco.args and isinstance(deco.args[0], ast.Constant) and isinstance(deco.args[0].value, str)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L267-L281]

## EV-D9790A4496C1

EV-D9790A4496C1: backend/docagent/analysis.py:323-332 (python_analysis:owner) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L323-L332]

## EV-FCB77EDC4B49

EV-FCB77EDC4B49: backend/docagent/analysis.py:333-347 (python_analysis:isinstance(node, ast.Call)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L333-L347]

## EV-3B8BAC62A01F

EV-3B8BAC62A01F: backend/docagent/analysis.py:558-568 (dependencies:name == 'pom.xml') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L558-L568]

## EV-00A4DC732935

EV-00A4DC732935: backend/docagent/analysis.py:276-284 (python_analysis:method == 'route') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L276-L284]

## EV-E185F91A0773

EV-E185F91A0773: backend/docagent/analysis.py:335-344 (python_analysis:name.split('.')[-1] in {'Depends', 'Security'} and node.args) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L335-L344]

## EV-F6E8EF69BA3C

EV-F6E8EF69BA3C: backend/docagent/analysis.py:345-354 (python_analysis:name.split('.')[-1] in {'Field', 'Column', 'mapped_column', 'relationship', 'ForeignKey'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L345-L354]

## EV-FAAD80868B11

EV-FAAD80868B11: backend/docagent/analysis.py:355-369 (python_analysis:isinstance(node.func, ast.Attribute) and node.func.attr in {'execute', 'query', 'commit', 'flush', 'save', 'insert_one', 'find_one', 'bulk_write'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L355-L369]

## EV-C4AD50B1CA41

EV-C4AD50B1CA41: backend/docagent/analysis.py:374-388 (python_analysis:any((word in name.lower() for word in ('authenticate', 'authorize', 'require_user', 'require_role', 'hashpw', 'jwt.decode', 'verify_password')))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L374-L388]

## EV-D8F483B6D29F

EV-D8F483B6D29F: backend/docagent/analysis.py:394-408 (python_analysis:re.search('(?:requests|httpx|client|session)\\.(get|post|put|delete|patch|request)$', name) and node.args) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L394-L408]

## EV-CC9E1536880F

EV-CC9E1536880F: backend/docagent/analysis.py:556-557 (dependencies:m) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L556-L557]

## EV-C6570A454D37

EV-C6570A454D37: backend/docagent/analysis.py:398-412 (python_analysis:isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str) and node.args[0].value.startswith('https://')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L398-L412]

## EV-2BF1FE1640C2

EV-2BF1FE1640C2: backend/docagent/analysis.py:565-568 (dependencies:artifact) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L565-L568]

## EV-5D6A3BDA7EA1

EV-5D6A3BDA7EA1: backend/docagent/analysis.py:279-284 (python_analysis:kw.arg == 'methods' and isinstance(kw.value, (ast.List, ast.Tuple))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/analysis.py#L279-L284]

## EV-D22453B5F87D

EV-D22453B5F87D: backend/docagent/api.py:67-81 (lifespan) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L67-L81]

## EV-DA1F96D99C74

EV-DA1F96D99C74: backend/docagent/api.py:93-95 (get_db) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L93-L95]

## EV-D5769066A95B

EV-D5769066A95B: backend/docagent/api.py:101-113 (user_session) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L101-L113]

## EV-EC94F9E62B6E

EV-EC94F9E62B6E: backend/docagent/api.py:119-127 (owner_job) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L119-L127]

## EV-883962E5F64D

EV-883962E5F64D: backend/docagent/api.py:130-132 (require_complete) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L130-L132]

## EV-3822461701CE

EV-3822461701CE: backend/docagent/api.py:135-140 (can_review) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L135-L140]

## EV-82A20ADC73B2

EV-82A20ADC73B2: backend/docagent/api.py:143-145 (require_reviewer) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L143-L145]

## EV-86EE08D58D5C

EV-86EE08D58D5C: backend/docagent/api.py:148-157 (set_cookie) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L148-L157]

## EV-A484F47246DC

EV-A484F47246DC: backend/docagent/api.py:160-171 (create_session) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L160-L171]

## EV-4CE5D4B06B5D

EV-4CE5D4B06B5D: backend/docagent/api.py:174-188 (connect_user) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L174-L188]

## EV-C459A6FB8876

EV-C459A6FB8876: backend/docagent/api.py:194-208 (job_view) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L194-L208]

## EV-7246DA27B3B2

EV-7246DA27B3B2: backend/docagent/api.py:220-221 (PATInput) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L220-L221]

## EV-ED4A8475DF1E

EV-ED4A8475DF1E: backend/docagent/api.py:224-238 (create_app) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L224-L238]

## EV-AD122B118A4A

EV-AD122B118A4A: backend/docagent/api.py:69-74 (lifespan:settings().env == 'production') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L69-L74]

## EV-5DFDC6E8196F

EV-5DFDC6E8196F: backend/docagent/api.py:75-81 (lifespan:settings().job_backend == 'local') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L75-L81]

## EV-BFC3BABEC92D

EV-BFC3BABEC92D: backend/docagent/api.py:84-85 (lifespan:local) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L84-L85]

## EV-34C7300F59A0

EV-34C7300F59A0: backend/docagent/api.py:104-105 (user_session:session is None or session.expires < now()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L104-L105]

## EV-1D78914EB6EF

EV-1D78914EB6EF: backend/docagent/api.py:106-112 (user_session:request.method not in {'GET', 'HEAD', 'OPTIONS'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L106-L112]

## EV-A16F720E461E

EV-A16F720E461E: backend/docagent/api.py:122-123 (owner_job:lock) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L122-L123]

## EV-1373931991FE

EV-1373931991FE: backend/docagent/api.py:125-126 (owner_job:job is None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L125-L126]

## EV-F840BF5C1046

EV-F840BF5C1046: backend/docagent/api.py:131-132 (require_complete:job.status != 'completed') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L131-L132]

## EV-8E73D0B71C3D

EV-8E73D0B71C3D: backend/docagent/api.py:137-138 (can_review:not user.login or user.login.casefold() not in names) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L137-L138]

## EV-3100548286D9

EV-3100548286D9: backend/docagent/api.py:144-145 (require_reviewer:not can_review(user, db, job)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L144-L145]

## EV-E94863AAAC86

EV-E94863AAAC86: backend/docagent/api.py:176-178 (connect_user:session.owner.startswith('anonymous:')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L176-L178]

## EV-B2F1DFA1368D

EV-B2F1DFA1368D: backend/docagent/api.py:206-216 (job_view:full) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L206-L216]

## EV-CEE60806FE0A

EV-CEE60806FE0A: backend/docagent/api.py:230-244 (create_app.security_headers) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L230-L244]

## EV-C931D4B17A06

EV-C931D4B17A06: backend/docagent/api.py:258-268 (create_app.validation_error) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L258-L268]

## EV-74B43C9C8489

EV-74B43C9C8489: backend/docagent/api.py:271-272 (create_app.github_error) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L271-L272]

## EV-CAE937DE3809

EV-CAE937DE3809: backend/docagent/api.py:275-278 (create_app.storage_error) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L275-L278]

## EV-AF4A575C030D

EV-AF4A575C030D: backend/docagent/api.py:281-282 (create_app.invalid_artifact_path) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L281-L282]

## EV-D934B6CC2F8B

EV-D934B6CC2F8B: backend/docagent/api.py:285-287 (create_app.health) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L285-L287]

## EV-A61F2683D120

EV-A61F2683D120: backend/docagent/api.py:284-287 (create_app.health:GET:/api/health) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L284-L287]

## EV-AA8C4F518310

EV-AA8C4F518310: backend/docagent/api.py:290-304 (create_app.session_info) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L290-L304]

## EV-FB9C3E876DFB

EV-FB9C3E876DFB: backend/docagent/api.py:289-303 (create_app.session_info:GET:/api/session) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L289-L303]

## EV-02A3FFE410DB

EV-02A3FFE410DB: backend/docagent/api.py:313-318 (create_app.authenticate) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L313-L318]

## EV-9D981D475B51

EV-9D981D475B51: backend/docagent/api.py:312-318 (create_app.authenticate:POST:/api/auth/pat) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L312-L318]

## EV-5E76C8CA69AC

EV-5E76C8CA69AC: backend/docagent/api.py:321-325 (create_app.logout) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L321-L325]

## EV-524A8084553C

EV-524A8084553C: backend/docagent/api.py:320-325 (create_app.logout:POST:/api/auth/logout) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L320-L325]

## EV-C79DEC7861D5

EV-C79DEC7861D5: backend/docagent/api.py:328-342 (create_app.oauth_start) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L328-L342]

## EV-9985B4B42280

EV-9985B4B42280: backend/docagent/api.py:327-341 (create_app.oauth_start:GET:/api/auth/github/start) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L327-L341]

## EV-FD52A6490417

EV-FD52A6490417: backend/docagent/api.py:351-365 (create_app.oauth_callback) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L351-L365]

## EV-0F6D0CA3CB32

EV-0F6D0CA3CB32: backend/docagent/api.py:350-364 (create_app.oauth_callback:GET:/api/auth/github/callback) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L350-L364]

## EV-D1D6DBED4E8E

EV-D1D6DBED4E8E: backend/docagent/api.py:388-392 (create_app.repositories) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L388-L392]

## EV-0A6F8BF3F634

EV-0A6F8BF3F634: backend/docagent/api.py:387-392 (create_app.repositories:GET:/api/repositories) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L387-L392]

## EV-EDF5F7A9C5A2

EV-EDF5F7A9C5A2: backend/docagent/api.py:395-398 (create_app.repository) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L395-L398]

## EV-F7EB788309AD

EV-F7EB788309AD: backend/docagent/api.py:394-398 (create_app.repository:GET:/api/repositories/{owner}/{name}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L394-L398]

## EV-8DACC9A157BE

EV-8DACC9A157BE: backend/docagent/api.py:401-410 (create_app.refs) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L401-L410]

## EV-A508170852F2

EV-A508170852F2: backend/docagent/api.py:400-410 (create_app.refs:GET:/api/repositories/{owner}/{name}/refs) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L400-L410]

## EV-6642A081F458

EV-6642A081F458: backend/docagent/api.py:412-426 (create_app.start_job) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L412-L426]

## EV-4B8493C1F5AD

EV-4B8493C1F5AD: backend/docagent/api.py:471-472 (create_app.create_job) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L471-L472]

## EV-68E83656D9AD

EV-68E83656D9AD: backend/docagent/api.py:470-472 (create_app.create_job:POST:/api/jobs) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L470-L472]

## EV-02537AB1105D

EV-02537AB1105D: backend/docagent/api.py:475-478 (create_app.demo) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L475-L478]

## EV-81EB1AC9D3D7

EV-81EB1AC9D3D7: backend/docagent/api.py:474-478 (create_app.demo:POST:/api/demo) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L474-L478]

## EV-AFECD7C7FFB1

EV-AFECD7C7FFB1: backend/docagent/api.py:481-491 (create_app.list_jobs) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L481-L491]

## EV-F2F3489C415F

EV-F2F3489C415F: backend/docagent/api.py:480-491 (create_app.list_jobs:GET:/api/jobs) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L480-L491]

## EV-F5EA31350D81

EV-F5EA31350D81: backend/docagent/api.py:494-495 (create_app.get_job) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L494-L495]

## EV-02DA59BFE2D0

EV-02DA59BFE2D0: backend/docagent/api.py:493-495 (create_app.get_job:GET:/api/jobs/{job_id}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L493-L495]

## EV-47B621ADFC28

EV-47B621ADFC28: backend/docagent/api.py:498-505 (create_app.collaborators) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L498-L505]

## EV-073F25C4C4FE

EV-073F25C4C4FE: backend/docagent/api.py:497-505 (create_app.collaborators:GET:/api/jobs/{job_id}/collaborators) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L497-L505]

## EV-C61F024FD0EF

EV-C61F024FD0EF: backend/docagent/api.py:508-522 (create_app.grant_access) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L508-L522]

## EV-0888B6E61750

EV-0888B6E61750: backend/docagent/api.py:507-521 (create_app.grant_access:POST:/api/jobs/{job_id}/collaborators) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L507-L521]

## EV-9A1D2988354A

EV-9A1D2988354A: backend/docagent/api.py:537-551 (create_app.revoke_access) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L537-L551]

## EV-C658AB9DFEAA

EV-C658AB9DFEAA: backend/docagent/api.py:536-550 (create_app.revoke_access:DELETE:/api/jobs/{job_id}/collaborators/{login}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L536-L550]

## EV-07B4ADE29F9E

EV-07B4ADE29F9E: backend/docagent/api.py:555-563 (create_app.files) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L555-L563]

## EV-5AC2398A5FEA

EV-5AC2398A5FEA: backend/docagent/api.py:554-563 (create_app.files:GET:/api/jobs/{job_id}/files) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L554-L563]

## EV-DF04D13D1BD6

EV-DF04D13D1BD6: backend/docagent/api.py:566-579 (create_app.download) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L566-L579]

## EV-22435B0ED175

EV-22435B0ED175: backend/docagent/api.py:565-579 (create_app.download:GET:/api/jobs/{job_id}/download) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L565-L579]

## EV-7B07CB44AD66

EV-7B07CB44AD66: backend/docagent/api.py:582-593 (create_app.preview) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L582-L593]

## EV-6ADED5183BF6

EV-6ADED5183BF6: backend/docagent/api.py:581-593 (create_app.preview:GET:/api/jobs/{job_id}/preview) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L581-L593]

## EV-CBFD6BB7D2D3

EV-CBFD6BB7D2D3: backend/docagent/api.py:596-607 (create_app.audit) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L596-L607]

## EV-46966887DC4B

EV-46966887DC4B: backend/docagent/api.py:595-607 (create_app.audit:GET:/api/jobs/{job_id}/audit) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L595-L607]

## EV-78DE396A252D

EV-78DE396A252D: backend/docagent/api.py:610-624 (create_app.review) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L610-L624]

## EV-4DB69A451714

EV-4DB69A451714: backend/docagent/api.py:609-623 (create_app.review:POST:/api/jobs/{job_id}/reviews) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L609-L623]

## EV-CBFE467043A9

EV-CBFE467043A9: backend/docagent/api.py:651-665 (create_app.record_result) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L651-L665]

## EV-7C38FD977886

EV-7C38FD977886: backend/docagent/api.py:650-664 (create_app.record_result:POST:/api/jobs/{job_id}/results) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L650-L664]

## EV-2DAB44E37092

EV-2DAB44E37092: backend/docagent/api.py:684-698 (create_app.edit_requirement) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L684-L698]

## EV-8CB4A0A92FAA

EV-8CB4A0A92FAA: backend/docagent/api.py:683-697 (create_app.edit_requirement:PATCH:/api/jobs/{job_id}/requirements/{requirement_id}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L683-L697]

## EV-32F177851483

EV-32F177851483: backend/docagent/api.py:715-724 (create_app:cfg.frontend_dir.is_dir()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L715-L724]

## EV-BD55FDEB031D

EV-BD55FDEB031D: backend/docagent/api.py:89-90 (lifespan:local) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L89-L90]

## EV-64977BD4D273

EV-64977BD4D273: backend/docagent/api.py:108-109 (user_session:not secrets.compare_digest(csrf, session.csrf)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L108-L109]

## EV-1694F0736C9F

EV-1694F0736C9F: backend/docagent/api.py:111-112 (user_session:origin and origin.rstrip('/') != settings().public_url.rstrip('/')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L111-L112]

## EV-9E15D2B75F76

EV-9E15D2B75F76: backend/docagent/api.py:169-169 (db.commit:169) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L169-L169]

## EV-FDD65DF48871

EV-FDD65DF48871: backend/docagent/api.py:190-190 (db.commit:190) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L190-L190]

## EV-CDBA75164FD0

EV-CDBA75164FD0: backend/docagent/api.py:215-216 (job_view:user) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L215-L216]

## EV-376E3B9BA4BD

EV-376E3B9BA4BD: backend/docagent/api.py:221-221 (Field(min_length=10, max_length=300)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L221-L221]

## EV-4625BB116C01

EV-4625BB116C01: backend/docagent/api.py:231-240 (create_app.security_headers:request.method in {'POST', 'PUT', 'PATCH'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L231-L240]

## EV-DDAA86921ACB

EV-DDAA86921ACB: backend/docagent/api.py:249-252 (create_app.security_headers:request.url.path in {'/docs', '/redoc'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L249-L252]

## EV-D6FD6D43E5C2

EV-D6FD6D43E5C2: backend/docagent/api.py:253-254 (create_app.security_headers:cfg.env == 'production') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L253-L254]

## EV-E79EDA750A91

EV-E79EDA750A91: backend/docagent/api.py:276-277 (create_app.storage_error:isinstance(exc, ArtifactNotFound)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L276-L277]

## EV-AFD32C317396

EV-AFD32C317396: backend/docagent/api.py:293-294 (create_app.session_info:user is None or user.expires < now()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L293-L294]

## EV-2AFFB1388A4E

EV-2AFFB1388A4E: backend/docagent/api.py:329-330 (create_app.oauth_start:not cfg.github_client_id) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L329-L330]

## EV-E90FB0D1866E

EV-E90FB0D1866E: backend/docagent/api.py:352-358 (create_app.oauth_callback:not user.oauth_state or not secrets.compare_digest(state, user.oauth_state) or (not user.oauth_started) or (now() - user.oauth_started > timedelta(minutes=10))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L352-L358]

## EV-5C7869A1A4B9

EV-5C7869A1A4B9: backend/docagent/api.py:389-390 (create_app.repositories:not user.token) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L389-L390]

## EV-A82897F5D34C

EV-A82897F5D34C: backend/docagent/api.py:413-414 (create_app.start_job:config.repository == 'demo/inventory' and (not demo)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L413-L414]

## EV-2C30728D6F6C

EV-2C30728D6F6C: backend/docagent/api.py:415-416 (create_app.start_job:config.execute_tests and (not cfg.test_execution_enabled)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L415-L416]

## EV-6882C4D601E9

EV-6882C4D601E9: backend/docagent/api.py:417-425 (create_app.start_job:not demo) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L417-L425]

## EV-E7D2AF1A350D

EV-E7D2AF1A350D: backend/docagent/api.py:429-430 (create_app.start_job:admission.rowcount != 1) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L429-L430]

## EV-CA0E095112EE

EV-CA0E095112EE: backend/docagent/api.py:437-438 (create_app.start_job:active >= 16 or owned >= cfg.max_concurrent_jobs) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L437-L438]

## EV-0CF2D24E9496

EV-0CF2D24E9496: backend/docagent/api.py:500-501 (create_app.collaborators:job.owner != user.owner) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L500-L501]

## EV-2D7FD192E2D3

EV-2D7FD192E2D3: backend/docagent/api.py:510-511 (create_app.grant_access:job.owner != user.owner or not user.login) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L510-L511]

## EV-A1CA528D58E2

EV-A1CA528D58E2: backend/docagent/api.py:512-515 (create_app.grant_access:not data.acknowledged) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L512-L515]

## EV-C271A5E850CD

EV-C271A5E850CD: backend/docagent/api.py:520-524 (create_app.grant_access:grant is None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L520-L524]

## EV-DC975731A3F0

EV-DC975731A3F0: backend/docagent/api.py:539-540 (create_app.revoke_access:job.owner != user.owner) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L539-L540]

## EV-F4A36C21FDD3

EV-F4A36C21FDD3: backend/docagent/api.py:546-551 (create_app.revoke_access:row) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L546-L551]

## EV-A507A9809E1D

EV-A507A9809E1D: backend/docagent/api.py:559-560 (create_app.files:db.get(DocumentVersion, (job.id, version)) is None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L559-L560]

## EV-3DB615C9FF85

EV-3DB615C9FF85: backend/docagent/api.py:561-562 (create_app.files:version > job.version) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L561-L562]

## EV-49C57FF9016E

EV-49C57FF9016E: backend/docagent/api.py:570-571 (create_app.download:db.get(DocumentVersion, (job.id, version)) is None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L570-L571]

## EV-CEC685CEDDD9

EV-CEC685CEDDD9: backend/docagent/api.py:572-573 (create_app.download:version > job.version) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L572-L573]

## EV-992E948B6E67

EV-992E948B6E67: backend/docagent/api.py:585-586 (create_app.preview:db.get(DocumentVersion, (job.id, job.version)) is None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L585-L586]

## EV-7F48D429F4EA

EV-7F48D429F4EA: backend/docagent/api.py:591-592 (create_app.preview:not path.endswith('.md')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L591-L592]

## EV-892E02E08DFC

EV-892E02E08DFC: backend/docagent/api.py:616-617 (create_app.review:data.baseline_hash != expected_hash) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L616-L617]

## EV-5E72E0C403CB

EV-5E72E0C403CB: backend/docagent/api.py:618-619 (create_app.review:data.decision == 'approved' and (not data.acknowledged)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L618-L619]

## EV-25B826F4748E

EV-25B826F4748E: backend/docagent/api.py:620-621 (create_app.review:data.stage == 'requirements' and data.decision == 'approved' and (not job.analysis['requirements'])) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L620-L621]

## EV-91071281693A

EV-91071281693A: backend/docagent/api.py:622-625 (create_app.review:data.stage == 'uat' and data.decision == 'approved' and (not state['ready_for_acceptance'])) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L622-L625]

## EV-0908E386217B

EV-0908E386217B: backend/docagent/api.py:655-656 (create_app.record_result:not data.attested) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L655-L656]

## EV-E0C8D653F9F1

EV-E0C8D653F9F1: backend/docagent/api.py:657-660 (create_app.record_result:data.baseline_hash != job.baseline_hash) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L657-L660]

## EV-30720496EA8A

EV-30720496EA8A: backend/docagent/api.py:661-662 (create_app.record_result:not any((t['id'] == data.test_case_id for t in job.analysis['test_cases']))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L661-L662]

## EV-49E95EAA88A5

EV-49E95EAA88A5: backend/docagent/api.py:666-667 (create_app.record_result:data.status == 'passed' and data.severity != 'none') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L666-L667]

## EV-A7E9E35E49CB

EV-A7E9E35E49CB: backend/docagent/api.py:688-689 (create_app.edit_requirement:data.baseline_hash != job.baseline_hash) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L688-L689]

## EV-6F53F986988E

EV-6F53F986988E: backend/docagent/api.py:692-693 (create_app.edit_requirement:requirement is None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L692-L693]

## EV-30B711749481

EV-30B711749481: backend/docagent/api.py:720-724 (create_app.missing_frontend) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L720-L724]

## EV-F141AC0E43FB

EV-F141AC0E43FB: backend/docagent/api.py:719-724 (create_app.missing_frontend:GET:/) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L719-L724]

## EV-5DC191F2CE31

EV-5DC191F2CE31: backend/docagent/api.py:98-98 (get_db) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L98-L98]

## EV-3ABE0B20F41E

EV-3ABE0B20F41E: backend/docagent/api.py:116-116 (user_session) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L116-L116]

## EV-6F847F35DE83

EV-6F847F35DE83: backend/docagent/api.py:232-233 (create_app.security_headers:request.headers.get('content-type', '').split(';')[0] != 'application/json') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L232-L233]

## EV-742B01FCB4B8

EV-742B01FCB4B8: backend/docagent/api.py:286-286 (db.execute:286) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L286-L286]

## EV-EA6FDB14592E

EV-EA6FDB14592E: backend/docagent/api.py:323-323 (db.commit:323) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L323-L323]

## EV-3F7F05F84380

EV-3F7F05F84380: backend/docagent/api.py:339-339 (db.commit:339) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L339-L339]

## EV-8E62418C5A43

EV-8E62418C5A43: backend/docagent/api.py:362-362 (db.commit:362) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L362-L362]

## EV-9065A7DB7566

EV-9065A7DB7566: backend/docagent/api.py:377-378 (create_app.oauth_callback:not token) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L377-L378]

## EV-8CF963BDF1AC

EV-8CF963BDF1AC: backend/docagent/api.py:420-425 (create_app.start_job:metadata['private'] and any((p.provider not in config.consent_providers for p in config.providers))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L420-L425]

## EV-A4AC724A262A

EV-A4AC724A262A: backend/docagent/api.py:428-428 (db.execute:428) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L428-L428]

## EV-04185E4753E3

EV-04185E4753E3: backend/docagent/api.py:447-447 (db.flush:447) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L447-L447]

## EV-B84C9DFB9ADA

EV-B84C9DFB9ADA: backend/docagent/api.py:460-460 (db.commit:460) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L460-L460]

## EV-C260A1D28061

EV-C260A1D28061: backend/docagent/api.py:533-533 (db.commit:533) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L533-L533]

## EV-3ADB8A9FC5BD

EV-3ADB8A9FC5BD: backend/docagent/api.py:645-645 (db.flush:645) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L645-L645]

## EV-C7257497C655

EV-C7257497C655: backend/docagent/api.py:647-647 (db.commit:647) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L647-L647]

## EV-96D84FF8128D

EV-96D84FF8128D: backend/docagent/api.py:678-678 (db.flush:678) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L678-L678]

## EV-7A46E28394F5

EV-7A46E28394F5: backend/docagent/api.py:680-680 (db.commit:680) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L680-L680]

## EV-1F2126D408DB

EV-1F2126D408DB: backend/docagent/api.py:710-710 (db.flush:710) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L710-L710]

## EV-AE2D67423C32

EV-AE2D67423C32: backend/docagent/api.py:712-712 (db.commit:712) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L712-L712]

## EV-84D05C3B28B4

EV-84D05C3B28B4: backend/docagent/api.py:72-72 (db.execute:72) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L72-L72]

## EV-099672642A7B

EV-099672642A7B: backend/docagent/api.py:81-81 (db.commit:81) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L81-L81]

## EV-D6F2B5F69486

EV-D6F2B5F69486: backend/docagent/api.py:238-239 (create_app.security_headers:len(body) > 128000) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L238-L239]

## EV-2139B2CCD5E2

EV-2139B2CCD5E2: backend/docagent/api.py:364-364 (httpx.post:github.com) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L364-L364]

## EV-A729D13EED26

EV-A729D13EED26: backend/docagent/api.py:551-551 (db.commit:551) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L551-L551]

## EV-3B1F48CE020E

EV-3B1F48CE020E: backend/docagent/api.py:467-467 (db.commit:467) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/api.py#L467-L467]

## EV-A98AB5FAAF12

EV-A98AB5FAAF12: backend/docagent/checks.py:23-24 (CheckFailure) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L23-L24]

## EV-84F979603F69

EV-84F979603F69: backend/docagent/checks.py:27-41 (postgres_check) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L27-L41]

## EV-B95194AEE50F

EV-B95194AEE50F: backend/docagent/checks.py:45-59 (redis_check) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L45-L59]

## EV-EE2B70391D68

EV-EE2B70391D68: backend/docagent/checks.py:67-81 (storage_check) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L67-L81]

## EV-5FACC9A789BF

EV-5FACC9A789BF: backend/docagent/checks.py:110-114 (encryption_check) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L110-L114]

## EV-F349E888BBF1

EV-F349E888BBF1: backend/docagent/checks.py:117-131 (api_check) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L117-L131]

## EV-66E2AEA66784

EV-66E2AEA66784: backend/docagent/checks.py:193-207 (run_checks) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L193-L207]

## EV-51D646C892A4

EV-51D646C892A4: backend/docagent/checks.py:28-29 (postgres_check:not cfg.database_url.startswith('postgresql')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L28-L29]

## EV-0BE7D70CC2BB

EV-0BE7D70CC2BB: backend/docagent/checks.py:46-47 (redis_check:cfg.redis_backend != 'real') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L46-L47]

## EV-FDFB8A4CCC3C

EV-FDFB8A4CCC3C: backend/docagent/checks.py:68-69 (storage_check:cfg.storage_backend != 's3') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L68-L69]

## EV-0C59764208DD

EV-0C59764208DD: backend/docagent/checks.py:112-113 (encryption_check:decrypt(encrypt(probe)) != probe) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L112-L113]

## EV-D2A035362599

EV-D2A035362599: backend/docagent/checks.py:196-207 (run_checks.run) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L196-L207]

## EV-A456ABE4FA3F

EV-A456ABE4FA3F: backend/docagent/checks.py:218-222 (run_checks:api_url) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L218-L222]

## EV-2428FCE64696

EV-2428FCE64696: backend/docagent/checks.py:52-53 (redis_check:not client.ping()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L52-L53]

## EV-E4418F2F0182

EV-E4418F2F0182: backend/docagent/checks.py:54-57 (redis_check:write_probe) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L54-L57]

## EV-FD1E2CF6717A

EV-FD1E2CF6717A: backend/docagent/checks.py:76-77 (storage_check:not write_probe) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L76-L77]

## EV-DAF3EF97EA5C

EV-DAF3EF97EA5C: backend/docagent/checks.py:102-103 (storage_check:storage.version_exists(probe_id, 1)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L102-L103]

## EV-2A239BE7C405

EV-2A239BE7C405: backend/docagent/checks.py:119-123 (api_check.request) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L119-L123]

## EV-CFA4F996DD54

EV-CFA4F996DD54: backend/docagent/checks.py:155-156 (api_check:individual.replace('\r\n', '\n') != preview) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L155-L156]

## EV-4877BF744386

EV-4877BF744386: backend/docagent/checks.py:181-182 (api_check:job['config']['providers'] or job['analysis']['execution'] is not None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L181-L182]

## EV-6F97BE9C09C9

EV-6F97BE9C09C9: backend/docagent/checks.py:183-184 (api_check:job['workflow']['counts']['passed'] != 0) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L183-L184]

## EV-EB22F94CB947

EV-EB22F94CB947: backend/docagent/checks.py:185-187 (api_check:package_output) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L185-L187]

## EV-0BBBFC651731

EV-0BBBFC651731: backend/docagent/checks.py:219-222 (run_checks:all((item['status'] == 'passed' for item in checks.values()))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L219-L222]

## EV-B16B3A2CC1D0

EV-B16B3A2CC1D0: backend/docagent/checks.py:34-35 (postgres_check:not inspect(connection).has_table('alembic_version')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L34-L35]

## EV-9CD546315FEF

EV-9CD546315FEF: backend/docagent/checks.py:37-38 (postgres_check:compare_metadata(MigrationContext.configure(connection), Base.metadata)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L37-L38]

## EV-1799930688AA

EV-1799930688AA: backend/docagent/checks.py:56-57 (redis_check:not created or client.get(key) != 'roundtrip-ok') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L56-L57]

## EV-901C9561186F

EV-901C9561186F: backend/docagent/checks.py:61-62 (redis_check:created) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L61-L62]

## EV-AA2E6BB564FB

EV-AA2E6BB564FB: backend/docagent/checks.py:86-87 (storage_check:storage.read_text(probe_id, 1, 'probe.txt') != payload) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L86-L87]

## EV-5092435A55F2

EV-5092435A55F2: backend/docagent/checks.py:121-122 (api_check.request:response.status_code != expected) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L121-L122]

## EV-6A5AA4FEE212

EV-6A5AA4FEE212: backend/docagent/checks.py:134-135 (api_check:job['status'] == 'completed') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L134-L135]

## EV-F9046D9A9A7B

EV-F9046D9A9A7B: backend/docagent/checks.py:136-137 (api_check:job['status'] == 'failed') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L136-L137]

## EV-63F2943D1066

EV-63F2943D1066: backend/docagent/checks.py:138-139 (api_check:time.monotonic() >= deadline) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L138-L139]

## EV-1319BA313C0C

EV-1319BA313C0C: backend/docagent/checks.py:144-145 (api_check:archive.testzip() is not None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L144-L145]

## EV-CEB504753155

EV-CEB504753155: backend/docagent/checks.py:149-150 (api_check:counts != {'docx': 7, 'pdf': 7, 'xlsx': 1, 'svg': 4, 'png': 4}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L149-L150]

## EV-DF0F8B25A89B

EV-DF0F8B25A89B: backend/docagent/checks.py:179-180 (api_check:other.get('/api/session').status_code != 200 or other.get(path).status_code != 404) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L179-L180]

## EV-4194377E517A

EV-4194377E517A: backend/docagent/checks.py:90-91 (storage_check:hashlib.sha256(download.path.read_bytes()).hexdigest() != expected_hash) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L90-L91]

## EV-FAC073CB8FB5

EV-FAC073CB8FB5: backend/docagent/checks.py:93-94 (storage_check:download.cleanup) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L93-L94]

## EV-DCF4D07E44FA

EV-DCF4D07E44FA: backend/docagent/checks.py:162-163 (api_check:not record or record.status != 'completed' or (not stored) or (stored.package_sha256 != checksum)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L162-L163]

## EV-D27C3193B1C5

EV-D27C3193B1C5: backend/docagent/checks.py:170-171 (api_check:hashlib.sha256(downloaded.path.read_bytes()).hexdigest() != checksum) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L170-L171]

## EV-1315C21CE8A4

EV-1315C21CE8A4: backend/docagent/checks.py:173-174 (api_check:downloaded.cleanup) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L173-L174]

## EV-E0C29DF62CF8

EV-E0C29DF62CF8: backend/docagent/checks.py:201-202 (run_checks.run:isinstance(exc, CheckFailure)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L201-L202]

## EV-E552E71DB4B7

EV-E552E71DB4B7: backend/docagent/checks.py:204-205 (run_checks.run:original is not None and getattr(original, 'sqlstate', None)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L204-L205]

## EV-A066A2AE4009

EV-A066A2AE4009: backend/docagent/checks.py:33-33 (connection.execute:33) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L33-L33]

## EV-1C1BAB3823B5

EV-1C1BAB3823B5: backend/docagent/checks.py:36-36 (connection.execute:36) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/checks.py#L36-L36]

## EV-97E1A9B7E661

EV-97E1A9B7E661: backend/docagent/cli.py:9-23 (main) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L9-L23]

## EV-95FCE0FDB8DC

EV-95FCE0FDB8DC: backend/docagent/cli.py:42-55 (main:args.command == 'compose-env') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L42-L55]

## EV-DE0855E37A40

EV-DE0855E37A40: backend/docagent/cli.py:56-68 (main:args.command == 'check-services') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L56-L68]

## EV-58CC9123F0D1

EV-58CC9123F0D1: backend/docagent/cli.py:69-83 (main:args.command == 'key') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L69-L83]

## EV-1FE93DACE448

EV-1FE93DACE448: backend/docagent/cli.py:59-60 (main:args.timeout < 1) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L59-L60]

## EV-D7621306E19F

EV-D7621306E19F: backend/docagent/cli.py:61-62 (main:args.output and args.output.suffix.lower() != '.json') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L61-L62]

## EV-FC59B9DD4CAC

EV-FC59B9DD4CAC: backend/docagent/cli.py:64-66 (main:args.output) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L64-L66]

## EV-2F8E5B094121

EV-2F8E5B094121: backend/docagent/cli.py:73-87 (main:args.command == 'init-db') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L73-L87]

## EV-74D0ECFB4F62

EV-74D0ECFB4F62: backend/docagent/cli.py:78-92 (main:args.command in {'serve', 'worker', 'scheduler'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L78-L92]

## EV-F1D0B8052BB9

EV-F1D0B8052BB9: backend/docagent/cli.py:83-84 (main:args.log_level) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L83-L84]

## EV-00904884BA2B

EV-00904884BA2B: backend/docagent/cli.py:86-100 (main:args.command == 'serve') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L86-L100]

## EV-79BEA169459C

EV-79BEA169459C: backend/docagent/cli.py:107-121 (main:args.command == 'cleanup') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L107-L121]

## EV-6979F66C8D9A

EV-6979F66C8D9A: backend/docagent/cli.py:92-93 (main:args.command == 'worker' and args.concurrency < 1) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L92-L93]

## EV-DC5466C98EA4

EV-DC5466C98EA4: backend/docagent/cli.py:97-106 (main:args.command == 'worker') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L97-L106]

## EV-792B5D336C2A

EV-792B5D336C2A: backend/docagent/cli.py:113-127 (main:args.command == 'scan') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L113-L127]

## EV-D3024A4AF9FF

EV-D3024A4AF9FF: backend/docagent/cli.py:99-100 (main:args.pool) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L99-L100]

## EV-53BF34A2AD79

EV-53BF34A2AD79: backend/docagent/cli.py:103-105 (main:args.schedule) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L103-L105]

## EV-F0DE816C1F0C

EV-F0DE816C1F0C: backend/docagent/cli.py:120-121 (main:not args.path.is_dir()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L120-L121]

## EV-F7B1F701C597

EV-F7B1F701C597: backend/docagent/cli.py:122-123 (main:args.output.resolve().is_relative_to(args.path.resolve())) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L122-L123]

## EV-05B4EAA7EDC9

EV-05B4EAA7EDC9: backend/docagent/cli.py:124-125 (main:args.output.exists() or package_path(args.output).exists()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/cli.py#L124-L125]

## EV-6F5A6CCD8D12

EV-6F5A6CCD8D12: backend/docagent/compose_config.py:13-19 (service_url) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/compose_config.py#L13-L19]

## EV-149FA05A9147

EV-149FA05A9147: backend/docagent/compose_config.py:22-36 (write_compose_env) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/compose_config.py#L22-L36]

## EV-CFCC25EBF29C

EV-CFCC25EBF29C: backend/docagent/compose_config.py:15-16 (service_url:not parsed.hostname or not host or any((c in host for c in '/\\@?#\r\n'))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/compose_config.py#L15-L16]

## EV-837A6F72CEAB

EV-837A6F72CEAB: backend/docagent/compose_config.py:29-30 (write_compose_env:output.resolve() == Path('.env').resolve()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/compose_config.py#L29-L30]

## EV-6A8E8E0A21E0

EV-6A8E8E0A21E0: backend/docagent/compose_config.py:32-33 (write_compose_env:not database.drivername.startswith('postgresql')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/compose_config.py#L32-L33]

## EV-5ED256BCB305

EV-5ED256BCB305: backend/docagent/compose_config.py:34-35 (write_compose_env:not database_host or any((c in database_host for c in '/\\@?#\r\n'))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/compose_config.py#L34-L35]

## EV-317288F74BB1

EV-317288F74BB1: backend/docagent/compose_config.py:40-41 (write_compose_env:cfg.storage_backend == 's3' and cfg.s3_endpoint_url) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/compose_config.py#L40-L41]

## EV-F5A8387BCFAA

EV-F5A8387BCFAA: backend/docagent/compose_config.py:42-43 (write_compose_env:any(('\n' in value or '\r' in value for value in values.values()))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/compose_config.py#L42-L43]

## EV-D5BE88DF2B31

EV-D5BE88DF2B31: backend/docagent/compose_config.py:58-59 (write_compose_env:temporary is not None and temporary.exists()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/compose_config.py#L58-L59]

## EV-7D8F7BF36CEA

EV-7D8F7BF36CEA: backend/docagent/config.py:12-26 (Settings) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L12-L26]

## EV-F4F1ED44CFE4

EV-F4F1ED44CFE4: backend/docagent/config.py:111-112 (settings) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L111-L112]

## EV-7A04632D6C90

EV-7A04632D6C90: backend/docagent/config.py:57-58 (Settings.normalize_log_level) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L57-L58]

## EV-82D7E520B177

EV-82D7E520B177: backend/docagent/config.py:61-75 (Settings.storage) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L61-L75]

## EV-36D82B1EC1AF

EV-36D82B1EC1AF: backend/docagent/config.py:95-107 (Settings.production) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L95-L107]

## EV-9D64A2E5D5A7

EV-9D64A2E5D5A7: backend/docagent/config.py:62-76 (Settings.storage:self.storage_backend == 's3') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L62-L76]

## EV-EA663AF4AC5D

EV-EA663AF4AC5D: backend/docagent/config.py:96-102 (Settings.production:self.env == 'production') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L96-L102]

## EV-824ED0DA7C55

EV-824ED0DA7C55: backend/docagent/config.py:103-104 (Settings.production:self.job_backend == 'celery' and self.redis_backend != 'real') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L103-L104]

## EV-F70841EA66C0

EV-F70841EA66C0: backend/docagent/config.py:105-106 (Settings.production:self.max_concurrent_jobs < 1) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L105-L106]

## EV-E288344AD447

EV-E288344AD447: backend/docagent/config.py:63-64 (Settings.storage:not self.s3_bucket.strip() or any((c in self.s3_bucket for c in '/\\:'))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L63-L64]

## EV-916E73866B83

EV-916E73866B83: backend/docagent/config.py:66-71 (Settings.storage:self.s3_prefix and (any((part in {'', '.', '..'} for part in self.s3_prefix.split('/'))) or any((c in self.s3_prefix for c in '\\:')) or any((ord(c) < 32 for c in self.s3_prefix)))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L66-L71]

## EV-0DF7ABD3A3B6

EV-0DF7ABD3A3B6: backend/docagent/config.py:72-85 (Settings.storage:self.s3_endpoint_url) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L72-L85]

## EV-5D09FBCDDFE0

EV-5D09FBCDDFE0: backend/docagent/config.py:88-89 (Settings.storage:bool(access_key) != bool(secret_key)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L88-L89]

## EV-089DC5DD5E77

EV-089DC5DD5E77: backend/docagent/config.py:90-91 (Settings.storage:self.s3_session_token.get_secret_value() and (not access_key)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L90-L91]

## EV-21C50E25E1CB

EV-21C50E25E1CB: backend/docagent/config.py:97-98 (Settings.production:not self.encryption_key.get_secret_value()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L97-L98]

## EV-87F71139CF19

EV-87F71139CF19: backend/docagent/config.py:99-100 (Settings.production:not self.public_url.startswith('https://')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L99-L100]

## EV-651FDAE813DC

EV-651FDAE813DC: backend/docagent/config.py:101-102 (Settings.production:not self.database_url.startswith('postgresql') or self.job_backend != 'celery') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L101-L102]

## EV-E56B5E3C5FD8

EV-E56B5E3C5FD8: backend/docagent/config.py:74-85 (Settings.storage:endpoint.scheme not in {'http', 'https'} or not endpoint.hostname or endpoint.username or endpoint.password or endpoint.query or endpoint.fragment or (endpoint.path not in {'', '/'})) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/config.py#L74-L85]

## EV-05ECBF6BB2A2

EV-05ECBF6BB2A2: backend/docagent/db.py:12-13 (now) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L12-L13]

## EV-FDDB1BB935C5

EV-FDDB1BB935C5: backend/docagent/db.py:16-17 (Base) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L16-L17]

## EV-12C5F1F1B8AF

EV-12C5F1F1B8AF: backend/docagent/db.py:20-24 (JobAdmission) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L20-L24]

## EV-A9B89FBBB448

EV-A9B89FBBB448: backend/docagent/db.py:27-37 (UserSession) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L27-L37]

## EV-C78667A2DB1D

EV-C78667A2DB1D: backend/docagent/db.py:40-54 (Job) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L40-L54]

## EV-49260818223C

EV-49260818223C: backend/docagent/db.py:61-67 (JobAccess) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L61-L67]

## EV-992E64D8AFC2

EV-992E64D8AFC2: backend/docagent/db.py:70-76 (DocumentVersion) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L70-L76]

## EV-8BD1CD83834F

EV-8BD1CD83834F: backend/docagent/db.py:79-88 (Review) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L79-L88]

## EV-471EEC5899CD

EV-471EEC5899CD: backend/docagent/db.py:91-103 (TestResult) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L91-L103]

## EV-AD5BBF3312D9

EV-AD5BBF3312D9: backend/docagent/db.py:106-113 (Audit) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L106-L113]

## EV-56B5E014BE46

EV-56B5E014BE46: backend/docagent/db.py:116-120 (ScanCache) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L116-L120]

## EV-8539AE7F1C10

EV-8539AE7F1C10: backend/docagent/db.py:124-138 (engine) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L124-L138]

## EV-AFFDA8B2E692

EV-AFFDA8B2E692: backend/docagent/db.py:144-145 (session_factory) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L144-L145]

## EV-E00AB9F27E83

EV-E00AB9F27E83: backend/docagent/db.py:148-158 (init_db) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L148-L158]

## EV-4BE1625E93E5

EV-4BE1625E93E5: backend/docagent/db.py:161-162 (digest) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L161-L162]

## EV-C4A57D4F0BF6

EV-C4A57D4F0BF6: backend/docagent/db.py:165-175 (save_cache) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L165-L175]

## EV-03976B92323E

EV-03976B92323E: backend/docagent/db.py:134-139 (engine:cfg.database_url.startswith('sqlite')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L134-L139]

## EV-B4ABB8B1E057

EV-B4ABB8B1E057: backend/docagent/db.py:167-170 (save_cache:db.bind.dialect.name == 'postgresql') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L167-L170]

## EV-4CB045DD29D7

EV-4CB045DD29D7: backend/docagent/db.py:24-24 (mapped_column(Integer, primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L24-L24]

## EV-399E37FD0E1E

EV-399E37FD0E1E: backend/docagent/db.py:29-29 (mapped_column(String(64), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L29-L29]

## EV-3F01586D2687

EV-3F01586D2687: backend/docagent/db.py:30-30 (mapped_column(String(100), index=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L30-L30]

## EV-9FF40361EA2F

EV-9FF40361EA2F: backend/docagent/db.py:31-31 (mapped_column(String(100), default='')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L31-L31]

## EV-2AD62D0D8092

EV-2AD62D0D8092: backend/docagent/db.py:32-32 (mapped_column(Text, default='')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L32-L32]

## EV-73DD231AEEB4

EV-73DD231AEEB4: backend/docagent/db.py:33-33 (mapped_column(String(100))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L33-L33]

## EV-37DAEB9224B8

EV-37DAEB9224B8: backend/docagent/db.py:34-34 (mapped_column(String(100), default='')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L34-L34]

## EV-05C714C48B91

EV-05C714C48B91: backend/docagent/db.py:35-35 (mapped_column(String(150), default='')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L35-L35]

## EV-E163EEFDCDAF

EV-E163EEFDCDAF: backend/docagent/db.py:36-36 (mapped_column(DateTime, nullable=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L36-L36]

## EV-6BA00102528A

EV-6BA00102528A: backend/docagent/db.py:37-37 (mapped_column(DateTime)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L37-L37]

## EV-D8CE01CE245F

EV-D8CE01CE245F: backend/docagent/db.py:42-42 (mapped_column(String(36), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L42-L42]

## EV-A761CC6B33C5

EV-A761CC6B33C5: backend/docagent/db.py:43-43 (mapped_column(String(100), index=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L43-L43]

## EV-BB77FC1204AA

EV-BB77FC1204AA: backend/docagent/db.py:44-44 (mapped_column(String(200))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L44-L44]

## EV-9818DA0D4C61

EV-9818DA0D4C61: backend/docagent/db.py:45-45 (mapped_column(String(30), default='queued')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L45-L45]

## EV-D54306838181

EV-D54306838181: backend/docagent/db.py:46-46 (mapped_column(Integer, default=0)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L46-L46]

## EV-18DE0276EA1A

EV-18DE0276EA1A: backend/docagent/db.py:47-47 (mapped_column(Text, default='Waiting for worker')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L47-L47]

## EV-1107D6E74751

EV-1107D6E74751: backend/docagent/db.py:48-48 (mapped_column(JSON)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L48-L48]

## EV-9F235BCB70D9

EV-9F235BCB70D9: backend/docagent/db.py:49-49 (mapped_column(JSON, nullable=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L49-L49]

## EV-E9849C568C6A

EV-E9849C568C6A: backend/docagent/db.py:50-50 (mapped_column(String(64), default='')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L50-L50]

## EV-5B8640498097

EV-5B8640498097: backend/docagent/db.py:51-51 (mapped_column(Integer, default=1)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L51-L51]

## EV-B4056F501988

EV-B4056F501988: backend/docagent/db.py:52-52 (mapped_column(DateTime, default=now)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L52-L52]

## EV-432C2E8B992B

EV-432C2E8B992B: backend/docagent/db.py:53-53 (mapped_column(DateTime, default=now, onupdate=now)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L53-L53]

## EV-0DA06AC84039

EV-0DA06AC84039: backend/docagent/db.py:55-55 (mapped_column(Text, default='')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L55-L55]

## EV-CEC4549764E5

EV-CEC4549764E5: backend/docagent/db.py:56-56 (mapped_column(String(36), default='')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L56-L56]

## EV-38E7E261D48D

EV-38E7E261D48D: backend/docagent/db.py:57-57 (mapped_column(String(40), default='', server_default='')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L57-L57]

## EV-D627647E3031

EV-D627647E3031: backend/docagent/db.py:58-58 (mapped_column(DateTime, nullable=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L58-L58]

## EV-18543ADA6BA4

EV-18543ADA6BA4: backend/docagent/db.py:63-63 (mapped_column(ForeignKey('jobs.id', ondelete='CASCADE'), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L63-L63]

## EV-4B493D667D77

EV-4B493D667D77: backend/docagent/db.py:64-64 (mapped_column(String(100), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L64-L64]

## EV-9AD64C71C6A4

EV-9AD64C71C6A4: backend/docagent/db.py:65-65 (mapped_column(String(100))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L65-L65]

## EV-8D2961F594E1

EV-8D2961F594E1: backend/docagent/db.py:66-66 (mapped_column(String(20))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L66-L66]

## EV-00E02F4E7A0F

EV-00E02F4E7A0F: backend/docagent/db.py:67-67 (mapped_column(DateTime, default=now)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L67-L67]

## EV-036407D9D038

EV-036407D9D038: backend/docagent/db.py:72-72 (mapped_column(ForeignKey('jobs.id', ondelete='CASCADE'), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L72-L72]

## EV-B3744BC7C6FA

EV-B3744BC7C6FA: backend/docagent/db.py:73-73 (mapped_column(Integer, primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L73-L73]

## EV-EAA2F9B099DF

EV-EAA2F9B099DF: backend/docagent/db.py:74-74 (mapped_column(String(64))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L74-L74]

## EV-251BF43552A1

EV-251BF43552A1: backend/docagent/db.py:75-75 (mapped_column(String(64))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L75-L75]

## EV-27278EA7D389

EV-27278EA7D389: backend/docagent/db.py:76-76 (mapped_column(DateTime, default=now)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L76-L76]

## EV-AAFFF79B66D1

EV-AAFFF79B66D1: backend/docagent/db.py:81-81 (mapped_column(primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L81-L81]

## EV-E79A07ECD48C

EV-E79A07ECD48C: backend/docagent/db.py:82-82 (mapped_column(ForeignKey('jobs.id', ondelete='CASCADE'), index=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L82-L82]

## EV-AF9FAB808146

EV-AF9FAB808146: backend/docagent/db.py:83-83 (mapped_column(String(64))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L83-L83]

## EV-F597D151A0AF

EV-F597D151A0AF: backend/docagent/db.py:84-84 (mapped_column(String(30))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L84-L84]

## EV-302E9AF0136C

EV-302E9AF0136C: backend/docagent/db.py:85-85 (mapped_column(String(30))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L85-L85]

## EV-5F28B573DAD0

EV-5F28B573DAD0: backend/docagent/db.py:86-86 (mapped_column(String(100))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L86-L86]

## EV-5C0BA33C9FC5

EV-5C0BA33C9FC5: backend/docagent/db.py:87-87 (mapped_column(Text)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L87-L87]

## EV-B04D50B3D7EC

EV-B04D50B3D7EC: backend/docagent/db.py:88-88 (mapped_column(DateTime, default=now)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L88-L88]

## EV-8DA509B4190D

EV-8DA509B4190D: backend/docagent/db.py:93-93 (mapped_column(primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L93-L93]

## EV-9FD39125C5E7

EV-9FD39125C5E7: backend/docagent/db.py:94-94 (mapped_column(ForeignKey('jobs.id', ondelete='CASCADE'), index=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L94-L94]

## EV-64856C3D6C33

EV-64856C3D6C33: backend/docagent/db.py:95-95 (mapped_column(String(64))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L95-L95]

## EV-B08DE3083B64

EV-B08DE3083B64: backend/docagent/db.py:96-96 (mapped_column(String(80))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L96-L96]

## EV-6B78F90A29C9

EV-6B78F90A29C9: backend/docagent/db.py:97-97 (mapped_column(String(30))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L97-L97]

## EV-23D9D2D7BE15

EV-23D9D2D7BE15: backend/docagent/db.py:98-98 (mapped_column(String(30))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L98-L98]

## EV-235877258D2D

EV-235877258D2D: backend/docagent/db.py:99-99 (mapped_column(Text)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L99-L99]

## EV-D8474D91EAF6

EV-D8474D91EAF6: backend/docagent/db.py:100-100 (mapped_column(Text)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L100-L100]

## EV-7A400789427B

EV-7A400789427B: backend/docagent/db.py:101-101 (mapped_column(String(20))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L101-L101]

## EV-53BD3BE19CF3

EV-53BD3BE19CF3: backend/docagent/db.py:102-102 (mapped_column(String(100))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L102-L102]

## EV-185DB2AF7399

EV-185DB2AF7399: backend/docagent/db.py:103-103 (mapped_column(DateTime, default=now)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L103-L103]

## EV-8533EE700285

EV-8533EE700285: backend/docagent/db.py:108-108 (mapped_column(primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L108-L108]

## EV-D34085882DD8

EV-D34085882DD8: backend/docagent/db.py:109-109 (mapped_column(ForeignKey('jobs.id', ondelete='CASCADE'), index=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L109-L109]

## EV-307646C4804A

EV-307646C4804A: backend/docagent/db.py:110-110 (mapped_column(String(100))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L110-L110]

## EV-3B5CEEBCEE9E

EV-3B5CEEBCEE9E: backend/docagent/db.py:111-111 (mapped_column(String(100))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L111-L111]

## EV-AE7A1F5483CE

EV-AE7A1F5483CE: backend/docagent/db.py:112-112 (mapped_column(JSON, default=dict)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L112-L112]

## EV-4E9444776E69

EV-4E9444776E69: backend/docagent/db.py:113-113 (mapped_column(DateTime, default=now)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L113-L113]

## EV-600A3B894462

EV-600A3B894462: backend/docagent/db.py:118-118 (mapped_column(String(64), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L118-L118]

## EV-8F92B26CE7C6

EV-8F92B26CE7C6: backend/docagent/db.py:119-119 (mapped_column(JSON)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L119-L119]

## EV-43DFD08A46B4

EV-43DFD08A46B4: backend/docagent/db.py:120-120 (mapped_column(DateTime, default=now, onupdate=now)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L120-L120]

## EV-BB4DFB4B72E4

EV-BB4DFB4B72E4: backend/docagent/db.py:137-139 (engine.sqlite_pragmas) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L137-L139]

## EV-FCAE850F72DA

EV-FCAE850F72DA: backend/docagent/db.py:171-175 (db.execute:171) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L171-L175]

## EV-97F7D5B97244

EV-97F7D5B97244: backend/docagent/db.py:63-63 (ForeignKey('jobs.id', ondelete='CASCADE')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L63-L63]

## EV-F626543048A0

EV-F626543048A0: backend/docagent/db.py:72-72 (ForeignKey('jobs.id', ondelete='CASCADE')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L72-L72]

## EV-F27C8D389658

EV-F27C8D389658: backend/docagent/db.py:82-82 (ForeignKey('jobs.id', ondelete='CASCADE')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L82-L82]

## EV-9F220FDC910F

EV-9F220FDC910F: backend/docagent/db.py:94-94 (ForeignKey('jobs.id', ondelete='CASCADE')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L94-L94]

## EV-65580A63D36A

EV-65580A63D36A: backend/docagent/db.py:109-109 (ForeignKey('jobs.id', ondelete='CASCADE')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L109-L109]

## EV-D9A4E4653EFF

EV-D9A4E4653EFF: backend/docagent/db.py:138-138 (connection.execute:138) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L138-L138]

## EV-2CAA1451CFB2

EV-2CAA1451CFB2: backend/docagent/db.py:139-139 (connection.execute:139) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/db.py#L139-L139]

## EV-D539EF909DD6

EV-D539EF909DD6: backend/docagent/diagrams.py:13-14 (label) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L13-L14]

## EV-B965CFD7FD10

EV-B965CFD7FD10: backend/docagent/diagrams.py:17-31 (graph_sets) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L17-L31]

## EV-21DAC680B1D6

EV-21DAC680B1D6: backend/docagent/diagrams.py:87-95 (mermaid) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L87-L95]

## EV-DA01A6A6CB61

EV-DA01A6A6CB61: backend/docagent/diagrams.py:98-112 (export_graph) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L98-L112]

## EV-858EEC593BD0

EV-858EEC593BD0: backend/docagent/diagrams.py:25-28 (graph_sets:not nodes) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L25-L28]

## EV-393860204399

EV-393860204399: backend/docagent/diagrams.py:40-42 (graph_sets:api) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L40-L42]

## EV-27E97E770CDA

EV-27E97E770CDA: backend/docagent/diagrams.py:89-90 (mermaid:not nodes) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L89-L90]

## EV-B6BD2C22B50B

EV-B6BD2C22B50B: backend/docagent/diagrams.py:101-102 (export_graph:not nodes) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L101-L102]

## EV-6B9362113934

EV-6B9362113934: backend/docagent/diagrams.py:114-126 (export_graph:shutil.which('dot')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L114-L126]

## EV-1867848CEB98

EV-1867848CEB98: backend/docagent/diagrams.py:130-131 (export_graph:not rows) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L130-L131]

## EV-4EE79B59D8C2

EV-4EE79B59D8C2: backend/docagent/diagrams.py:72-73 (graph_sets:not handler) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L72-L73]

## EV-8E8ED7A3E809

EV-8E8ED7A3E809: backend/docagent/diagrams.py:160-167 (export_graph:target) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L160-L167]

## EV-BF8DEFAD293F

EV-BF8DEFAD293F: backend/docagent/diagrams.py:170-170 (image.save:170) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L170-L170]

## EV-7E2EEE2A73F8

EV-7E2EEE2A73F8: backend/docagent/diagrams.py:27-28 (graph_sets:item['category'] == 'source') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L27-L28]

## EV-25E2FABEFFD6

EV-25E2FABEFFD6: backend/docagent/diagrams.py:147-148 (export_graph:not value) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/diagrams.py#L147-L148]

## EV-9E67F0EFBB14

EV-9E67F0EFBB14: backend/docagent/documents.py:28-41 (evidence_text) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L28-L41]

## EV-C4A81A5314FF

EV-C4A81A5314FF: backend/docagent/documents.py:44-58 (build_sections) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L44-L58]

## EV-86AC6DE98F71

EV-86AC6DE98F71: backend/docagent/documents.py:246-259 (approval_lines) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L246-L259]

## EV-55620050CF05

EV-55620050CF05: backend/docagent/documents.py:262-268 (markdown) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L262-L268]

## EV-246F2DEE2E27

EV-246F2DEE2E27: backend/docagent/documents.py:271-285 (write_docx) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L271-L285]

## EV-0537068BAE4F

EV-0537068BAE4F: backend/docagent/documents.py:301-315 (write_pdf) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L301-L315]

## EV-C3D85A7CF1B8

EV-C3D85A7CF1B8: backend/docagent/documents.py:353-367 (write_rtm) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L353-L367]

## EV-548D0B15D94F

EV-548D0B15D94F: backend/docagent/documents.py:412-413 (package_path) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L412-L413]

## EV-626774756A09

EV-626774756A09: backend/docagent/documents.py:416-430 (export_package) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L416-L430]

## EV-52C74E69FA7B

EV-52C74E69FA7B: backend/docagent/documents.py:49-50 (build_sections.section) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L49-L50]

## EV-F47EC54F2B0F

EV-F47EC54F2B0F: backend/docagent/documents.py:52-65 (build_sections.findings) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L52-L65]

## EV-CCCAF6A1A09A

EV-CCCAF6A1A09A: backend/docagent/documents.py:67-81 (build_sections:kind == 'srs') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L67-L81]

## EV-B2ED9AD7FFA2

EV-B2ED9AD7FFA2: backend/docagent/documents.py:248-255 (approval_lines:not records) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L248-L255]

## EV-8D1D7FC5D66F

EV-8D1D7FC5D66F: backend/docagent/documents.py:324-326 (write_pdf.safe) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L324-L326]

## EV-33F2D51E1D4A

EV-33F2D51E1D4A: backend/docagent/documents.py:338-341 (write_pdf.footer) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L338-L341]

## EV-E3723DC5F80B

EV-E3723DC5F80B: backend/docagent/documents.py:405-408 (write_rtm:sheet.max_row > 1) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L405-L408]

## EV-3AFD5E94293C

EV-3AFD5E94293C: backend/docagent/documents.py:417-418 (export_package:package_path(root).exists()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L417-L418]

## EV-BA32B7232D3D

EV-BA32B7232D3D: backend/docagent/documents.py:439-440 (export_package:'architecture' in config.documents) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L439-L440]

## EV-18BEA8DF5439

EV-18BEA8DF5439: backend/docagent/documents.py:441-443 (export_package:'data_flow' in config.documents) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L441-L443]

## EV-CA6132A02117

EV-CA6132A02117: backend/docagent/documents.py:444-446 (export_package:'test_cases' in config.documents or 'uat_signoff' in config.documents) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L444-L446]

## EV-E124D9F909D8

EV-E124D9F909D8: backend/docagent/documents.py:32-36 (evidence_text:repository.startswith(('local/', 'demo/'))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L32-L36]

## EV-3DAA6B71B3D0

EV-3DAA6B71B3D0: backend/docagent/documents.py:93-107 (build_sections:kind == 'requirements_signoff') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L93-L107]

## EV-F419A856BBD3

EV-F419A856BBD3: backend/docagent/documents.py:298-298 (document.save:298) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L298-L298]

## EV-99CE91629190

EV-99CE91629190: backend/docagent/documents.py:409-409 (workbook.save:409) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L409-L409]

## EV-BFA82A63A3A3

EV-BFA82A63A3A3: backend/docagent/documents.py:434-435 (export_package:'docx' in config.formats) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L434-L435]

## EV-9409AA8FCDBC

EV-9409AA8FCDBC: backend/docagent/documents.py:436-437 (export_package:'pdf' in config.formats) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L436-L437]

## EV-6D57DBB9BAFE

EV-6D57DBB9BAFE: backend/docagent/documents.py:55-58 (build_sections.findings:f['kind'] in kinds) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L55-L58]

## EV-20D7F17DB778

EV-20D7F17DB778: backend/docagent/documents.py:113-127 (build_sections:kind == 'test_cases') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L113-L127]

## EV-FEE57686FD4E

EV-FEE57686FD4E: backend/docagent/documents.py:473-474 (export_package:file.is_file()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L473-L474]

## EV-3C627943822C

EV-3C627943822C: backend/docagent/documents.py:143-157 (build_sections:kind == 'uat_signoff') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L143-L157]

## EV-29597948FC8F

EV-29597948FC8F: backend/docagent/documents.py:174-188 (build_sections:kind == 'architecture') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L174-L188]

## EV-2D6A25642BD5

EV-2D6A25642BD5: backend/docagent/documents.py:194-208 (build_sections:kind == 'data_flow') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L194-L208]

## EV-EFAC61A9196C

EV-EFAC61A9196C: backend/docagent/documents.py:215-229 (build_sections:kind == 'technology') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/documents.py#L215-L229]

## EV-F6779719A44F

EV-F6779719A44F: backend/docagent/execution.py:18-31 (junit_summary) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/execution.py#L18-L31]

## EV-C1714CE92E4B

EV-C1714CE92E4B: backend/docagent/execution.py:34-48 (execute_tests) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/execution.py#L34-L48]

## EV-EF6850E036D8

EV-EF6850E036D8: backend/docagent/execution.py:19-20 (junit_summary:path.is_symlink() or path.stat().st_size > 5000000) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/execution.py#L19-L20]

## EV-4763AB772547

EV-4763AB772547: backend/docagent/execution.py:36-37 (execute_tests:not cfg.test_execution_enabled) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/execution.py#L36-L37]

## EV-5BFE70C54740

EV-5BFE70C54740: backend/docagent/execution.py:38-39 (execute_tests:not re.fullmatch('[\\w./:-]+@sha256:[a-f0-9]{64}', cfg.test_image)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/execution.py#L38-L39]

## EV-920B45F07654

EV-920B45F07654: backend/docagent/execution.py:40-41 (execute_tests:not shutil.which('docker')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/execution.py#L40-L41]

## EV-2DCCB8EEEE0C

EV-2DCCB8EEEE0C: backend/docagent/execution.py:25-30 (junit_summary:case.find('failure') is not None or case.find('error') is not None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/execution.py#L25-L30]

## EV-EB58F38D2B01

EV-EB58F38D2B01: backend/docagent/execution.py:48-55 (execute_tests.exclude) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/execution.py#L48-L55]

## EV-5FB666AD1864

EV-5FB666AD1864: backend/docagent/execution.py:27-30 (junit_summary:case.find('skipped') is not None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/execution.py#L27-L30]

## EV-EDB2E2C17264

EV-EDB2E2C17264: backend/docagent/execution.py:103-104 (execute_tests:started.returncode) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/execution.py#L103-L104]

## EV-96C2229CA3BA

EV-96C2229CA3BA: backend/docagent/execution.py:136-143 (execute_tests:profile == 'pytest') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/execution.py#L136-L143]

## EV-4B1281AF57B5

EV-4B1281AF57B5: backend/docagent/execution.py:121-122 (execute_tests:check.returncode == 0) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/execution.py#L121-L122]

## EV-F762521FF183

EV-F762521FF183: backend/docagent/github.py:16-19 (GitHubError) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L16-L19]

## EV-23113678431B

EV-23113678431B: backend/docagent/github.py:22-36 (GitHub) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L22-L36]

## EV-3C6DD9F144C3

EV-3C6DD9F144C3: backend/docagent/github.py:150-164 (safe_extract) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L150-L164]

## EV-6BF9876B6E4F

EV-6BF9876B6E4F: backend/docagent/github.py:17-19 (GitHubError.__init__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L17-L19]

## EV-7BEB396B57DA

EV-7BEB396B57DA: backend/docagent/github.py:23-37 (GitHub.__init__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L23-L37]

## EV-C6A38DA91429

EV-C6A38DA91429: backend/docagent/github.py:39-40 (GitHub.__enter__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L39-L40]

## EV-BD15A95483E9

EV-BD15A95483E9: backend/docagent/github.py:42-43 (GitHub.__exit__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L42-L43]

## EV-361987E1EA33

EV-361987E1EA33: backend/docagent/github.py:45-59 (GitHub.request) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L45-L59]

## EV-318E1092B0CB

EV-318E1092B0CB: backend/docagent/github.py:72-73 (GitHub.user) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L72-L73]

## EV-B7495F8E4BB2

EV-B7495F8E4BB2: backend/docagent/github.py:75-88 (GitHub.repositories) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L75-L88]

## EV-4E37C9DFF93B

EV-4E37C9DFF93B: backend/docagent/github.py:91-102 (GitHub.metadata) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L91-L102]

## EV-B076B402C610

EV-B076B402C610: backend/docagent/github.py:104-105 (GitHub.repository) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L104-L105]

## EV-56A7066BAC50

EV-56A7066BAC50: backend/docagent/github.py:107-112 (GitHub.refs) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L107-L112]

## EV-D69FA530A7CC

EV-D69FA530A7CC: backend/docagent/github.py:114-118 (GitHub.resolve) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L114-L118]

## EV-0248256D5ACB

EV-0248256D5ACB: backend/docagent/github.py:120-134 (GitHub.download) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L120-L134]

## EV-DDFD61DBE9A5

EV-DDFD61DBE9A5: backend/docagent/github.py:29-30 (GitHub.__init__:token) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L29-L30]

## EV-31DE4DB71309

EV-31DE4DB71309: backend/docagent/github.py:116-117 (GitHub.resolve:not re.fullmatch('[a-f0-9]{40}', value)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L116-L117]

## EV-DFB195D01908

EV-DFB195D01908: backend/docagent/github.py:122-123 (GitHub.download:response.status_code not in {301, 302, 307}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L122-L123]

## EV-846913BDC484

EV-846913BDC484: backend/docagent/github.py:126-132 (GitHub.download:parsed.scheme != 'https' or parsed.hostname != 'codeload.github.com' or parsed.username or (parsed.port not in {None, 443})) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L126-L132]

## EV-603E6235B453

EV-603E6235B453: backend/docagent/github.py:158-159 (safe_extract:len(members) > max_files) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L158-L159]

## EV-DB7B5E52B814

EV-DB7B5E52B814: backend/docagent/github.py:161-162 (safe_extract:len(prefixes) != 1) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L161-L162]

## EV-2BA780A39D5B

EV-2BA780A39D5B: backend/docagent/github.py:54-57 (GitHub.request:response.status_code in {429, 500, 502, 503, 504} and attempt < 2) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L54-L57]

## EV-3BCFD5977BA4

EV-3BCFD5977BA4: backend/docagent/github.py:58-62 (GitHub.request:response.status_code in {403, 429}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L58-L62]

## EV-15A35DFF3478

EV-15A35DFF3478: backend/docagent/github.py:63-64 (GitHub.request:response.status_code == 401) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L63-L64]

## EV-8A9C7BA084B9

EV-8A9C7BA084B9: backend/docagent/github.py:65-66 (GitHub.request:response.status_code == 404) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L65-L66]

## EV-022B0F3E03B5

EV-022B0F3E03B5: backend/docagent/github.py:67-68 (GitHub.request:response.status_code >= 400) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L67-L68]

## EV-D905F072D68E

EV-D905F072D68E: backend/docagent/github.py:166-179 (safe_extract:not parts or entry.orig_filename.startswith(('/', '\\')) or '\\' in entry.orig_filename or any((p in {'..', '.'} or ':' in p or p.endswith(('.', ' ')) or any((ord(c) < 32 for c in p)) or re.fullmatch('(?i)(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\\..*)?', p) for p in parts))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L166-L179]

## EV-38F72CF1D679

EV-38F72CF1D679: backend/docagent/github.py:180-181 (safe_extract:stat.S_ISLNK(entry.external_attr >> 16)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L180-L181]

## EV-B3D6BFB84FA7

EV-B3D6BFB84FA7: backend/docagent/github.py:183-186 (safe_extract:total > max_bytes or (entry.file_size > 1000000 and entry.file_size > max(entry.compress_size, 1) * 500)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L183-L186]

## EV-C3E01D27B747

EV-C3E01D27B747: backend/docagent/github.py:187-188 (safe_extract:len(parts) == 1 or entry.is_dir()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L187-L188]

## EV-320E52D6000B

EV-320E52D6000B: backend/docagent/github.py:190-191 (safe_extract:relative.casefold() in seen) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L190-L191]

## EV-0F87017C4981

EV-0F87017C4981: backend/docagent/github.py:194-195 (safe_extract:not target.resolve().is_relative_to(root)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L194-L195]

## EV-B9F185D7B84A

EV-B9F185D7B84A: backend/docagent/github.py:138-139 (GitHub.download:stream.status_code != 200) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L138-L139]

## EV-756504C94C9A

EV-756504C94C9A: backend/docagent/github.py:50-52 (GitHub.request:attempt < 2) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L50-L52]

## EV-7CFC20F142F6

EV-7CFC20F142F6: backend/docagent/github.py:141-142 (GitHub.download:archive.tell() + len(chunk) > cfg.max_archive_bytes) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/github.py#L141-L142]

## EV-DC6B53FEDA75

EV-DC6B53FEDA75: backend/docagent/imports.py:7-21 (import_edges) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L7-L21]

## EV-0E1E44B30AA4

EV-0E1E44B30AA4: backend/docagent/imports.py:11-25 (import_edges:'pyproject.toml' in paths) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L11-L25]

## EV-6FC02C03AF67

EV-6FC02C03AF67: backend/docagent/imports.py:39-43 (import_edges.python_target) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L39-L43]

## EV-401822895A60

EV-401822895A60: backend/docagent/imports.py:29-30 (import_edges:package.name in {'src', 'backend', 'lib'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L29-L30]

## EV-B9A2E9349BEA

EV-B9A2E9349BEA: backend/docagent/imports.py:34-37 (import_edges:PurePosixPath(path).name == '__init__.py') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L34-L37]

## EV-5235CD4642FD

EV-5235CD4642FD: backend/docagent/imports.py:17-19 (import_edges:isinstance(packages, dict)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L17-L19]

## EV-2C0CBB04E619

EV-2C0CBB04E619: backend/docagent/imports.py:32-33 (import_edges:parent.name in {'src', 'backend', 'lib'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L32-L33]

## EV-6EFA98C59B1F

EV-6EFA98C59B1F: backend/docagent/imports.py:41-42 (import_edges.python_target:candidate in python_paths) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L41-L42]

## EV-164CF42F8359

EV-164CF42F8359: backend/docagent/imports.py:51-65 (import_edges:source.endswith('.py')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L51-L65]

## EV-90BA7147A367

EV-90BA7147A367: backend/docagent/imports.py:21-24 (import_edges:isinstance(value, str)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L21-L24]

## EV-8B40C028EA88

EV-8B40C028EA88: backend/docagent/imports.py:54-65 (import_edges:level) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L54-L65]

## EV-AE1B2BCD85C6

EV-AE1B2BCD85C6: backend/docagent/imports.py:78-88 (import_edges:not targets and (not level)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L78-L88]

## EV-6E1D2FB5FEC2

EV-6E1D2FB5FEC2: backend/docagent/imports.py:89-97 (import_edges:module.startswith('.')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L89-L97]

## EV-E379D9C86139

EV-E379D9C86139: backend/docagent/imports.py:100-105 (import_edges:source != target and identity not in seen) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L100-L105]

## EV-38281310F763

EV-38281310F763: backend/docagent/imports.py:23-24 (import_edges:not base.is_absolute() and '..' not in base.parts and ('\\' not in value) and (':' not in value)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L23-L24]

## EV-B7C61E1A5697

EV-B7C61E1A5697: backend/docagent/imports.py:55-56 (import_edges:level > len(parent.parts)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L55-L56]

## EV-903D2CBC466B

EV-903D2CBC466B: backend/docagent/imports.py:75-77 (import_edges:found) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L75-L77]

## EV-4041C64DCBD8

EV-4041C64DCBD8: backend/docagent/imports.py:87-88 (import_edges:len(matches) == 1) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L87-L88]

## EV-7D2B28B87054

EV-7D2B28B87054: backend/docagent/imports.py:91-97 (import_edges:target.is_relative_to(root)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L91-L97]

## EV-5F54F8673600

EV-5F54F8673600: backend/docagent/imports.py:85-86 (import_edges:any(found)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/imports.py#L85-L86]

## EV-40FC982544FD

EV-40FC982544FD: backend/docagent/jobs.py:28-32 (start_local_queue) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L28-L32]

## EV-2DA94864B7A3

EV-2DA94864B7A3: backend/docagent/jobs.py:35-39 (stop_local_queue) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L35-L39]

## EV-948916CF6FF2

EV-948916CF6FF2: backend/docagent/jobs.py:42-44 (output_root) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L42-L44]

## EV-3617236689C5

EV-3617236689C5: backend/docagent/jobs.py:47-61 (export_job) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L47-L61]

## EV-5F93C7A86C2B

EV-5F93C7A86C2B: backend/docagent/jobs.py:64-69 (next_version) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L64-L69]

## EV-33DF68ED1D4B

EV-33DF68ED1D4B: backend/docagent/jobs.py:72-73 (WorkerLeaseLost) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L72-L73]

## EV-140C75DDE56D

EV-140C75DDE56D: backend/docagent/jobs.py:76-85 (set_progress) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L76-L85]

## EV-3F93482218E0

EV-3F93482218E0: backend/docagent/jobs.py:88-102 (pin_commit) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L88-L102]

## EV-C5605AC49E91

EV-C5605AC49E91: backend/docagent/jobs.py:107-121 (run_job) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L107-L121]

## EV-D5269F7DA2C3

EV-D5269F7DA2C3: backend/docagent/jobs.py:274-282 (enqueue) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L274-L282]

## EV-83A622ADB217

EV-83A622ADB217: backend/docagent/jobs.py:285-298 (cleanup) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L285-L298]

## EV-05280CAF4E32

EV-05280CAF4E32: backend/docagent/jobs.py:301-315 (recover_jobs) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L301-L315]

## EV-E52AE37FD94B

EV-E52AE37FD94B: backend/docagent/jobs.py:30-31 (start_local_queue:local_queue is not None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L30-L31]

## EV-09D2FBF6B2C6

EV-09D2FBF6B2C6: backend/docagent/jobs.py:38-39 (stop_local_queue:queue is not None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L38-L39]

## EV-71ED16C3835E

EV-71ED16C3835E: backend/docagent/jobs.py:136-148 (run_job.heartbeat) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L136-L148]

## EV-B001DF9F2BD4

EV-B001DF9F2BD4: backend/docagent/jobs.py:275-282 (enqueue:settings().job_backend == 'celery') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L275-L282]

## EV-36B05A79550B

EV-36B05A79550B: backend/docagent/jobs.py:84-85 (set_progress:not changed.rowcount) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L84-L85]

## EV-AB0F1FB0C854

EV-AB0F1FB0C854: backend/docagent/jobs.py:102-103 (pin_commit:not resolved) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L102-L103]

## EV-92419F6051C8

EV-92419F6051C8: backend/docagent/jobs.py:127-128 (run_job:not claimed.rowcount) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L127-L128]

## EV-1D94DEAD557F

EV-1D94DEAD557F: backend/docagent/jobs.py:280-281 (enqueue:local_queue is None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L280-L281]

## EV-F052B543ECB8

EV-F052B543ECB8: backend/docagent/jobs.py:78-82 (db.execute:78) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L78-L82]

## EV-28A2DD905F46

EV-28A2DD905F46: backend/docagent/jobs.py:83-83 (db.commit:83) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L83-L83]

## EV-0E61713AA144

EV-0E61713AA144: backend/docagent/jobs.py:90-97 (db.execute:90) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L90-L97]

## EV-805753E81214

EV-805753E81214: backend/docagent/jobs.py:98-98 (db.commit:98) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L98-L98]

## EV-95AACAFCF316

EV-95AACAFCF316: backend/docagent/jobs.py:111-125 (db.execute:111) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L111-L125]

## EV-60247E4EFD28

EV-60247E4EFD28: backend/docagent/jobs.py:126-126 (db.commit:126) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L126-L126]

## EV-C555458D82CE

EV-C555458D82CE: backend/docagent/jobs.py:158-172 (run_job:config.repository == 'demo/inventory') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L158-L172]

## EV-C6B037C8661D

EV-C6B037C8661D: backend/docagent/jobs.py:188-191 (run_job:config.repository == 'demo/inventory') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L188-L191]

## EV-A6BA680859FA

EV-A6BA680859FA: backend/docagent/jobs.py:198-200 (run_job:config.execute_tests) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L198-L200]

## EV-F261F2408070

EV-F261F2408070: backend/docagent/jobs.py:295-295 (db.execute:295) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L295-L295]

## EV-5DA7C6DF02B7

EV-5DA7C6DF02B7: backend/docagent/jobs.py:296-296 (db.execute:296) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L296-L296]

## EV-06BBA748CBA6

EV-06BBA748CBA6: backend/docagent/jobs.py:297-297 (db.commit:297) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L297-L297]

## EV-2F62590F29D6

EV-2F62590F29D6: backend/docagent/jobs.py:310-318 (recover_jobs:job.status == 'running') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L310-L318]

## EV-C189B781189D

EV-C189B781189D: backend/docagent/jobs.py:320-320 (db.commit:320) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L320-L320]

## EV-55B488499D9D

EV-55B488499D9D: backend/docagent/jobs.py:204-205 (run_job:job.worker_id != worker_id or job.status != 'running') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L204-L205]

## EV-A1CA71AD64EA

EV-A1CA71AD64EA: backend/docagent/jobs.py:216-229 (run_job:previous and previous.analysis) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L216-L229]

## EV-EF199AFD130B

EV-EF199AFD130B: backend/docagent/jobs.py:232-233 (run_job:artifact_storage().version_exists(job.id, job.version)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L232-L233]

## EV-AFFDED72154F

EV-AFFDED72154F: backend/docagent/jobs.py:255-268 (run_job:job and job.worker_id == worker_id) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L255-L268]

## EV-79037F44AE24

EV-79037F44AE24: backend/docagent/jobs.py:174-175 (run_job:private and any((p.provider not in config.consent_providers for p in config.providers))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L174-L175]

## EV-803814B656EA

EV-803814B656EA: backend/docagent/jobs.py:186-186 (db.commit:186) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L186-L186]

## EV-537BFE3F18A8

EV-537BFE3F18A8: backend/docagent/jobs.py:197-197 (db.commit:197) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L197-L197]

## EV-8EB15A3A6D55

EV-8EB15A3A6D55: backend/docagent/jobs.py:248-248 (db.commit:248) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L248-L248]

## EV-0F766EB9A791

EV-0F766EB9A791: backend/docagent/jobs.py:140-144 (heartbeat_db.execute:140) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L140-L144]

## EV-65F1DB0C4B9D

EV-65F1DB0C4B9D: backend/docagent/jobs.py:145-145 (heartbeat_db.commit:145) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L145-L145]

## EV-B2087F8C9967

EV-B2087F8C9967: backend/docagent/jobs.py:268-268 (db.commit:268) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/jobs.py#L268-L268]

## EV-E580624F253F

EV-E580624F253F: backend/docagent/llm.py:25-26 (ProviderFailure) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L25-L26]

## EV-41AE6E18932F

EV-41AE6E18932F: backend/docagent/llm.py:29-43 (call_provider) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L29-L43]

## EV-5EF9DDEE90F5

EV-5EF9DDEE90F5: backend/docagent/llm.py:93-105 (evidence_batches) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L93-L105]

## EV-44FBA0645AB5

EV-44FBA0645AB5: backend/docagent/llm.py:108-122 (enrich) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L108-L122]

## EV-3647B3D5777F

EV-3647B3D5777F: backend/docagent/llm.py:32-33 (call_provider:not key) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L32-L33]

## EV-A1DEBD9F5582

EV-A1DEBD9F5582: backend/docagent/llm.py:34-48 (call_provider:provider == 'openai') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L34-L48]

## EV-706B8DD2923F

EV-706B8DD2923F: backend/docagent/llm.py:50-64 (call_provider:provider == 'anthropic') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L50-L64]

## EV-FB1FB9ECE521

EV-FB1FB9ECE521: backend/docagent/llm.py:67-81 (call_provider:provider == 'gemini') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L67-L81]

## EV-7E432E69C895

EV-7E432E69C895: backend/docagent/llm.py:104-105 (evidence_batches:chunk) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L104-L105]

## EV-B372A9B20BC7

EV-B372A9B20BC7: backend/docagent/llm.py:117-121 (enrich:not config.providers) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L117-L121]

## EV-B3E1DD42FB76

EV-B3E1DD42FB76: backend/docagent/llm.py:123-126 (enrich:private and any((p.provider not in allowed for p in config.providers))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L123-L126]

## EV-FB96CDF50558

EV-FB96CDF50558: backend/docagent/llm.py:130-133 (enrich:len(all_batches) > max_batches) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L130-L133]

## EV-BD831DA6A15F

EV-BD831DA6A15F: backend/docagent/llm.py:99-101 (evidence_batches:chunk and size + length > max_chars) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L99-L101]

## EV-3C8191318CE4

EV-3C8191318CE4: backend/docagent/llm.py:142-152 (enrich:cached) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L142-L152]

## EV-7A2495DD58E6

EV-7A2495DD58E6: backend/docagent/llm.py:192-196 (enrich:result is None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L192-L196]

## EV-CF3334E017A4

EV-CF3334E017A4: backend/docagent/llm.py:197-198 (enrich:db is not None and (not cached)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L197-L198]

## EV-85A808E3157F

EV-85A808E3157F: backend/docagent/llm.py:46-47 (call_provider:result.status != 'completed' or result.output_parsed is None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L46-L47]

## EV-FF8EBC5CA35F

EV-FF8EBC5CA35F: backend/docagent/llm.py:61-62 (call_provider:result.stop_reason != 'end_turn' or result.parsed_output is None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L61-L62]

## EV-4FBE705917A2

EV-4FBE705917A2: backend/docagent/llm.py:82-83 (call_provider:not result.text) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L82-L83]

## EV-89283088F9E2

EV-89283088F9E2: backend/docagent/llm.py:190-191 (enrich:result is not None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L190-L191]

## EV-60D6C3EF5CB6

EV-60D6C3EF5CB6: backend/docagent/llm.py:201-205 (enrich:not req.evidence_ids or any((e not in valid for e in req.evidence_ids))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L201-L205]

## EV-CFA85107F665

EV-CFA85107F665: backend/docagent/llm.py:220-224 (enrich:not scenario.steps or not scenario.expected.strip()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L220-L224]

## EV-277FE92B2B03

EV-277FE92B2B03: backend/docagent/llm.py:187-188 (enrich:not retryable or attempt == 2) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/llm.py#L187-L188]

## EV-FC2EBA81B8C4

EV-FC2EBA81B8C4: backend/docagent/logging_config.py:11-17 (configure_logging) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/logging_config.py#L11-L17]

## EV-9771B970BF60

EV-9771B970BF60: backend/docagent/queue.py:14-23 (create_redis_client) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/queue.py#L14-L23]

## EV-F87D9885E780

EV-F87D9885E780: backend/docagent/queue.py:26-40 (LocalJobQueue) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/queue.py#L26-L40]

## EV-031127C9D371

EV-031127C9D371: backend/docagent/queue.py:15-17 (create_redis_client:config.redis_backend == 'fake') [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/queue.py#L15-L17]

## EV-E57BE018214D

EV-E57BE018214D: backend/docagent/queue.py:29-42 (LocalJobQueue.__init__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/queue.py#L29-L42]

## EV-1856DEAEC0E3

EV-1856DEAEC0E3: backend/docagent/queue.py:44-49 (LocalJobQueue.enqueue) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/queue.py#L44-L49]

## EV-E009DE9AA2A2

EV-E009DE9AA2A2: backend/docagent/queue.py:51-59 (LocalJobQueue._consume_one) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/queue.py#L51-L59]

## EV-875CC75DB5CD

EV-875CC75DB5CD: backend/docagent/queue.py:61-71 (LocalJobQueue.close) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/queue.py#L61-L71]

## EV-D696C00496B8

EV-D696C00496B8: backend/docagent/queue.py:46-47 (LocalJobQueue.enqueue:self.closed) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/queue.py#L46-L47]

## EV-6310FCBC9A2C

EV-6310FCBC9A2C: backend/docagent/queue.py:54-55 (LocalJobQueue._consume_one:job_id is not None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/queue.py#L54-L55]

## EV-6BF685A0003D

EV-6BF685A0003D: backend/docagent/queue.py:63-64 (LocalJobQueue.close:self.closed) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/queue.py#L63-L64]

## EV-A1EDF1FA09E4

EV-A1EDF1FA09E4: backend/docagent/schemas.py:7-8 (StrictModel) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L7-L8]

## EV-69553C54F1F3

EV-69553C54F1F3: backend/docagent/schemas.py:11-14 (Confidence) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L11-L14]

## EV-BE191E96FE9C

EV-BE191E96FE9C: backend/docagent/schemas.py:17-24 (Evidence) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L17-L24]

## EV-35A404DAB01E

EV-35A404DAB01E: backend/docagent/schemas.py:27-34 (Finding) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L27-L34]

## EV-36EB88ECC405

EV-36EB88ECC405: backend/docagent/schemas.py:37-44 (Requirement) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L37-L44]

## EV-CF7387EF9EE0

EV-CF7387EF9EE0: backend/docagent/schemas.py:47-56 (TestCase) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L47-L56]

## EV-32BD2DBF85AD

EV-32BD2DBF85AD: backend/docagent/schemas.py:59-61 (ProviderSelection) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L59-L61]

## EV-A5E907126942

EV-A5E907126942: backend/docagent/schemas.py:75-89 (AnalysisConfig) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L75-L89]

## EV-199D1FC6B600

EV-199D1FC6B600: backend/docagent/schemas.py:119-124 (LLMScenario) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L119-L124]

## EV-6E64E43BEF0B

EV-6E64E43BEF0B: backend/docagent/schemas.py:127-131 (LLMRequirement) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L127-L131]

## EV-D5FA304BAAE5

EV-D5FA304BAAE5: backend/docagent/schemas.py:134-136 (LLMOutput) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L134-L136]

## EV-377D52964F06

EV-377D52964F06: backend/docagent/schemas.py:139-144 (ReviewInput) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L139-L144]

## EV-6892A1468A52

EV-6892A1468A52: backend/docagent/schemas.py:147-155 (ResultInput) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L147-L155]

## EV-B06ED9F0115D

EV-B06ED9F0115D: backend/docagent/schemas.py:158-161 (RequirementEdit) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L158-L161]

## EV-9B3FE3AA5FEB

EV-9B3FE3AA5FEB: backend/docagent/schemas.py:164-167 (CollaboratorInput) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L164-L167]

## EV-A28DC1C8A5B3

EV-A28DC1C8A5B3: backend/docagent/schemas.py:98-101 (AnalysisConfig.valid_repository) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L98-L101]

## EV-A3E4354179F9

EV-A3E4354179F9: backend/docagent/schemas.py:105-108 (AnalysisConfig.valid_ref) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L105-L108]

## EV-5C17BDFA00F3

EV-5C17BDFA00F3: backend/docagent/schemas.py:111-116 (AnalysisConfig.unique) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L111-L116]

## EV-D1CCDAE14BB8

EV-D1CCDAE14BB8: backend/docagent/schemas.py:34-34 (Field(default_factory=dict)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L34-L34]

## EV-5C99779A32C6

EV-5C99779A32C6: backend/docagent/schemas.py:61-61 (Field(min_length=1, max_length=120, pattern='^[a-zA-Z0-9._:/-]+$')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L61-L61]

## EV-981BA12DBDA4

EV-981BA12DBDA4: backend/docagent/schemas.py:76-76 (Field(pattern='^[A-Za-z0-9][A-Za-z0-9-]{0,38}/[A-Za-z0-9_.-]{1,100}$', max_length=140)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L76-L76]

## EV-0D1E7662029A

EV-0D1E7662029A: backend/docagent/schemas.py:77-77 (Field(default='', max_length=250)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L77-L77]

## EV-B7A8B4E73A77

EV-B7A8B4E73A77: backend/docagent/schemas.py:89-89 (Field(default_factory=lambda: DOCUMENTS.copy(), min_length=1)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L89-L89]

## EV-2F600140343B

EV-2F600140343B: backend/docagent/schemas.py:90-90 (Field(default_factory=lambda: ['md', 'docx'], min_length=1)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L90-L90]

## EV-B5B597E446F0

EV-B5B597E446F0: backend/docagent/schemas.py:91-91 (Field(default_factory=list, max_length=3)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L91-L91]

## EV-36A33AD5B519

EV-36A33AD5B519: backend/docagent/schemas.py:92-92 (Field(default_factory=list)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L92-L92]

## EV-B2B4BD1120DB

EV-B2B4BD1120DB: backend/docagent/schemas.py:99-100 (AnalysisConfig.valid_repository:value.split('/')[1] in {'.', '..'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L99-L100]

## EV-8DBAAA308AA5

EV-8DBAAA308AA5: backend/docagent/schemas.py:106-107 (AnalysisConfig.valid_ref:any((ord(c) < 32 for c in value)) or value.startswith('-')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L106-L107]

## EV-D26C6E22BE51

EV-D26C6E22BE51: backend/docagent/schemas.py:114-115 (AnalysisConfig.unique:len({p.provider for p in self.providers}) != len(self.providers)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L114-L115]

## EV-C804B96901A5

EV-C804B96901A5: backend/docagent/schemas.py:131-131 (Field(default_factory=list)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L131-L131]

## EV-D1B158605584

EV-D1B158605584: backend/docagent/schemas.py:142-142 (Field(min_length=1, max_length=4000)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L142-L142]

## EV-4E760EA3C64E

EV-4E760EA3C64E: backend/docagent/schemas.py:143-143 (Field(min_length=64, max_length=64)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L143-L143]

## EV-7DABE7605632

EV-7DABE7605632: backend/docagent/schemas.py:148-148 (Field(min_length=64, max_length=64)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L148-L148]

## EV-9D146E30B276

EV-9D146E30B276: backend/docagent/schemas.py:151-151 (Field(min_length=10, max_length=5000)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L151-L151]

## EV-BC5C38085A6F

EV-BC5C38085A6F: backend/docagent/schemas.py:152-152 (Field(min_length=5, max_length=1000)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L152-L152]

## EV-14BC959388AF

EV-14BC959388AF: backend/docagent/schemas.py:159-159 (Field(min_length=10, max_length=4000)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L159-L159]

## EV-A5E042D1C971

EV-A5E042D1C971: backend/docagent/schemas.py:160-160 (Field(min_length=5, max_length=2000)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L160-L160]

## EV-1301296CA324

EV-1301296CA324: backend/docagent/schemas.py:165-165 (Field(pattern='^[A-Za-z0-9][A-Za-z0-9-]{0,38}$')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/schemas.py#L165-L165]

## EV-5B82008377BC

EV-5B82008377BC: backend/docagent/security.py:34-37 (redact) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/security.py#L34-L37]

## EV-7673861DBB46

EV-7673861DBB46: backend/docagent/security.py:40-47 (redact_object) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/security.py#L40-L47]

## EV-26D4E8C30639

EV-26D4E8C30639: backend/docagent/security.py:50-64 (secret_path) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/security.py#L50-L64]

## EV-3433BB1D0359

EV-3433BB1D0359: backend/docagent/security.py:71-85 (cipher) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/security.py#L71-L85]

## EV-190F4F21B72D

EV-190F4F21B72D: backend/docagent/security.py:88-89 (encrypt) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/security.py#L88-L89]

## EV-597A8BE15A4D

EV-597A8BE15A4D: backend/docagent/security.py:92-93 (decrypt) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/security.py#L92-L93]

## EV-33DC9F9993E2

EV-33DC9F9993E2: backend/docagent/security.py:96-97 (token_hash) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/security.py#L96-L97]

## EV-DE656DDEBA0D

EV-DE656DDEBA0D: backend/docagent/security.py:100-101 (new_token) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/security.py#L100-L101]

## EV-4FE158B6E08A

EV-4FE158B6E08A: backend/docagent/security.py:41-42 (redact_object:isinstance(value, str)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/security.py#L41-L42]

## EV-C1AD1965B88F

EV-C1AD1965B88F: backend/docagent/security.py:43-44 (redact_object:isinstance(value, list)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/security.py#L43-L44]

## EV-825530503161

EV-825530503161: backend/docagent/security.py:45-46 (redact_object:isinstance(value, dict)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/security.py#L45-L46]

## EV-F79BB5F5BEB6

EV-F79BB5F5BEB6: backend/docagent/security.py:74-84 (cipher:not key) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/security.py#L74-L84]

## EV-A70F5DEEFEC1

EV-A70F5DEEFEC1: backend/docagent/storage.py:25-26 (StorageError) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L25-L26]

## EV-974A4EF9EB91

EV-974A4EF9EB91: backend/docagent/storage.py:29-30 (ArtifactNotFound) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L29-L30]

## EV-09309A1FD595

EV-09309A1FD595: backend/docagent/storage.py:33-34 (InvalidArtifactPath) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L33-L34]

## EV-A1FED8CFC0C3

EV-A1FED8CFC0C3: backend/docagent/storage.py:38-48 (storage_errors) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L38-L48]

## EV-754DF011F6EB

EV-754DF011F6EB: backend/docagent/storage.py:51-54 (version_name) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L51-L54]

## EV-B4D8759803E4

EV-B4D8759803E4: backend/docagent/storage.py:57-65 (validate_path) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L57-L65]

## EV-C768A4F4A33D

EV-C768A4F4A33D: backend/docagent/storage.py:68-70 (artifact_key) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L68-L70]

## EV-C040888A19AB

EV-C040888A19AB: backend/docagent/storage.py:74-77 (Download) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L74-L77]

## EV-3A96EE52080D

EV-3A96EE52080D: backend/docagent/storage.py:80-94 (LocalArtifactStorage) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L80-L94]

## EV-36DD4FD45C3D

EV-36DD4FD45C3D: backend/docagent/storage.py:133-147 (S3ArtifactStorage) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L133-L147]

## EV-0405A6A9F2AB

EV-0405A6A9F2AB: backend/docagent/storage.py:245-247 (artifact_storage) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L245-L247]

## EV-27E737A02018

EV-27E737A02018: backend/docagent/storage.py:52-53 (version_name:not isinstance(version, int) or version < 1) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L52-L53]

## EV-8041C86F5B1F

EV-8041C86F5B1F: backend/docagent/storage.py:58-64 (validate_path:not path or any((part in {'', '.', '..'} for part in path.split('/'))) or any((c in path for c in '\\:')) or any((ord(c) < 32 for c in path))) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L58-L64]

## EV-CB7B24D5B51F

EV-CB7B24D5B51F: backend/docagent/storage.py:81-82 (LocalArtifactStorage.__init__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L81-L82]

## EV-9A47F6014F97

EV-9A47F6014F97: backend/docagent/storage.py:84-91 (LocalArtifactStorage.root) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L84-L91]

## EV-708738A1938E

EV-708738A1938E: backend/docagent/storage.py:93-103 (LocalArtifactStorage._path) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L93-L103]

## EV-A4FC2EFF7BF8

EV-A4FC2EFF7BF8: backend/docagent/storage.py:106-111 (LocalArtifactStorage.export_directory) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L106-L111]

## EV-476B8DC72249

EV-476B8DC72249: backend/docagent/storage.py:113-114 (LocalArtifactStorage.version_exists) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L113-L114]

## EV-6D224007E9C0

EV-6D224007E9C0: backend/docagent/storage.py:116-118 (LocalArtifactStorage.read_text) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L116-L118]

## EV-2A2F5D9AF0C3

EV-2A2F5D9AF0C3: backend/docagent/storage.py:120-124 (LocalArtifactStorage.download) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L120-L124]

## EV-DE4A28596070

EV-DE4A28596070: backend/docagent/storage.py:126-130 (LocalArtifactStorage.delete_job) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L126-L130]

## EV-C1F4F121BAF1

EV-C1F4F121BAF1: backend/docagent/storage.py:134-148 (S3ArtifactStorage.__init__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L134-L148]

## EV-D1DF6E750341

EV-D1DF6E750341: backend/docagent/storage.py:161-162 (S3ArtifactStorage._key) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L161-L162]

## EV-714832036B08

EV-714832036B08: backend/docagent/storage.py:164-173 (S3ArtifactStorage.version_exists) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L164-L173]

## EV-DF66E82D1EEF

EV-DF66E82D1EEF: backend/docagent/storage.py:176-190 (S3ArtifactStorage.export_directory) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L176-L190]

## EV-6E51A4602A62

EV-6E51A4602A62: backend/docagent/storage.py:208-213 (S3ArtifactStorage.read_text) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L208-L213]

## EV-A03C3C235B82

EV-A03C3C235B82: backend/docagent/storage.py:215-226 (S3ArtifactStorage.download) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L215-L226]

## EV-D5A97EB7C8D8

EV-D5A97EB7C8D8: backend/docagent/storage.py:228-241 (S3ArtifactStorage.delete_job) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L228-L241]

## EV-1C8E70566379

EV-1C8E70566379: backend/docagent/storage.py:86-87 (LocalArtifactStorage.root:version is not None) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L86-L87]

## EV-D8A9F1E95AE3

EV-D8A9F1E95AE3: backend/docagent/storage.py:89-90 (LocalArtifactStorage.root:root.resolve() != root) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L89-L90]

## EV-52ADE0C491D7

EV-52ADE0C491D7: backend/docagent/storage.py:95-100 (LocalArtifactStorage._path:not path) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L95-L100]

## EV-FEC8447A2EB0

EV-FEC8447A2EB0: backend/docagent/storage.py:101-102 (LocalArtifactStorage._path:target.is_symlink() or not target.resolve().is_relative_to(boundary.resolve())) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L101-L102]

## EV-AFC411A60E61

EV-AFC411A60E61: backend/docagent/storage.py:122-123 (LocalArtifactStorage.download:not target.is_file()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L122-L123]

## EV-B4AA3DD399BD

EV-B4AA3DD399BD: backend/docagent/storage.py:139-144 (S3ArtifactStorage.__init__:cfg.s3_access_key_id.get_secret_value()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L139-L144]

## EV-0717922ECB8F

EV-0717922ECB8F: backend/docagent/storage.py:44-45 (storage_errors:exc.response.get('Error', {}).get('Code') in {'NoSuchKey', '404', 'NotFound'}) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L44-L45]

## EV-2C4642156ECA

EV-2C4642156ECA: backend/docagent/storage.py:109-110 (LocalArtifactStorage.export_directory:self.version_exists(job_id, version)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L109-L110]

## EV-68264F56C677

EV-68264F56C677: backend/docagent/storage.py:129-130 (LocalArtifactStorage.delete_job:root.exists()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L129-L130]

## EV-B1F6B5D06FD7

EV-B1F6B5D06FD7: backend/docagent/storage.py:167-168 (S3ArtifactStorage.version_exists:self.client.list_objects_v2(Bucket=self.bucket, Prefix=prefix, MaxKeys=1).get('Contents')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L167-L168]

## EV-A653545BE035

EV-A653545BE035: backend/docagent/storage.py:178-179 (S3ArtifactStorage.export_directory:self.version_exists(job_id, version)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L178-L179]

## EV-825FBA36638F

EV-825FBA36638F: backend/docagent/storage.py:235-241 (S3ArtifactStorage.delete_job:objects) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L235-L241]

## EV-A88E0AD83A2F

EV-A88E0AD83A2F: backend/docagent/storage.py:191-200 (S3ArtifactStorage.export_directory:file.is_file()) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L191-L200]

## EV-38ACE9BC7356

EV-38ACE9BC7356: backend/docagent/storage.py:239-241 (S3ArtifactStorage.delete_job:result.get('Errors')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/storage.py#L239-L241]

## EV-EBF97153B1F9

EV-EBF97153B1F9: backend/docagent/worker.py:30-33 (analyze_task) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/worker.py#L30-L33]

## EV-3872B9AD15E1

EV-3872B9AD15E1: backend/docagent/worker.py:37-40 (cleanup_task) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/worker.py#L37-L40]

## EV-5BD1A314236F

EV-5BD1A314236F: backend/docagent/worker.py:44-47 (recover_task) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/worker.py#L44-L47]

## EV-3BDF183FC2AA

EV-3BDF183FC2AA: backend/docagent/workflow.py:6-7 (baseline) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/workflow.py#L6-L7]

## EV-B10DD1FCC616

EV-B10DD1FCC616: backend/docagent/workflow.py:10-24 (workflow) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/workflow.py#L10-L24]

## EV-85E27A06F1D7

EV-85E27A06F1D7: backend/docagent/workflow.py:15-26 (workflow:result.baseline_hash == job.baseline_hash) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/workflow.py#L15-L26]

## EV-04AA73A5A431

EV-04AA73A5A431: backend/docagent/workflow.py:30-36 (workflow:review.stage == 'requirements' and review.baseline_hash == job.baseline_hash and (review.decision != 'comment')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/workflow.py#L30-L36]

## EV-13F10C93925B

EV-13F10C93925B: backend/docagent/workflow.py:40-41 (workflow:review.stage == 'uat' and review.baseline_hash == acceptance_hash and (review.decision != 'comment')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/workflow.py#L40-L41]

## EV-9C8E460438A5

EV-9C8E460438A5: backend/docagent/migrations/versions/v001_initial.py:16-30 (upgrade) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L16-L30]

## EV-BB2ADBCEE990

EV-BB2ADBCEE990: backend/docagent/migrations/versions/v001_initial.py:102-104 (downgrade) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L102-L104]

## EV-2BF1EE29CBD4

EV-2BF1EE29CBD4: backend/docagent/migrations/versions/v001_initial.py:19-19 (sa.Column('id', sa.String(64), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L19-L19]

## EV-D8C50DB19C2C

EV-D8C50DB19C2C: backend/docagent/migrations/versions/v001_initial.py:20-20 (sa.Column('owner', sa.String(100), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L20-L20]

## EV-B02932125E31

EV-B02932125E31: backend/docagent/migrations/versions/v001_initial.py:21-21 (sa.Column('login', sa.String(100), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L21-L21]

## EV-540519E37A9A

EV-540519E37A9A: backend/docagent/migrations/versions/v001_initial.py:22-22 (sa.Column('token', sa.Text(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L22-L22]

## EV-52F499CADB32

EV-52F499CADB32: backend/docagent/migrations/versions/v001_initial.py:23-23 (sa.Column('csrf', sa.String(100), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L23-L23]

## EV-543A9D39BAEA

EV-543A9D39BAEA: backend/docagent/migrations/versions/v001_initial.py:24-24 (sa.Column('oauth_state', sa.String(100), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L24-L24]

## EV-D6E506CDDCF6

EV-D6E506CDDCF6: backend/docagent/migrations/versions/v001_initial.py:25-25 (sa.Column('oauth_verifier', sa.String(150), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L25-L25]

## EV-1EACD2C63DA2

EV-1EACD2C63DA2: backend/docagent/migrations/versions/v001_initial.py:26-26 (sa.Column('oauth_started', sa.DateTime())) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L26-L26]

## EV-70D5B4AE0368

EV-70D5B4AE0368: backend/docagent/migrations/versions/v001_initial.py:27-27 (sa.Column('expires', sa.DateTime(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L27-L27]

## EV-395680D066C2

EV-395680D066C2: backend/docagent/migrations/versions/v001_initial.py:32-32 (sa.Column('id', sa.String(36), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L32-L32]

## EV-61343276FE97

EV-61343276FE97: backend/docagent/migrations/versions/v001_initial.py:33-33 (sa.Column('owner', sa.String(100), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L33-L33]

## EV-65954083C368

EV-65954083C368: backend/docagent/migrations/versions/v001_initial.py:34-34 (sa.Column('repository', sa.String(200), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L34-L34]

## EV-DC77CA3343F9

EV-DC77CA3343F9: backend/docagent/migrations/versions/v001_initial.py:35-35 (sa.Column('status', sa.String(30), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L35-L35]

## EV-1F8755643A58

EV-1F8755643A58: backend/docagent/migrations/versions/v001_initial.py:36-36 (sa.Column('progress', sa.Integer(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L36-L36]

## EV-42C802C3E5DD

EV-42C802C3E5DD: backend/docagent/migrations/versions/v001_initial.py:37-37 (sa.Column('message', sa.Text(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L37-L37]

## EV-085C5EEC1D1D

EV-085C5EEC1D1D: backend/docagent/migrations/versions/v001_initial.py:38-38 (sa.Column('config', sa.JSON(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L38-L38]

## EV-0ADBEBBC6A28

EV-0ADBEBBC6A28: backend/docagent/migrations/versions/v001_initial.py:39-39 (sa.Column('analysis', sa.JSON())) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L39-L39]

## EV-51CF5BFD5F3B

EV-51CF5BFD5F3B: backend/docagent/migrations/versions/v001_initial.py:40-40 (sa.Column('baseline_hash', sa.String(64), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L40-L40]

## EV-C2CA6C8826CE

EV-C2CA6C8826CE: backend/docagent/migrations/versions/v001_initial.py:41-41 (sa.Column('version', sa.Integer(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L41-L41]

## EV-7D49CD7389E7

EV-7D49CD7389E7: backend/docagent/migrations/versions/v001_initial.py:42-42 (sa.Column('created', sa.DateTime(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L42-L42]

## EV-FB388A59997E

EV-FB388A59997E: backend/docagent/migrations/versions/v001_initial.py:43-43 (sa.Column('updated', sa.DateTime(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L43-L43]

## EV-8F8DB9BF9746

EV-8F8DB9BF9746: backend/docagent/migrations/versions/v001_initial.py:44-44 (sa.Column('credential', sa.Text(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L44-L44]

## EV-4D1F1FBC8B04

EV-4D1F1FBC8B04: backend/docagent/migrations/versions/v001_initial.py:45-45 (sa.Column('worker_id', sa.String(36), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L45-L45]

## EV-297DC946B12D

EV-297DC946B12D: backend/docagent/migrations/versions/v001_initial.py:46-46 (sa.Column('lease_until', sa.DateTime())) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L46-L46]

## EV-C6BEA3395AF9

EV-C6BEA3395AF9: backend/docagent/migrations/versions/v001_initial.py:51-51 (sa.Column('job_id', sa.String(36), sa.ForeignKey('jobs.id', ondelete='CASCADE'), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L51-L51]

## EV-775DA5802147

EV-775DA5802147: backend/docagent/migrations/versions/v001_initial.py:52-52 (sa.Column('principal', sa.String(100), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L52-L52]

## EV-C8655FC643BB

EV-C8655FC643BB: backend/docagent/migrations/versions/v001_initial.py:53-53 (sa.Column('login', sa.String(100), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L53-L53]

## EV-895539B56D4E

EV-895539B56D4E: backend/docagent/migrations/versions/v001_initial.py:54-54 (sa.Column('role', sa.String(20), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L54-L54]

## EV-D44B94CE8513

EV-D44B94CE8513: backend/docagent/migrations/versions/v001_initial.py:55-55 (sa.Column('created', sa.DateTime(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L55-L55]

## EV-519D779EDE61

EV-519D779EDE61: backend/docagent/migrations/versions/v001_initial.py:59-59 (sa.Column('id', sa.Integer(), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L59-L59]

## EV-BAEF9513AADB

EV-BAEF9513AADB: backend/docagent/migrations/versions/v001_initial.py:60-60 (sa.Column('job_id', sa.String(36), sa.ForeignKey('jobs.id', ondelete='CASCADE'), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L60-L60]

## EV-04655794F0FA

EV-04655794F0FA: backend/docagent/migrations/versions/v001_initial.py:61-61 (sa.Column('baseline_hash', sa.String(64), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L61-L61]

## EV-DD54492ACB5A

EV-DD54492ACB5A: backend/docagent/migrations/versions/v001_initial.py:62-62 (sa.Column('stage', sa.String(30), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L62-L62]

## EV-1C3167B3FA90

EV-1C3167B3FA90: backend/docagent/migrations/versions/v001_initial.py:63-63 (sa.Column('decision', sa.String(30), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L63-L63]

## EV-B11A03F9C66A

EV-B11A03F9C66A: backend/docagent/migrations/versions/v001_initial.py:64-64 (sa.Column('reviewer', sa.String(100), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L64-L64]

## EV-0C705FD85586

EV-0C705FD85586: backend/docagent/migrations/versions/v001_initial.py:65-65 (sa.Column('comment', sa.Text(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L65-L65]

## EV-1A6EF9F48321

EV-1A6EF9F48321: backend/docagent/migrations/versions/v001_initial.py:66-66 (sa.Column('created', sa.DateTime(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L66-L66]

## EV-94616B0DBB48

EV-94616B0DBB48: backend/docagent/migrations/versions/v001_initial.py:71-71 (sa.Column('id', sa.Integer(), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L71-L71]

## EV-E4B22C78E1D2

EV-E4B22C78E1D2: backend/docagent/migrations/versions/v001_initial.py:72-72 (sa.Column('job_id', sa.String(36), sa.ForeignKey('jobs.id', ondelete='CASCADE'), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L72-L72]

## EV-3112CF30EF34

EV-3112CF30EF34: backend/docagent/migrations/versions/v001_initial.py:73-73 (sa.Column('baseline_hash', sa.String(64), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L73-L73]

## EV-E7D0DD7328DF

EV-E7D0DD7328DF: backend/docagent/migrations/versions/v001_initial.py:74-74 (sa.Column('test_case_id', sa.String(80), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L74-L74]

## EV-C329BEC12BC7

EV-C329BEC12BC7: backend/docagent/migrations/versions/v001_initial.py:75-75 (sa.Column('status', sa.String(30), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L75-L75]

## EV-17382FC9B50B

EV-17382FC9B50B: backend/docagent/migrations/versions/v001_initial.py:76-76 (sa.Column('source', sa.String(30), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L76-L76]

## EV-ED04147D7D07

EV-ED04147D7D07: backend/docagent/migrations/versions/v001_initial.py:77-77 (sa.Column('actual', sa.Text(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L77-L77]

## EV-B65A9FCD2AB4

EV-B65A9FCD2AB4: backend/docagent/migrations/versions/v001_initial.py:78-78 (sa.Column('evidence_reference', sa.Text(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L78-L78]

## EV-BBD49ECD4647

EV-BBD49ECD4647: backend/docagent/migrations/versions/v001_initial.py:79-79 (sa.Column('severity', sa.String(20), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L79-L79]

## EV-36B965C86121

EV-36B965C86121: backend/docagent/migrations/versions/v001_initial.py:80-80 (sa.Column('reviewer', sa.String(100), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L80-L80]

## EV-7576DC2BB62E

EV-7576DC2BB62E: backend/docagent/migrations/versions/v001_initial.py:81-81 (sa.Column('created', sa.DateTime(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L81-L81]

## EV-996CF623C337

EV-996CF623C337: backend/docagent/migrations/versions/v001_initial.py:86-86 (sa.Column('id', sa.Integer(), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L86-L86]

## EV-E17155C9F49F

EV-E17155C9F49F: backend/docagent/migrations/versions/v001_initial.py:87-87 (sa.Column('job_id', sa.String(36), sa.ForeignKey('jobs.id', ondelete='CASCADE'), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L87-L87]

## EV-2478794A1F64

EV-2478794A1F64: backend/docagent/migrations/versions/v001_initial.py:88-88 (sa.Column('actor', sa.String(100), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L88-L88]

## EV-88972F2AACCA

EV-88972F2AACCA: backend/docagent/migrations/versions/v001_initial.py:89-89 (sa.Column('action', sa.String(100), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L89-L89]

## EV-1A50EE194E24

EV-1A50EE194E24: backend/docagent/migrations/versions/v001_initial.py:90-90 (sa.Column('detail', sa.JSON(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L90-L90]

## EV-75D98340551D

EV-75D98340551D: backend/docagent/migrations/versions/v001_initial.py:91-91 (sa.Column('created', sa.DateTime(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L91-L91]

## EV-AAB54CA1DB75

EV-AAB54CA1DB75: backend/docagent/migrations/versions/v001_initial.py:96-96 (sa.Column('key', sa.String(64), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L96-L96]

## EV-B8C8311C4C4B

EV-B8C8311C4C4B: backend/docagent/migrations/versions/v001_initial.py:97-97 (sa.Column('payload', sa.JSON(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L97-L97]

## EV-AD1E452F835C

EV-AD1E452F835C: backend/docagent/migrations/versions/v001_initial.py:98-98 (sa.Column('updated', sa.DateTime(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L98-L98]

## EV-B10A08B7DD3A

EV-B10A08B7DD3A: backend/docagent/migrations/versions/v001_initial.py:51-51 (sa.ForeignKey('jobs.id', ondelete='CASCADE')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L51-L51]

## EV-43BAE26E9A8F

EV-43BAE26E9A8F: backend/docagent/migrations/versions/v001_initial.py:60-60 (sa.ForeignKey('jobs.id', ondelete='CASCADE')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L60-L60]

## EV-D546D1D4F045

EV-D546D1D4F045: backend/docagent/migrations/versions/v001_initial.py:72-72 (sa.ForeignKey('jobs.id', ondelete='CASCADE')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L72-L72]

## EV-A671E15BD708

EV-A671E15BD708: backend/docagent/migrations/versions/v001_initial.py:87-87 (sa.ForeignKey('jobs.id', ondelete='CASCADE')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v001_initial.py#L87-L87]

## EV-A56B291D52D4

EV-A56B291D52D4: backend/docagent/migrations/versions/v002_document_versions.py:16-30 (upgrade) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v002_document_versions.py#L16-L30]

## EV-F9F49CAF6930

EV-F9F49CAF6930: backend/docagent/migrations/versions/v002_document_versions.py:53-54 (downgrade) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v002_document_versions.py#L53-L54]

## EV-5AD35729C964

EV-5AD35729C964: backend/docagent/migrations/versions/v002_document_versions.py:43-50 (op.execute:43) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v002_document_versions.py#L43-L50]

## EV-AE448CB2D80E

EV-AE448CB2D80E: backend/docagent/migrations/versions/v002_document_versions.py:19-19 (sa.Column('job_id', sa.String(36), sa.ForeignKey('jobs.id', ondelete='CASCADE'), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v002_document_versions.py#L19-L19]

## EV-1F978955B9B2

EV-1F978955B9B2: backend/docagent/migrations/versions/v002_document_versions.py:20-20 (sa.Column('version', sa.Integer(), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v002_document_versions.py#L20-L20]

## EV-BA7280D56FEB

EV-BA7280D56FEB: backend/docagent/migrations/versions/v002_document_versions.py:21-21 (sa.Column('baseline_hash', sa.String(64), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v002_document_versions.py#L21-L21]

## EV-8F7552D9D705

EV-8F7552D9D705: backend/docagent/migrations/versions/v002_document_versions.py:22-22 (sa.Column('package_sha256', sa.String(64), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v002_document_versions.py#L22-L22]

## EV-6FCB8BB4C9F6

EV-6FCB8BB4C9F6: backend/docagent/migrations/versions/v002_document_versions.py:23-23 (sa.Column('created', sa.DateTime(), nullable=False)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v002_document_versions.py#L23-L23]

## EV-55674BCB1046

EV-55674BCB1046: backend/docagent/migrations/versions/v002_document_versions.py:19-19 (sa.ForeignKey('jobs.id', ondelete='CASCADE')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v002_document_versions.py#L19-L19]

## EV-71C851914463

EV-71C851914463: backend/docagent/migrations/versions/v003_resolved_commit.py:12-13 (upgrade) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v003_resolved_commit.py#L12-L13]

## EV-292A86A3BDD7

EV-292A86A3BDD7: backend/docagent/migrations/versions/v003_resolved_commit.py:16-17 (downgrade) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v003_resolved_commit.py#L16-L17]

## EV-84BE369B4E84

EV-84BE369B4E84: backend/docagent/migrations/versions/v003_resolved_commit.py:13-13 (sa.Column('resolved_commit', sa.String(40), nullable=False, server_default='')) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v003_resolved_commit.py#L13-L13]

## EV-C732E53F55EB

EV-C732E53F55EB: backend/docagent/migrations/versions/v004_job_admission.py:12-14 (upgrade) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v004_job_admission.py#L12-L14]

## EV-2F29A65D13DA

EV-2F29A65D13DA: backend/docagent/migrations/versions/v004_job_admission.py:17-18 (downgrade) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v004_job_admission.py#L17-L18]

## EV-0CD185A9C208

EV-0CD185A9C208: backend/docagent/migrations/versions/v004_job_admission.py:13-13 (sa.Column('id', sa.Integer(), primary_key=True)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/backend/docagent/migrations/versions/v004_job_admission.py#L13-L13]

## EV-601EE49876A7

EV-601EE49876A7: examples/inventory/Dockerfile:1-7 (file) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/Dockerfile#L1-L7]

## EV-533B043EB4E6

EV-533B043EB4E6: examples/inventory/Dockerfile:1-1 (FROM python:3.12-slim) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/Dockerfile#L1-L1]

## EV-0B39940B306C

EV-0B39940B306C: examples/inventory/Dockerfile:6-6 (EXPOSE 8000) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/Dockerfile#L6-L6]

## EV-567CD7E72698

EV-567CD7E72698: examples/inventory/Dockerfile:7-7 (CMD ["uvicorn", "app:app", "--host", "0.0.0.0"]) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/Dockerfile#L7-L7]

## EV-B75DCBACB7E8

EV-B75DCBACB7E8: examples/inventory/Dockerfile:1-1 (file) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/Dockerfile#L1-L1]

## EV-21A1142E8766

EV-21A1142E8766: examples/inventory/README.md:1-7 (file) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/README.md#L1-L7]

## EV-200BBFE2C65A

EV-200BBFE2C65A: examples/inventory/app.py:8-10 (Reservation) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/app.py#L8-L10]

## EV-CA16855F18C4

EV-CA16855F18C4: examples/inventory/app.py:14-16 (list_products) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/app.py#L14-L16]

## EV-AC8AD8AB1C7C

EV-AC8AD8AB1C7C: examples/inventory/app.py:13-16 (list_products:GET:/products) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/app.py#L13-L16]

## EV-345CF8F4F422

EV-345CF8F4F422: examples/inventory/app.py:20-27 (reserve_product) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/app.py#L20-L27]

## EV-2BE0E4A409EE

EV-2BE0E4A409EE: examples/inventory/app.py:19-27 (reserve_product:POST:/reservations) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/app.py#L19-L27]

## EV-5A2E606F392B

EV-5A2E606F392B: examples/inventory/app.py:22-23 (reserve_product:request.sku not in stock) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/app.py#L22-L23]

## EV-35467BDCCC7F

EV-35467BDCCC7F: examples/inventory/app.py:24-25 (reserve_product:request.quantity > stock[request.sku]) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/app.py#L24-L25]

## EV-F40E1895D36A

EV-F40E1895D36A: examples/inventory/app.py:10-10 (Field(gt=0)) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/app.py#L10-L10]

## EV-18A3F654CFA3

EV-18A3F654CFA3: examples/inventory/requirements.txt:1-1 (fastapi) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/requirements.txt#L1-L1]

## EV-7DC00B9E8618

EV-7DC00B9E8618: examples/inventory/requirements.txt:2-2 (pydantic) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/requirements.txt#L2-L2]

## EV-0B33ACCEA6A8

EV-0B33ACCEA6A8: examples/inventory/requirements.txt:3-3 (pytest) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/requirements.txt#L3-L3]

## EV-659D70CBFA5B

EV-659D70CBFA5B: examples/inventory/test_inventory.py:4-5 (test_catalog_contains_products) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/examples/inventory/test_inventory.py#L4-L5]

## EV-1DC6229F6D93

EV-1DC6229F6D93: frontend/package.json:13-13 (lucide-react) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L13-L13]

## EV-3A3E28901B0A

EV-3A3E28901B0A: frontend/package.json:14-14 (react) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L14-L14]

## EV-4B9289E5DBDA

EV-4B9289E5DBDA: frontend/package.json:15-15 (react-dom) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L15-L15]

## EV-C53CA2AFA97B

EV-C53CA2AFA97B: frontend/package.json:16-16 (react-markdown) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L16-L16]

## EV-E13CCAD40C43

EV-E13CCAD40C43: frontend/package.json:17-17 (remark-gfm) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L17-L17]

## EV-FE132CEE8653

EV-FE132CEE8653: frontend/package.json:20-20 (@testing-library/jest-dom) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L20-L20]

## EV-DB871E70F0A8

EV-DB871E70F0A8: frontend/package.json:21-21 (@testing-library/react) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L21-L21]

## EV-B0C00281EF28

EV-B0C00281EF28: frontend/package.json:22-22 (@testing-library/user-event) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L22-L22]

## EV-A4B544753895

EV-A4B544753895: frontend/package.json:23-23 (@types/react) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L23-L23]

## EV-B857FE2FB376

EV-B857FE2FB376: frontend/package.json:24-24 (@types/react-dom) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L24-L24]

## EV-AC4723660053

EV-AC4723660053: frontend/package.json:25-25 (@vitejs/plugin-react) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L25-L25]

## EV-3E3F600036B7

EV-3E3F600036B7: frontend/package.json:26-26 (jsdom) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L26-L26]

## EV-6BF46E504F0B

EV-6BF46E504F0B: frontend/package.json:27-27 (prettier) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L27-L27]

## EV-82FCA2D0021F

EV-82FCA2D0021F: frontend/package.json:28-28 (typescript) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L28-L28]

## EV-EDF5329227A1

EV-EDF5329227A1: frontend/package.json:29-29 (vite) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L29-L29]

## EV-6758AF8AA44D

EV-6758AF8AA44D: frontend/package.json:30-30 (vitest) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L30-L30]

## EV-38DF9E132199

EV-38DF9E132199: frontend/package.json:1-1 (dev) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L1-L1]

## EV-7027CA0CE3CF

EV-7027CA0CE3CF: frontend/package.json:1-1 (build) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L1-L1]

## EV-C812BE2678EB

EV-C812BE2678EB: frontend/package.json:1-1 (preview) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L1-L1]

## EV-1745ED584C04

EV-1745ED584C04: frontend/package.json:1-1 (test) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/package.json#L1-L1]

## EV-219CFA07936B

EV-219CFA07936B: frontend/src/App.tsx:16-30 (App) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/App.tsx#L16-L30]

## EV-E80B16EC7CA3

EV-E80B16EC7CA3: frontend/src/App.tsx:51-61 (act) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/App.tsx#L51-L61]

## EV-14A54721B458

EV-14A54721B458: frontend/src/App.tsx:62-67 (openJob) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/App.tsx#L62-L67]

## EV-E32C7E53EA90

EV-E32C7E53EA90: frontend/src/App.tsx:68-74 (demo) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/App.tsx#L68-L74]

## EV-463AD9602143

EV-463AD9602143: frontend/src/App.tsx:75-79 (choose) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/App.tsx#L75-L79]

## EV-4EF1BB88041D

EV-4EF1BB88041D: frontend/src/App.tsx:82-91 (openRepository) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/App.tsx#L82-L91]

## EV-19605DFEACF1

EV-19605DFEACF1: frontend/src/App.tsx:92-104 (account) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/App.tsx#L92-L104]

## EV-F24E72B3EFCE

EV-F24E72B3EFCE: frontend/src/api.ts:2-4 (setCsrf) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/api.ts#L2-L4]

## EV-8A3B0646FA3F

EV-8A3B0646FA3F: frontend/src/api.ts:5-19 (api) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/api.ts#L5-L19]

## EV-78C69687E76A

EV-78C69687E76A: frontend/src/api.ts:32-38 (repositoryName) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/api.ts#L32-L38]

## EV-024CDC5D5D2C

EV-024CDC5D5D2C: frontend/src/types.ts:10-17 (Session) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/types.ts#L10-L17]

## EV-2D8D708DD940

EV-2D8D708DD940: frontend/src/types.ts:18-28 (Repository) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/types.ts#L18-L28]

## EV-72448CFF5C29

EV-72448CFF5C29: frontend/src/types.ts:29-37 (Evidence) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/types.ts#L29-L37]

## EV-F863B15C3C52

EV-F863B15C3C52: frontend/src/types.ts:38-46 (Requirement) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/types.ts#L38-L46]

## EV-0394B66DAC40

EV-0394B66DAC40: frontend/src/types.ts:47-55 (Case) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/types.ts#L47-L55]

## EV-5C2C1E5A8C7F

EV-5C2C1E5A8C7F: frontend/src/types.ts:56-64 (Finding) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/types.ts#L56-L64]

## EV-28E9932C002F

EV-28E9932C002F: frontend/src/types.ts:65-72 (TestResult) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/types.ts#L65-L72]

## EV-C60B723C3ED3

EV-C60B723C3ED3: frontend/src/types.ts:73-87 (Workflow) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/types.ts#L73-L87]

## EV-66BA1702ACFF

EV-66BA1702ACFF: frontend/src/types.ts:90-104 (Analysis) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/types.ts#L90-L104]

## EV-571A2FBB08B0

EV-571A2FBB08B0: frontend/src/types.ts:120-134 (Job) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/types.ts#L120-L134]

## EV-8DF534F1227B

EV-8DF534F1227B: frontend/src/types.ts:135-138 (Artifact) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/types.ts#L135-L138]

## EV-12580CD493D6

EV-12580CD493D6: frontend/src/types.ts:140-146 (AuditEntry) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/types.ts#L140-L146]

## EV-7165A82E8C2B

EV-7165A82E8C2B: frontend/src/components/AccessPanel.tsx:6-20 (AccessPanel) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/AccessPanel.tsx#L6-L20]

## EV-AD43EB8873B0

EV-AD43EB8873B0: frontend/src/components/AppShell.tsx:16-30 (AppShell) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/AppShell.tsx#L16-L30]

## EV-2637070F4FE9

EV-2637070F4FE9: frontend/src/components/AuthDialog.tsx:4-18 (AuthDialog) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/AuthDialog.tsx#L4-L18]

## EV-017942286ED4

EV-017942286ED4: frontend/src/components/Configure.tsx:17-31 (Configure) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/Configure.tsx#L17-L31]

## EV-1C7B84F7675E

EV-1C7B84F7675E: frontend/src/components/EditModal.tsx:5-19 (EditModal) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/EditModal.tsx#L5-L19]

## EV-FC0E3FA411B8

EV-FC0E3FA411B8: frontend/src/components/EvidenceList.tsx:5-19 (EvidenceList) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/EvidenceList.tsx#L5-L19]

## EV-48F97AA590D2

EV-48F97AA590D2: frontend/src/components/Modal.tsx:5-19 (Modal) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/Modal.tsx#L5-L19]

## EV-C92A442C9399

EV-C92A442C9399: frontend/src/components/Report.test.tsx:11-25 (reportJob) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/Report.test.tsx#L11-L25]

## EV-91EB36056591

EV-91EB36056591: frontend/src/components/Report.tsx:18-32 (Report) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/Report.tsx#L18-L32]

## EV-15451DFC4D2C

EV-15451DFC4D2C: frontend/src/components/Report.tsx:43-55 (mutate) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/Report.tsx#L43-L55]

## EV-48F1C1F68C93

EV-48F1C1F68C93: frontend/src/components/ResultModal.tsx:5-19 (ResultModal) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/ResultModal.tsx#L5-L19]

## EV-EDE6D4E3279C

EV-EDE6D4E3279C: frontend/src/components/ReviewModal.tsx:5-19 (ReviewModal) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/ReviewModal.tsx#L5-L19]

## EV-239316FEFF4F

EV-239316FEFF4F: frontend/src/components/report/ActivityTab.tsx:4-18 (ActivityTab) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/report/ActivityTab.tsx#L4-L18]

## EV-A26BBBAE4AC4

EV-A26BBBAE4AC4: frontend/src/components/report/AnalysisProgress.tsx:3-17 (AnalysisProgress) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/report/AnalysisProgress.tsx#L3-L17]

## EV-51BB247E1687

EV-51BB247E1687: frontend/src/components/report/DiagramsTab.tsx:4-18 (DiagramsTab) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/report/DiagramsTab.tsx#L4-L18]

## EV-84DA533F6AA8

EV-84DA533F6AA8: frontend/src/components/report/DocumentsTab.tsx:9-23 (DocumentsTab) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/report/DocumentsTab.tsx#L9-L23]

## EV-B6C49F2D09E2

EV-B6C49F2D09E2: frontend/src/components/report/OverviewTab.tsx:3-17 (OverviewTab) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/report/OverviewTab.tsx#L3-L17]

## EV-90C30FB9EA15

EV-90C30FB9EA15: frontend/src/components/report/RecordsPanel.tsx:3-8 (RecordControls) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/report/RecordsPanel.tsx#L3-L8]

## EV-374B7239E1A3

EV-374B7239E1A3: frontend/src/components/report/RecordsPanel.tsx:9-23 (RecordsPanel) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/report/RecordsPanel.tsx#L9-L23]

## EV-27FCA5C2E5CB

EV-27FCA5C2E5CB: frontend/src/components/report/ReportHeader.tsx:11-25 (ReportHeader) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/report/ReportHeader.tsx#L11-L25]

## EV-B6542F03A1E2

EV-B6542F03A1E2: frontend/src/components/report/RequirementsTab.tsx:7-21 (RequirementsTab) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/report/RequirementsTab.tsx#L7-L21]

## EV-A83F31BDE67F

EV-A83F31BDE67F: frontend/src/components/report/TestsTab.tsx:5-19 (TestsTab) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/report/TestsTab.tsx#L5-L19]

## EV-9354D1731984

EV-9354D1731984: frontend/src/components/workspace/RepositoryPicker.tsx:13-18 (RepositoryFilters) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/workspace/RepositoryPicker.tsx#L13-L18]

## EV-FF0191341242

EV-FF0191341242: frontend/src/components/workspace/RepositoryPicker.tsx:19-33 (RepositoryPicker) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/workspace/RepositoryPicker.tsx#L19-L33]

## EV-D337FF57A046

EV-D337FF57A046: frontend/src/components/workspace/WorkspaceFooter.tsx:3-17 (WorkspaceFooter) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/workspace/WorkspaceFooter.tsx#L3-L17]

## EV-F4A641557521

EV-F4A641557521: frontend/src/components/workspace/WorkspaceIntro.tsx:14-28 (WorkspaceIntro) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/components/workspace/WorkspaceIntro.tsx#L14-L28]

## EV-4F9F72A1D4D3

EV-4F9F72A1D4D3: frontend/src/hooks/useJobPolling.ts:7-21 (useJobPolling) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/hooks/useJobPolling.ts#L7-L21]

## EV-70573A1F7F24

EV-70573A1F7F24: frontend/src/hooks/useJobPolling.ts:20-34 (poll) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/hooks/useJobPolling.ts#L20-L34]

## EV-0CB0F65B94D8

EV-0CB0F65B94D8: frontend/src/hooks/useReportArtifacts.ts:4-18 (useReportArtifacts) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/hooks/useReportArtifacts.ts#L4-L18]

## EV-A3573C076530

EV-A3573C076530: frontend/src/hooks/useRepositories.ts:4-18 (useRepositories) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/frontend/src/hooks/useRepositories.ts#L4-L18]

## EV-AAA9A2E18AFC

EV-AAA9A2E18AFC: tests/conftest.py:16-30 (isolated) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/conftest.py#L16-L30]

## EV-7DDEC46D10C1

EV-7DDEC46D10C1: tests/conftest.py:38-46 (client) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/conftest.py#L38-L46]

## EV-2FF782F02D84

EV-2FF782F02D84: tests/conftest.py:50-59 (completed) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/conftest.py#L50-L59]

## EV-018A557FFB07

EV-018A557FFB07: tests/conftest.py:63-71 (reviewer) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/conftest.py#L63-L71]

## EV-8167811A6B26

EV-8167811A6B26: tests/conftest.py:70-70 (db.commit:70) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/conftest.py#L70-L70]

## EV-5D2C291D6A9C

EV-5D2C291D6A9C: tests/test_admission.py:12-26 (test_concurrent_admission_cannot_exceed_limits) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_admission.py#L12-L26]

## EV-9C7608AB0520

EV-9C7608AB0520: tests/test_admission.py:23-37 (test_concurrent_admission_cannot_exceed_limits.GitHub) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_admission.py#L23-L37]

## EV-7584831BFB66

EV-7584831BFB66: tests/test_admission.py:24-25 (test_concurrent_admission_cannot_exceed_limits.GitHub.__init__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_admission.py#L24-L25]

## EV-687F20B28F68

EV-687F20B28F68: tests/test_admission.py:27-28 (test_concurrent_admission_cannot_exceed_limits.GitHub.__enter__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_admission.py#L27-L28]

## EV-D20F5B80FE96

EV-D20F5B80FE96: tests/test_admission.py:30-31 (test_concurrent_admission_cannot_exceed_limits.GitHub.__exit__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_admission.py#L30-L31]

## EV-6AAB72BC9A1A

EV-6AAB72BC9A1A: tests/test_admission.py:33-37 (test_concurrent_admission_cannot_exceed_limits.GitHub.repository) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_admission.py#L33-L37]

## EV-646F8946AC48

EV-646F8946AC48: tests/test_admission.py:20-20 (db.commit:20) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_admission.py#L20-L20]

## EV-83A2EFBCF865

EV-83A2EFBCF865: tests/test_analysis.py:11-20 (archive) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_analysis.py#L11-L20]

## EV-8C715B1F2F72

EV-8C715B1F2F72: tests/test_analysis.py:35-37 (test_archive_rejects_unsafe_paths) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_analysis.py#L35-L37]

## EV-0140DFE6C4F0

EV-0140DFE6C4F0: tests/test_analysis.py:40-44 (test_archive_rejects_links_and_expansion) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_analysis.py#L40-L44]

## EV-FE565F4355C1

EV-FE565F4355C1: tests/test_analysis.py:47-49 (test_archive_valid) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_analysis.py#L47-L49]

## EV-47AEFA255292

EV-47AEFA255292: tests/test_analysis.py:52-57 (test_redaction) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_analysis.py#L52-L57]

## EV-2FCD37B89A59

EV-2FCD37B89A59: tests/test_analysis.py:60-71 (test_python_evidence_and_no_execution) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_analysis.py#L60-L71]

## EV-5D9BDEFCCDCA

EV-5D9BDEFCCDCA: tests/test_analysis.py:74-76 (test_tree_sitter_typescript) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_analysis.py#L74-L76]

## EV-5B46637B1E44

EV-5B46637B1E44: tests/test_analysis.py:79-84 (test_extensionless_readme_is_analyzed) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_analysis.py#L79-L84]

## EV-814C5C2C5A55

EV-814C5C2C5A55: tests/test_analysis.py:87-101 (test_incremental_and_stable_ids) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_analysis.py#L87-L101]

## EV-E42735EE18BC

EV-E42735EE18BC: tests/test_analysis.py:96-96 (db.commit:96) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_analysis.py#L96-L96]

## EV-BCD088D62E6A

EV-BCD088D62E6A: tests/test_api.py:7-12 (test_csrf_and_secret_validation) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_api.py#L7-L12]

## EV-12F9EFE00A83

EV-12F9EFE00A83: tests/test_api.py:15-29 (test_demo_exports_and_isolation) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_api.py#L15-L29]

## EV-51401D06CED4

EV-51401D06CED4: tests/test_api.py:38-50 (test_no_automatic_approval) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_api.py#L38-L50]

## EV-758800B8CBF7

EV-758800B8CBF7: tests/test_api.py:53-67 (test_baseline_edit_invalidates_approval) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_api.py#L53-L67]

## EV-09738607FE32

EV-09738607FE32: tests/test_api.py:82-93 (test_uat_cannot_approve_without_evidence) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_api.py#L82-L93]

## EV-C4A89D1C7EBD

EV-C4A89D1C7EBD: tests/test_api.py:96-109 (test_recorded_result_needs_attestation) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_api.py#L96-L109]

## EV-52A29F65A1A2

EV-52A29F65A1A2: tests/test_api.py:112-122 (test_uncommitted_version_is_not_downloadable) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_api.py#L112-L122]

## EV-54C6366C09C5

EV-54C6366C09C5: tests/test_cli.py:9-23 (test_sibling_cli_scans_have_independent_packages) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_cli.py#L9-L23]

## EV-FE76D601CD6A

EV-FE76D601CD6A: tests/test_cli.py:31-42 (test_cli_does_not_overwrite_an_existing_zip) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_cli.py#L31-L42]

## EV-472DF5C7A053

EV-472DF5C7A053: tests/test_github.py:6-17 (test_github_resolves_refs_and_sends_token_only_in_header) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_github.py#L6-L17]

## EV-6AB451061CA1

EV-6AB451061CA1: tests/test_github.py:20-26 (test_untrusted_archive_redirect_is_rejected) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_github.py#L20-L26]

## EV-2C8A42A252EC

EV-2C8A42A252EC: tests/test_github.py:29-34 (test_errors_do_not_echo_provider_response) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_github.py#L29-L34]

## EV-051DD202C6EA

EV-051DD202C6EA: tests/test_github.py:37-46 (test_private_consent_prevents_job_creation) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_github.py#L37-L46]

## EV-35D755BF36B9

EV-35D755BF36B9: tests/test_github.py:49-63 (test_pat_login_rotates_session_and_encrypts_token) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_github.py#L49-L63]

## EV-D778CEE15C45

EV-D778CEE15C45: tests/test_github.py:67-76 (test_oauth_state_is_single_use_and_expires) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_github.py#L67-L76]

## EV-3261DB0C13F0

EV-3261DB0C13F0: tests/test_github.py:9-11 (test_github_resolves_refs_and_sends_token_only_in_header.handler) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_github.py#L9-L11]

## EV-59F2251C716E

EV-59F2251C716E: tests/test_imports.py:6-15 (test_python_package_roots) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_imports.py#L6-L15]

## EV-89D4DF62D28D

EV-89D4DF62D28D: tests/test_imports.py:18-30 (test_all_relative_modules_and_package_initializers_are_retained) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_imports.py#L18-L30]

## EV-3EE1DE2541AE

EV-3EE1DE2541AE: tests/test_imports.py:33-40 (test_declared_namespace_source_root) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_imports.py#L33-L40]

## EV-FEB2F1E0C927

EV-FEB2F1E0C927: tests/test_imports.py:43-50 (test_ambiguous_packages_are_not_falsely_linked) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_imports.py#L43-L50]

## EV-D09187AD6055

EV-D09187AD6055: tests/test_imports.py:53-61 (test_repository_root_initializer_and_source_root_precedence) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_imports.py#L53-L61]

## EV-D4760EA618C3

EV-D4760EA618C3: tests/test_jobs.py:8-22 (test_worker_recovery_reuses_the_persisted_commit) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L8-L22]

## EV-E484DFCA4CAB

EV-E484DFCA4CAB: tests/test_jobs.py:64-78 (test_replaced_workers_cannot_pin_commits_or_change_progress) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L64-L78]

## EV-77E4BE55A555

EV-77E4BE55A555: tests/test_jobs.py:21-35 (test_worker_recovery_reuses_the_persisted_commit.GitHub) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L21-L35]

## EV-9BF8BE94D875

EV-9BF8BE94D875: tests/test_jobs.py:22-23 (test_worker_recovery_reuses_the_persisted_commit.GitHub.__init__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L22-L23]

## EV-D07E990955A0

EV-D07E990955A0: tests/test_jobs.py:25-26 (test_worker_recovery_reuses_the_persisted_commit.GitHub.__enter__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L25-L26]

## EV-BE72E5A29F03

EV-BE72E5A29F03: tests/test_jobs.py:28-29 (test_worker_recovery_reuses_the_persisted_commit.GitHub.__exit__) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L28-L29]

## EV-56A9574B1E1E

EV-56A9574B1E1E: tests/test_jobs.py:31-32 (test_worker_recovery_reuses_the_persisted_commit.GitHub.repository) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L31-L32]

## EV-BD5BFD1318B9

EV-BD5BFD1318B9: tests/test_jobs.py:34-36 (test_worker_recovery_reuses_the_persisted_commit.GitHub.resolve) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L34-L36]

## EV-FB8702786012

EV-FB8702786012: tests/test_jobs.py:38-43 (test_worker_recovery_reuses_the_persisted_commit.GitHub.download) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L38-L43]

## EV-DFB0596D1025

EV-DFB0596D1025: tests/test_jobs.py:17-17 (db.commit:17) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L17-L17]

## EV-ACEB083AAFE0

EV-ACEB083AAFE0: tests/test_jobs.py:53-53 (db.commit:53) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L53-L53]

## EV-04DCA0D6715E

EV-04DCA0D6715E: tests/test_jobs.py:71-71 (db.commit:71) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L71-L71]

## EV-C0CE1B3AAD5A

EV-C0CE1B3AAD5A: tests/test_jobs.py:83-83 (db.commit:83) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_jobs.py#L83-L83]

## EV-88D492970CDF

EV-88D492970CDF: tests/test_live_commands.py:16-30 (test_compose_overrides_preserve_credentials_and_host_configuration) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_live_commands.py#L16-L30]

## EV-5E947AD528B5

EV-5E947AD528B5: tests/test_live_commands.py:41-46 (test_compose_generator_refuses_to_replace_host_env) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_live_commands.py#L41-L46]

## EV-F1735610A324

EV-F1735610A324: tests/test_live_commands.py:49-56 (test_compose_reuses_external_infrastructure) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_live_commands.py#L49-L56]

## EV-5DBAA12F0504

EV-5DBAA12F0504: tests/test_live_commands.py:59-73 (test_service_errors_do_not_expose_credentials) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_live_commands.py#L59-L73]

## EV-6701D6B370D7

EV-6701D6B370D7: tests/test_live_commands.py:79-86 (test_redis_probe_preserves_unrelated_keys) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_live_commands.py#L79-L86]

## EV-A3134CA89C2C

EV-A3134CA89C2C: tests/test_live_commands.py:90-99 (test_storage_probe_preserves_unrelated_artifacts) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_live_commands.py#L90-L99]

## EV-39E41752508E

EV-39E41752508E: tests/test_live_commands.py:65-66 (test_service_errors_do_not_expose_credentials.fail) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_live_commands.py#L65-L66]

## EV-1A398DC0B09A

EV-1A398DC0B09A: tests/test_llm.py:7-9 (sample) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_llm.py#L7-L9]

## EV-BC6F73C3AAEA

EV-BC6F73C3AAEA: tests/test_llm.py:12-17 (test_private_consent_blocks_before_call) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_llm.py#L12-L17]

## EV-A4A508294194

EV-A4A508294194: tests/test_llm.py:20-34 (test_fallback_and_invalid_citations) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_llm.py#L20-L34]

## EV-E51E48EA606E

EV-E51E48EA606E: tests/test_llm.py:52-66 (test_unchanged_evidence_reuses_ai_cache) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_llm.py#L52-L66]

## EV-D961B15392E6

EV-D961B15392E6: tests/test_llm.py:74-88 (test_ai_scenarios_are_traceable_and_never_executed) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_llm.py#L74-L88]

## EV-51F87A20AB37

EV-51F87A20AB37: tests/test_llm.py:29-43 (test_fallback_and_invalid_citations.invoke) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_llm.py#L29-L43]

## EV-D4A18B8104C1

EV-D4A18B8104C1: tests/test_llm.py:62-64 (test_unchanged_evidence_reuses_ai_cache.invoke) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_llm.py#L62-L64]

## EV-86C8AA3434A8

EV-86C8AA3434A8: tests/test_llm.py:78-92 (test_ai_scenarios_are_traceable_and_never_executed.invoke) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_llm.py#L78-L92]

## EV-740BA0E9BB82

EV-740BA0E9BB82: tests/test_llm.py:68-68 (db.commit:68) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_llm.py#L68-L68]

## EV-5A470A050F17

EV-5A470A050F17: tests/test_logging.py:13-20 (restore_logging) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_logging.py#L13-L20]

## EV-372F6BF1F168

EV-372F6BF1F168: tests/test_logging.py:26-28 (test_log_level_environment_is_case_insensitive) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_logging.py#L26-L28]

## EV-2DB10BBBC7A3

EV-2DB10BBBC7A3: tests/test_logging.py:31-34 (test_invalid_log_level_is_rejected) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_logging.py#L31-L34]

## EV-6B9BA1C5FB68

EV-6B9BA1C5FB68: tests/test_logging.py:37-50 (test_debug_logs_application_without_enabling_sdk_request_logging) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_logging.py#L37-L50]

## EV-9F2FA56D1BC2

EV-9F2FA56D1BC2: tests/test_logging.py:54-68 (test_serve_passes_effective_level_and_keeps_access_logs_disabled) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_logging.py#L54-L68]

## EV-E46010316E8F

EV-E46010316E8F: tests/test_logging.py:72-85 (test_worker_and_scheduler_forward_configured_level) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_logging.py#L72-L85]

## EV-A3EB787BAF4F

EV-A3EB787BAF4F: tests/test_queue.py:13-17 (forbid_real_redis) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_queue.py#L13-L17]

## EV-1D41D0898AD8

EV-1D41D0898AD8: tests/test_queue.py:20-32 (test_default_fake_client_ignores_real_url) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_queue.py#L20-L32]

## EV-F8AE7EBB1692

EV-F8AE7EBB1692: tests/test_queue.py:35-49 (test_fake_queue_consumes_fifo_and_drains_on_shutdown) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_queue.py#L35-L49]

## EV-DCE6C5CAFEB6

EV-DCE6C5CAFEB6: tests/test_queue.py:63-70 (test_real_client_uses_configured_url) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_queue.py#L63-L70]

## EV-C62D16363358

EV-C62D16363358: tests/test_queue.py:73-80 (test_unavailable_real_redis_fails_without_silent_fallback) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_queue.py#L73-L80]

## EV-1417E86B5D5A

EV-1417E86B5D5A: tests/test_queue.py:91-93 (test_invalid_queue_configuration) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_queue.py#L91-L93]

## EV-A66391FBEA68

EV-A66391FBEA68: tests/test_queue.py:96-107 (test_production_requires_real_redis) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_queue.py#L96-L107]

## EV-7FCD67673018

EV-7FCD67673018: tests/test_queue.py:110-124 (test_demo_runs_through_fake_queue_without_redis) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_queue.py#L110-L124]

## EV-0BB9D2AFCEC2

EV-0BB9D2AFCEC2: tests/test_queue.py:14-15 (forbid_real_redis.fail) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_queue.py#L14-L15]

## EV-D13A002BF1FE

EV-D13A002BF1FE: tests/test_queue.py:40-44 (test_fake_queue_consumes_fifo_and_drains_on_shutdown.handle) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_queue.py#L40-L44]

## EV-C526D96EA61C

EV-C526D96EA61C: tests/test_queue.py:118-122 (test_demo_runs_through_fake_queue_without_redis.run_and_signal) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_queue.py#L118-L122]

## EV-74A538504B72

EV-74A538504B72: tests/test_requirements.py:4-18 (test_handler_guards_form_one_traceable_requirement) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_requirements.py#L4-L18]

## EV-13886BE840A8

EV-13886BE840A8: tests/test_requirements.py:27-41 (test_models_group_constraints_and_keep_internal_helpers_in_findings) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_requirements.py#L27-L41]

## EV-E93BCD137F7A

EV-E93BCD137F7A: tests/test_requirements.py:48-54 (test_group_ids_survive_unrelated_declarations) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_requirements.py#L48-L54]

## EV-48440F20CD38

EV-48440F20CD38: tests/test_requirements.py:57-61 (test_frontend_component_tests_are_not_acceptance_requirements) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_requirements.py#L57-L61]

## EV-FBD74888A56F

EV-FBD74888A56F: tests/test_storage.py:29-43 (s3) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L29-L43]

## EV-E202D46D3F82

EV-E202D46D3F82: tests/test_storage.py:49-51 (config) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L49-L51]

## EV-734ECEB4ED7C

EV-734ECEB4ED7C: tests/test_storage.py:69-72 (test_invalid_s3_settings) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L69-L72]

## EV-5E80B21D44ED

EV-5E80B21D44ED: tests/test_storage.py:75-89 (test_minio_configuration_and_credential_chain) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L75-L89]

## EV-FE68650AEB64

EV-FE68650AEB64: tests/test_storage.py:100-114 (test_storage_roundtrip_and_isolation) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L100-L114]

## EV-C38C97146A15

EV-C38C97146A15: tests/test_storage.py:132-146 (test_s3_generation_previews_downloads_history_and_retention) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L132-L146]

## EV-5DDA7412E5F9

EV-5DDA7412E5F9: tests/test_storage.py:192-206 (test_partial_upload_is_not_committed_and_retry_skips_it) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L192-L206]

## EV-4461BC00049C

EV-4461BC00049C: tests/test_storage.py:225-231 (test_s3_error_is_sanitized_and_download_scratch_is_removed) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L225-L231]

## EV-F98CBF06B81D

EV-F98CBF06B81D: tests/test_storage.py:234-248 (test_s3_failed_review_preserves_committed_version) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L234-L248]

## EV-EA097B0A1FF2

EV-EA097B0A1FF2: tests/test_storage.py:257-269 (test_cleanup_failure_retains_records_for_retry) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L257-L269]

## EV-976AA7E17A17

EV-976AA7E17A17: tests/test_storage.py:272-286 (test_s3_cleanup_paginates_and_stays_in_job_prefix) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L272-L286]

## EV-6096337884D4

EV-6096337884D4: tests/test_storage.py:313-316 (test_orphan_zip_reserves_version) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L313-L316]

## EV-C2AC809D0811

EV-C2AC809D0811: tests/test_storage.py:319-327 (test_s3_version_check_uses_only_prefix_scoped_listing) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L319-L327]

## EV-A5C5D301D359

EV-A5C5D301D359: tests/test_storage.py:195-200 (test_partial_upload_is_not_committed_and_retry_skips_it.fail_zip) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L195-L200]

## EV-5BCD6BB97058

EV-5BCD6BB97058: tests/test_storage.py:235-236 (test_s3_failed_review_preserves_committed_version.unavailable) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L235-L236]

## EV-2311B6110D0E

EV-2311B6110D0E: tests/test_storage.py:184-184 (db.commit:184) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L184-L184]

## EV-32739FBB9E38

EV-32739FBB9E38: tests/test_storage.py:212-212 (db.commit:212) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L212-L212]

## EV-4BAC91C350EC

EV-4BAC91C350EC: tests/test_storage.py:260-260 (db.commit:260) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_storage.py#L260-L260]

## EV-28C5861FA77A

EV-28C5861FA77A: tests/test_workflow.py:10-24 (test_acceptance_invalidates_when_evidence_changes) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L10-L24]

## EV-F88CFD1DEC21

EV-F88CFD1DEC21: tests/test_workflow.py:71-85 (test_shared_viewer_cannot_approve) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L71-L85]

## EV-25AA2654774A

EV-25AA2654774A: tests/test_workflow.py:94-107 (test_stale_result_is_rejected) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L94-L107]

## EV-6C9F9D450068

EV-6C9F9D450068: tests/test_workflow.py:110-124 (test_recorded_result_and_document_versions) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L110-L124]

## EV-715B80CB0941

EV-715B80CB0941: tests/test_workflow.py:131-139 (test_migrations_match_models) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L131-L139]

## EV-540245CC25F5

EV-540245CC25F5: tests/test_workflow.py:142-153 (test_expired_job_lease_is_requeued) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L142-L153]

## EV-0CFDF1072481

EV-0CFDF1072481: tests/test_workflow.py:156-168 (test_retention_removes_artifacts_and_records) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L156-L168]

## EV-7B053A0C1650

EV-7B053A0C1650: tests/test_workflow.py:37-37 (db.flush:37) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L37-L37]

## EV-1E70D4A5CB3C

EV-1E70D4A5CB3C: tests/test_workflow.py:50-50 (db.flush:50) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L50-L50]

## EV-0E998BEA48F0

EV-0E998BEA48F0: tests/test_workflow.py:65-65 (db.flush:65) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L65-L65]

## EV-59A80763A514

EV-59A80763A514: tests/test_workflow.py:77-77 (db.commit:77) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L77-L77]

## EV-C1E7C6CDD366

EV-C1E7C6CDD366: tests/test_workflow.py:151-151 (db.commit:151) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L151-L151]

## EV-031F6029B741

EV-031F6029B741: tests/test_workflow.py:164-164 (db.commit:164) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/test_workflow.py#L164-L164]

## EV-2953B3D158C9

EV-2953B3D158C9: tests/integration/test_services.py:18-32 (test_postgres_redis_and_celery_worker) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/integration/test_services.py#L18-L32]

## EV-6DB93AFEEF51

EV-6DB93AFEEF51: tests/integration/test_services.py:47-47 (db.commit:47) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/integration/test_services.py#L47-L47]

## EV-5B56EB5D6C28

EV-5B56EB5D6C28: tests/integration/test_services.py:87-87 (db.commit:87) [https://github.com/nishitsaha52/Folio/blob/009c318fec24cebc3f94a1a6faa0d514c49e97f5/tests/integration/test_services.py#L87-L87]
