# Test Cases and User Acceptance Testing Report

Application: nishitsaha52/Folio
Source snapshot: 009c318fec24 | Document version: 1
Generated: 2026-11-20 | Status: draft for review

## Contents

- [Test plan and current status](#test-plan-and-current-status)
- [Application entry point scenarios](#application-entry-point-scenarios)
- [Account connection scenarios](#account-connection-scenarios)
- [Service health scenarios](#service-health-scenarios)
- [Jobs and generated artifacts scenarios](#jobs-and-generated-artifacts-scenarios)
- [Repository selection scenarios](#repository-selection-scenarios)
- [Coverage requiring design](#coverage-requiring-design)
- [Existing automated tests](#existing-automated-tests)
- [Acceptance gate](#acceptance-gate)

## Test plan and current status

These scenarios describe expected source behavior for review. None was executed by generating this document. Run them in an isolated test deployment and record actual outcomes separately.

| Measure | Count |
| --- | --- |
| Passed | 0 |
| Failed | 0 |
| Blocked | 0 |
| Unexecuted | 32 |
| Capabilities needing test design | 2 |

## View application returns the expected response

| Field | Test specification |
| --- | --- |
| Test ID | TC-85B9CF9C445F |
| Requirement | Application entry point (REQ-59CD34C1D495) |
| Category | positive |
| Preparation | Use an isolated test deployment and a test session. |
| Actions | 1. Send GET /.<br>2. Record the HTTP status and response body. |
| Expected outcome | The response value is {"message": "Build the React frontend: cd frontend && npm ci && npm run build", "api": "/docs"}. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Sign out returns the expected response

| Field | Test specification |
| --- | --- |
| Test ID | TC-EE5F09D3EF28 |
| Requirement | Account connection (REQ-B332AEA39B89) |
| Category | positive |
| Preparation | Use an isolated test deployment and a test session. |
| Actions | 1. Send POST /api/auth/logout.<br>2. Record the HTTP status and response body. |
| Expected outcome | The response value is {"status": "disconnected"}. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Start GitHub sign in when GitHub client ID has not been supplied

| Field | Test specification |
| --- | --- |
| Test ID | TC-F5C468BF2754 |
| Requirement | Account connection (REQ-B332AEA39B89) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session. |
| Actions | 1. Arrange test data so that GitHub client ID has not been supplied.<br>2. Send GET /api/auth/github/start.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 409; error detail: GitHub OAuth is not configured. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Check service health returns the expected response

| Field | Test specification |
| --- | --- |
| Test ID | TC-91B932B34185 |
| Requirement | Service health (REQ-4D1DF68617A4) |
| Category | positive |
| Preparation | Use an isolated test deployment and a test session. |
| Actions | 1. Send GET /api/health.<br>2. Record the HTTP status and response body. |
| Expected outcome | The response value is {"status": "ok", "version": "0.1.0"}. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## View a job when the requested job does not exist

| Field | Test specification |
| --- | --- |
| Test ID | TC-DE8939B83889 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the requested job does not exist.<br>2. Send GET /api/jobs/{job_id}.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Analysis not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## View collaborators when the job owner does not equal the current account

| Field | Test specification |
| --- | --- |
| Test ID | TC-6636BBFA6A48 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the job owner does not equal the current account.<br>2. Send GET /api/jobs/{job_id}/collaborators.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 403; error detail: Only the analysis owner can manage access. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## View collaborators when the requested job does not exist

| Field | Test specification |
| --- | --- |
| Test ID | TC-8BD527175B18 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the requested job does not exist.<br>2. Send GET /api/jobs/{job_id}/collaborators.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Analysis not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Grant collaborator access when the required acknowledgement has not been supplied

| Field | Test specification |
| --- | --- |
| Test ID | TC-39A3ED147DA5 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the required acknowledgement has not been supplied.<br>2. Send POST /api/jobs/{job_id}/collaborators.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 422; error detail: Acknowledge sharing all artifacts and source evidence with this account. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Grant collaborator access when the requested job does not exist

| Field | Test specification |
| --- | --- |
| Test ID | TC-43FAA17538F0 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the requested job does not exist.<br>2. Send POST /api/jobs/{job_id}/collaborators.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Analysis not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Revoke collaborator access when the job owner does not equal the current account

| Field | Test specification |
| --- | --- |
| Test ID | TC-70D9B5873A71 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the job owner does not equal the current account.<br>2. Send DELETE /api/jobs/{job_id}/collaborators/{login}.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 403; error detail: Only the analysis owner can revoke access. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Revoke collaborator access when the requested job does not exist

| Field | Test specification |
| --- | --- |
| Test ID | TC-B2E2B27A5F21 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the requested job does not exist.<br>2. Send DELETE /api/jobs/{job_id}/collaborators/{login}.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Analysis not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## List generated files when version is greater than job version

| Field | Test specification |
| --- | --- |
| Test ID | TC-FF217C7927E3 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that version is greater than job version.<br>2. Send GET /api/jobs/{job_id}/files.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Document version not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## List generated files when the requested job does not exist

| Field | Test specification |
| --- | --- |
| Test ID | TC-A98DDC3C6897 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the requested job does not exist.<br>2. Send GET /api/jobs/{job_id}/files.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Analysis not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## List generated files when job status does not equal completed

| Field | Test specification |
| --- | --- |
| Test ID | TC-B7EBCF25399F |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that job status does not equal completed.<br>2. Send GET /api/jobs/{job_id}/files.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 409; error detail: Analysis is not complete. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Download documents when version is greater than job version

| Field | Test specification |
| --- | --- |
| Test ID | TC-3BAE6E7DF400 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that version is greater than job version.<br>2. Send GET /api/jobs/{job_id}/download.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Document version not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Download documents when the requested job does not exist

| Field | Test specification |
| --- | --- |
| Test ID | TC-A4212D94B76D |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the requested job does not exist.<br>2. Send GET /api/jobs/{job_id}/download.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Analysis not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Download documents when job status does not equal completed

| Field | Test specification |
| --- | --- |
| Test ID | TC-778DFE64D42A |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that job status does not equal completed.<br>2. Send GET /api/jobs/{job_id}/download.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 409; error detail: Analysis is not complete. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Preview a document when the requested job does not exist

| Field | Test specification |
| --- | --- |
| Test ID | TC-B7617DEB7641 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the requested job does not exist.<br>2. Send GET /api/jobs/{job_id}/preview.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Analysis not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Preview a document when job status does not equal completed

| Field | Test specification |
| --- | --- |
| Test ID | TC-3E79B047DC2E |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that job status does not equal completed.<br>2. Send GET /api/jobs/{job_id}/preview.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 409; error detail: Analysis is not complete. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## View the audit history when the requested job does not exist

| Field | Test specification |
| --- | --- |
| Test ID | TC-880662BA6B76 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the requested job does not exist.<br>2. Send GET /api/jobs/{job_id}/audit.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Analysis not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Record a review decision when the supplied baseline identifier does not equal the expected baseline identifier

| Field | Test specification |
| --- | --- |
| Test ID | TC-D31DC9FACE2E |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the supplied baseline identifier does not equal the expected baseline identifier.<br>2. Send POST /api/jobs/{job_id}/reviews.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 409; error detail: Baseline changed. Refresh and review the current version.. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Record a review decision when the requested job does not exist

| Field | Test specification |
| --- | --- |
| Test ID | TC-4B9E97F73F40 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the requested job does not exist.<br>2. Send POST /api/jobs/{job_id}/reviews.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Analysis not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Record a review decision when job status does not equal completed

| Field | Test specification |
| --- | --- |
| Test ID | TC-D331269CDCA8 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that job status does not equal completed.<br>2. Send POST /api/jobs/{job_id}/reviews.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 409; error detail: Analysis is not complete. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Record a test result when execution evidence confirmation has not been supplied

| Field | Test specification |
| --- | --- |
| Test ID | TC-56B6663B0F1C |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that execution evidence confirmation has not been supplied.<br>2. Send POST /api/jobs/{job_id}/results.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 422; error detail: A reviewer must attest that the result evidence was verified. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Record a test result when the supplied baseline identifier does not equal the current baseline identifier

| Field | Test specification |
| --- | --- |
| Test ID | TC-E2EB3461D2B3 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the supplied baseline identifier does not equal the current baseline identifier.<br>2. Send POST /api/jobs/{job_id}/results.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 409; error detail: Baseline changed. Revalidate this test result against the current requirements.. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Record a test result when the requested job does not exist

| Field | Test specification |
| --- | --- |
| Test ID | TC-D64CBA155E83 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the requested job does not exist.<br>2. Send POST /api/jobs/{job_id}/results.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Analysis not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Record a test result when job status does not equal completed

| Field | Test specification |
| --- | --- |
| Test ID | TC-52AAF26708CD |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that job status does not equal completed.<br>2. Send POST /api/jobs/{job_id}/results.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 409; error detail: Analysis is not complete. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Edit a requirement when the supplied baseline identifier does not equal the current baseline identifier

| Field | Test specification |
| --- | --- |
| Test ID | TC-240957A52653 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the supplied baseline identifier does not equal the current baseline identifier.<br>2. Send PATCH /api/jobs/{job_id}/requirements/{requirement_id}.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 409; error detail: Baseline changed. Refresh before editing.. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Edit a requirement when the requested requirement does not exist

| Field | Test specification |
| --- | --- |
| Test ID | TC-4C2AB11CFEC2 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the requested requirement does not exist.<br>2. Send PATCH /api/jobs/{job_id}/requirements/{requirement_id}.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Requirement not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Edit a requirement when the requested job does not exist

| Field | Test specification |
| --- | --- |
| Test ID | TC-1195A01BAE02 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that the requested job does not exist.<br>2. Send PATCH /api/jobs/{job_id}/requirements/{requirement_id}.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 404; error detail: Analysis not found. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Edit a requirement when job status does not equal completed

| Field | Test specification |
| --- | --- |
| Test ID | TC-49A91F6AD396 |
| Requirement | Jobs and generated artifacts (REQ-7424FDCDC17D) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session.<br>Replace path placeholders with identifiers selected for this test. |
| Actions | 1. Arrange test data so that job status does not equal completed.<br>2. Send PATCH /api/jobs/{job_id}/requirements/{requirement_id}.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 409; error detail: Analysis is not complete. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## View repositories when user token has not been supplied

| Field | Test specification |
| --- | --- |
| Test ID | TC-D4CD658AC253 |
| Requirement | Repository selection (REQ-1357A6D706AE) |
| Category | negative |
| Preparation | Use an isolated test deployment and a test session. |
| Actions | 1. Arrange test data so that user token has not been supplied.<br>2. Send GET /api/repositories.<br>3. Record the HTTP status and response body. |
| Expected outcome | HTTP 401; error detail: Connect GitHub to discover accessible repositories. |
| Recorded outcome | Unexecuted. No actual result is recorded. |

## Coverage requiring design

| Capability | Work required |
| --- | --- |
| Demonstration workflow | Specify fixtures, input values and measurable expected outcomes |
| Session settings | Specify fixtures, input values and measurable expected outcomes |

## Existing automated tests

The source scan identified 108 test declarations. Their implementation inventory is in the technical reference. Test-file presence does not establish a passing result.

## Acceptance gate

Acceptance requires current requirements approval, a concrete test design for every capability, reliable recorded passing evidence for every proposed case, and an authorized human decision.

Detailed source citations, implementation candidates and analysis limitations are in the 06-analysis folder. Evidence IDs in this document resolve through Evidence_Register.md.
