# System Architecture

Application: nishitsaha52/Folio
Source snapshot: 009c318fec24 | Document version: 1
Generated: 2026-11-20 | Status: draft for review

## Contents

- [Architecture overview](#architecture-overview)
- [Source components](#source-components)
- [Component map](#component-map)
- [Data structures](#data-structures)
- [Deployment questions](#deployment-questions)

## Architecture overview

Folio is a Python and React application for turning a GitHub repository into a versioned, evidence-linked documentation package. It includes a working local demo, static analysis, optional AI synthesis, document exports and authenticated review workflows.

The component map groups inspected source modules by responsibility. Arrows represent declared code dependencies; they do not establish a live deployment topology.

## Source components

Each row gives the source scope and one representative location. The complete file inventory remains in 06-analysis/Repository_Analysis_Summary.json.

| Component | Source scope |
| --- | --- |
| AI synthesis | 1 source files. Example: backend/docagent/llm.py |
| Application API | 1 source files. Example: backend/docagent/api.py |
| Application configuration | 1 source files. Example: backend/docagent/config.py |
| Artifact storage | 1 source files. Example: backend/docagent/storage.py |
| Background processing | 3 source files. Example: backend/docagent/jobs.py |
| Checks | 1 source files. Example: backend/docagent/checks.py |
| Cli | 1 source files. Example: backend/docagent/cli.py |
| Compose config | 1 source files. Example: backend/docagent/compose_config.py |
| Data persistence | 1 source files. Example: backend/docagent/db.py |
| Database migrations | 7 source files. Example: backend/docagent/migrations/__init__.py |
| Document exports | 2 source files. Example: backend/docagent/diagrams.py |
| Execution | 1 source files. Example: backend/docagent/execution.py |
| GitHub integration | 1 source files. Example: backend/docagent/github.py |
| Init | 1 source files. Example: backend/docagent/__init__.py |
| Logging config | 1 source files. Example: backend/docagent/logging_config.py |
| Repository analysis | 2 source files. Example: backend/docagent/analysis.py |
| Review workflow | 1 source files. Example: backend/docagent/workflow.py |
| Schemas | 1 source files. Example: backend/docagent/schemas.py |
| Security utilities | 1 source files. Example: backend/docagent/security.py |
| Ui smoke | 1 source files. Example: scripts/ui_smoke.py |
| User interface | 41 source files. Example: frontend/index.html |

## Component map

![Source dependency map with implementation helpers grouped by responsibility](Architecture_Diagram.png)

Source dependency map with implementation helpers grouped by responsibility

## Data structures

| Model | Declared fields | Evidence |
| --- | --- | --- |
| JobAdmission | id | EV-12C5F1F1B8AF |
| UserSession | id, owner, login, token, csrf, oauth state, oauth verifier, oauth started, expires | EV-A9B89FBBB448 |
| Job | id, owner, repository, status, progress, message, config, analysis, baseline hash, version, created, updated, credential, worker id, resolved commit, lease until | EV-C78667A2DB1D |
| JobAccess | job id, principal, login, role, created | EV-49260818223C |
| DocumentVersion | job id, version, baseline hash, package sha256, created | EV-992E64D8AFC2 |
| Review | id, job id, baseline hash, stage, decision, reviewer, comment, created | EV-8BD1CD83834F |
| TestResult | id, job id, baseline hash, test case id, status, source, actual, evidence reference, severity, reviewer, created | EV-471EEC5899CD |
| Audit | id, job id, actor, action, detail, created | EV-AD5BBF3312D9 |
| ScanCache | key, payload, updated | EV-56B5E014BE46 |

## Deployment questions

Confirm deployed services, database and object-store endpoints, worker topology, trust boundaries and capacity with the deployment owner. Dependency manifests alone do not prove installed or active infrastructure.

Detailed source citations, implementation candidates and analysis limitations are in the 06-analysis folder. Evidence IDs in this document resolve through Evidence_Register.md.
