# Technology Stack and Dependencies

Application: nishitsaha52/Folio
Source snapshot: 009c318fec24 | Document version: 1
Generated: 2026-11-20 | Status: draft for review

## Contents

- [Technology overview](#technology-overview)
- [Languages](#languages)
- [AI and ML](#ai-and-ml)
- [Backend](#backend)
- [Background processing](#background-processing)
- [CI/CD](#cicd)
- [Containerization](#containerization)
- [Databases](#databases)
- [Frontend](#frontend)
- [Infrastructure](#infrastructure)
- [Libraries](#libraries)
- [Security](#security)
- [Testing](#testing)
- [Verification needed](#verification-needed)

## Technology overview

This inventory lists declared dependencies and their intended purpose. Version ranges are manifest constraints; deployed versions and actual runtime use require verification.

## Languages

| Language | Inspected files |
| --- | --- |
| CSS | 7 |
| Configuration / text | 18 |
| HTML | 1 |
| Python | 48 |
| TypeScript | 44 |

## AI and ML

| Technology | Declared version | Purpose | Evidence |
| --- | --- | --- | --- |
| openai | <3,>=2.0 | OpenAI API client | EV-C9D47E96814A |
| anthropic | <2,>=0.75 | Claude API client | EV-521645C26A5F |
| google-genai | <3,>=1.50 | Gemini API client | EV-ABA9ADDBE78F |

## Backend

| Technology | Declared version | Purpose | Evidence |
| --- | --- | --- | --- |
| fastapi | <1,>=0.115 | HTTP API framework | EV-19F4DF50DEA1 |
| fastapi | >=0.115 | HTTP API framework | EV-18A3F654CFA3 |

## Background processing

| Technology | Declared version | Purpose | Evidence |
| --- | --- | --- | --- |
| celery | <6,>=5.4 | Distributed tasks | EV-1B2F4DDE47C6 |

## CI/CD

| Technology | Declared version | Purpose | Evidence |
| --- | --- | --- | --- |
| GitHub Actions | not specified | Infrastructure configuration | EV-B0C5E999374E |

## Containerization

| Technology | Declared version | Purpose | Evidence |
| --- | --- | --- | --- |
| Docker | not specified | Container image build | EV-9178BCF86255 |
| Docker | not specified | Container image build | EV-B75DCBACB7E8 |

## Databases

| Technology | Declared version | Purpose | Evidence |
| --- | --- | --- | --- |
| sqlalchemy | <3,>=2.0 | SQL persistence toolkit | EV-4EB767FEF33F |
| psycopg | <4,>=3.2 | PostgreSQL driver | EV-5BB5E7FD44ED |
| redis | <9,>=5 | Redis client | EV-04297BF62645 |

## Frontend

| Technology | Declared version | Purpose | Evidence |
| --- | --- | --- | --- |
| react | ^19.0.0 | User interface | EV-3A3E28901B0A |

## Infrastructure

| Technology | Declared version | Purpose | Evidence |
| --- | --- | --- | --- |
| boto3 | <2,>=1.36 | AWS API client | EV-1AAED348A189 |

## Libraries

| Technology | Declared version | Purpose | Evidence |
| --- | --- | --- | --- |
| uvicorn | <1,>=0.30 | Declared dependency; usage requires module inspection | EV-22EE7E3301B2 |
| httpx | <1,>=0.28 | Declared dependency; usage requires module inspection | EV-DFB8375B7A1E |
| pydantic | <3,>=2.10 | Declared dependency; usage requires module inspection | EV-59988F1BCE3B |
| pydantic-settings | <3,>=2.7 | Declared dependency; usage requires module inspection | EV-6E96431C13B6 |
| alembic | <2,>=1.14 | Declared dependency; usage requires module inspection | EV-62D8E5256CC6 |
| python-docx | <2,>=1.1 | Declared dependency; usage requires module inspection | EV-5877419F81BC |
| openpyxl | <4,>=3.1 | Declared dependency; usage requires module inspection | EV-B5612D1A5493 |
| reportlab | <5,>=4.2 | Declared dependency; usage requires module inspection | EV-E6CAD2809C74 |
| defusedxml | <1,>=0.7 | Declared dependency; usage requires module inspection | EV-BAD0F5918860 |
| packaging | >=24 | Declared dependency; usage requires module inspection | EV-2BC5F5B9FE44 |
| fakeredis | <3,>=2.31 | Declared dependency; usage requires module inspection | EV-36B0EDF37190 |
| tree-sitter | <0.26,>=0.25 | Declared dependency; usage requires module inspection | EV-59011F20025A |
| tree-sitter-javascript | <0.26,>=0.25 | Declared dependency; usage requires module inspection | EV-742D8E167553 |
| tree-sitter-typescript | <0.24,>=0.23 | Declared dependency; usage requires module inspection | EV-3A18201329F0 |
| tree-sitter-java | <0.24,>=0.23 | Declared dependency; usage requires module inspection | EV-D916BCB1F194 |
| tree-sitter-go | <0.26,>=0.25 | Declared dependency; usage requires module inspection | EV-2EFB621F6C03 |
| PyYAML | <7,>=6 | Declared dependency; usage requires module inspection | EV-A5250D9FE69F |
| pathspec | <1,>=0.12 | Declared dependency; usage requires module inspection | EV-671E2B3C389C |
| pytest-cov | <8,>=6 | Declared dependency; usage requires module inspection | EV-E6C96C77030A |
| ruff | <1,>=0.11 | Declared dependency; usage requires module inspection | EV-1FE4AE352615 |
| moto | <6,>=5 | Declared dependency; usage requires module inspection | EV-92BD9924A8BB |
| pydantic | >=2.10 | Declared dependency; usage requires module inspection | EV-7DC00B9E8618 |
| lucide-react | ^0.468.0 | Declared dependency; usage requires module inspection | EV-1DC6229F6D93 |
| react-dom | ^19.0.0 | Declared dependency; usage requires module inspection | EV-4B9289E5DBDA |
| react-markdown | ^10.0.0 | Declared dependency; usage requires module inspection | EV-C53CA2AFA97B |
| remark-gfm | ^4.0.0 | Declared dependency; usage requires module inspection | EV-E13CCAD40C43 |
| @testing-library/jest-dom | ^7.0.1 | Declared dependency; usage requires module inspection | EV-FE132CEE8653 |
| @testing-library/react | ^16.3.3 | Declared dependency; usage requires module inspection | EV-DB871E70F0A8 |
| @testing-library/user-event | ^14.6.12 | Declared dependency; usage requires module inspection | EV-B0C00281EF28 |
| @types/react | ^19.0.0 | Declared dependency; usage requires module inspection | EV-A4B544753895 |
| @types/react-dom | ^19.0.0 | Declared dependency; usage requires module inspection | EV-B857FE2FB376 |
| @vitejs/plugin-react | ^4.4.0 | Declared dependency; usage requires module inspection | EV-AC4723660053 |
| jsdom | ^26.1.0 | Declared dependency; usage requires module inspection | EV-3E3F600036B7 |
| prettier | ^3.5.0 | Declared dependency; usage requires module inspection | EV-6BF46E504F0B |
| typescript | ~5.8.0 | Declared dependency; usage requires module inspection | EV-82FCA2D0021F |
| vite | ^6.2.0 | Declared dependency; usage requires module inspection | EV-EDF5329227A1 |

## Security

| Technology | Declared version | Purpose | Evidence |
| --- | --- | --- | --- |
| cryptography | >=44 | Cryptographic primitives | EV-1ADA686320F6 |

## Testing

| Technology | Declared version | Purpose | Evidence |
| --- | --- | --- | --- |
| pytest | <10,>=8 | Python testing | EV-59713D11F0BB |
| pytest | >=8 | Python testing | EV-0B33ACCEA6A8 |
| vitest | ^3.0.0 | JavaScript testing | EV-6758AF8AA44D |

## Verification needed

Confirm installed versions, ownership, security maintenance and actual runtime configuration before relying on this inventory for release decisions.

Detailed source citations, implementation candidates and analysis limitations are in the 06-analysis folder. Evidence IDs in this document resolve through Evidence_Register.md.
