# Software Requirements Specification

Application: nishitsaha52/Folio
Source snapshot: 009c318fec24 | Document version: 1
Generated: 2026-11-20 | Status: draft for review

## Contents

- [Purpose and scope](#purpose-and-scope)
- [Review summary](#review-summary)
- [Application entry point](#application-entry-point)
- [Account connection](#account-connection)
- [Demonstration workflow](#demonstration-workflow)
- [Service health](#service-health)
- [Jobs and generated artifacts](#jobs-and-generated-artifacts)
- [Repository selection](#repository-selection)
- [Session settings](#session-settings)
- [Data handled by the application](#data-handled-by-the-application)
- [Decisions required before approval](#decisions-required-before-approval)

## Purpose and scope

Folio is a Python and React application for turning a GitHub repository into a versioned, evidence-linked documentation package. It includes a working local demo, static analysis, optional AI synthesis, document exports and authenticated review workflows.

This draft groups the observed application interfaces into 7 capabilities. It supports requirements review at commit 009c318fec24; business intent and runtime behavior still need owner confirmation.

## Review summary

| Item | Current position |
| --- | --- |
| Requirements approval | pending |
| Capabilities | 7 |
| Proposed scenarios | 32 |
| Capabilities needing test design | 2 |
| Inspected source files | 118 |

## Application entry point

Requirement REQ-59CD34C1D495. The application provides 1 declared operations for application entry point. The operation catalogue and source-supported rejection rules below define the observed scope.

| Operation | Description | Evidence |
| --- | --- | --- |
| View application | Declared interface: GET / | EV-F141AC0E43FB |

## Account connection

Requirement REQ-B332AEA39B89. The application provides 4 declared operations for account connection. The operation catalogue and source-supported rejection rules below define the observed scope.

| Operation | Description | Evidence |
| --- | --- | --- |
| Connect a GitHub account with a token | Declared interface: POST /api/auth/pat | EV-9D981D475B51 |
| Sign out | Declared interface: POST /api/auth/logout | EV-524A8084553C |
| Start GitHub sign in | Declared interface: GET /api/auth/github/start | EV-9985B4B42280 |
| Complete GitHub sign in | Declared interface: GET /api/auth/github/callback | EV-0F6D0CA3CB32 |

- When GitHub client ID has not been supplied, the request is rejected with HTTP 409: GitHub OAuth is not configured.
- The request can return HTTP 403: OAuth state is invalid or expired.

Some rejection preconditions are incomplete in the inspected snippets. Confirm their fixtures and access context before using them as acceptance tests.

## Demonstration workflow

Requirement REQ-83BD5259D1BC. The application provides 1 declared operations for demonstration workflow. The operation catalogue and source-supported rejection rules below define the observed scope.

| Operation | Description | Evidence |
| --- | --- | --- |
| Start the demonstration | Declared interface: POST /api/demo | EV-81EB1AC9D3D7 |

Test design is required: the available evidence does not establish a concrete acceptance scenario for this capability.

## Service health

Requirement REQ-4D1DF68617A4. The application provides 1 declared operations for service health. The operation catalogue and source-supported rejection rules below define the observed scope.

| Operation | Description | Evidence |
| --- | --- | --- |
| Check service health | Declared interface: GET /api/health | EV-A61F2683D120 |

## Jobs and generated artifacts

Requirement REQ-7424FDCDC17D. The application provides 13 declared operations for jobs and generated artifacts. The operation catalogue and source-supported rejection rules below define the observed scope.

| Operation | Description | Evidence |
| --- | --- | --- |
| Start a job | Declared interface: POST /api/jobs | EV-68E83656D9AD |
| List jobs | Declared interface: GET /api/jobs | EV-F2F3489C415F |
| View a job | Declared interface: GET /api/jobs/{job_id} | EV-02DA59BFE2D0 |
| View collaborators | Declared interface: GET /api/jobs/{job_id}/collaborators | EV-073F25C4C4FE |
| Grant collaborator access | Declared interface: POST /api/jobs/{job_id}/collaborators | EV-0888B6E61750 |
| Revoke collaborator access | Declared interface: DELETE /api/jobs/{job_id}/collaborators/{login} | EV-C658AB9DFEAA |
| List generated files | Declared interface: GET /api/jobs/{job_id}/files | EV-5AC2398A5FEA |
| Download documents | Declared interface: GET /api/jobs/{job_id}/download | EV-22435B0ED175 |
| Preview a document | Declared interface: GET /api/jobs/{job_id}/preview | EV-6ADED5183BF6 |
| View the audit history | Declared interface: GET /api/jobs/{job_id}/audit | EV-46966887DC4B |
| Record a review decision | Declared interface: POST /api/jobs/{job_id}/reviews | EV-4DB69A451714 |
| Record a test result | Declared interface: POST /api/jobs/{job_id}/results | EV-7C38FD977886 |
| Edit a requirement | Declared interface: PATCH /api/jobs/{job_id}/requirements/{requirement_id} | EV-8CB4A0A92FAA |

- When the requested job does not exist, the request is rejected with HTTP 404: Analysis not found.
- When the job owner does not equal the current account, the request is rejected with HTTP 403: Only the analysis owner can manage access.
- The request can return HTTP 403: The authenticated analysis owner must grant access.
- When the required acknowledgement has not been supplied, the request is rejected with HTTP 422: Acknowledge sharing all artifacts and source evidence with this account.
- When the job owner does not equal the current account, the request is rejected with HTTP 403: Only the analysis owner can revoke access.
- The request can return HTTP 404: Committed document version not found.
- When version is greater than job version, the request is rejected with HTTP 404: Document version not found.
- When job status does not equal completed, the request is rejected with HTTP 409: Analysis is not complete.
- The request can return HTTP 404: Markdown preview not found.
- When the supplied baseline identifier does not equal the expected baseline identifier, the request is rejected with HTTP 409: Baseline changed. Refresh and review the current version..
- The request can return HTTP 422: Explicit reviewer acknowledgement is required.
- The request can return HTTP 409: An empty requirements baseline cannot be approved.
- The request can return HTTP 409: Current requirements approval and passing evidence for all cases are required.
- The request can return HTTP 403: An authenticated GitHub account listed in DOCAGENT_REVIEWERS is required.
- When execution evidence confirmation has not been supplied, the request is rejected with HTTP 422: A reviewer must attest that the result evidence was verified.
- When the supplied baseline identifier does not equal the current baseline identifier, the request is rejected with HTTP 409: Baseline changed. Revalidate this test result against the current requirements..
- The request can return HTTP 422: Unknown test case.
- The request can return HTTP 422: A passing case cannot have an unresolved defect severity.
- When the supplied baseline identifier does not equal the current baseline identifier, the request is rejected with HTTP 409: Baseline changed. Refresh before editing..
- When the requested requirement does not exist, the request is rejected with HTTP 404: Requirement not found.

Some rejection preconditions are incomplete in the inspected snippets. Confirm their fixtures and access context before using them as acceptance tests.

## Repository selection

Requirement REQ-1357A6D706AE. The application provides 3 declared operations for repository selection. The operation catalogue and source-supported rejection rules below define the observed scope.

| Operation | Description | Evidence |
| --- | --- | --- |
| View repositories | Declared interface: GET /api/repositories | EV-0A6F8BF3F634 |
| View repositories | Declared interface: GET /api/repositories/{owner}/{name} | EV-F7EB788309AD |
| List repository branches and tags | Declared interface: GET /api/repositories/{owner}/{name}/refs | EV-A508170852F2 |

- When user token has not been supplied, the request is rejected with HTTP 401: Connect GitHub to discover accessible repositories.

## Session settings

Requirement REQ-B2264A09023B. The application provides 1 declared operations for session settings. The operation catalogue and source-supported rejection rules below define the observed scope.

| Operation | Description | Evidence |
| --- | --- | --- |
| View session settings | Declared interface: GET /api/session | EV-FB9C3E876DFB |

Test design is required: the available evidence does not establish a concrete acceptance scenario for this capability.

## Data handled by the application

| Declared model | Fields | Evidence |
| --- | --- | --- |
| JobAdmission | id | EV-12C5F1F1B8AF |
| UserSession | id, owner, login, token, csrf, oauth state, oauth verifier, oauth started, expires | EV-A9B89FBBB448 |
| Job | id, owner, repository, status, progress, message, config, analysis, baseline hash, version, created, updated, credential, worker id, resolved commit, lease until | EV-C78667A2DB1D |
| JobAccess | job id, principal, login, role, created | EV-49260818223C |
| DocumentVersion | job id, version, baseline hash, package sha256, created | EV-992E64D8AFC2 |
| Review | id, job id, baseline hash, stage, decision, reviewer, comment, created | EV-8BD1CD83834F |
| TestResult | id, job id, baseline hash, test case id, status, source, actual, evidence reference, severity, reviewer, created | EV-471EEC5899CD |
| Audit | id, job id, actor, action, detail, created | EV-AD5BBF3312D9 |
| ScanCache | key, payload, updated | EV-56B5E014BE46 |

## Decisions required before approval

- Confirm the application owner, intended users and access privileges.
- Review inferred behavior against the pinned source and agree on measurable acceptance criteria.
- Complete missing test design and confirm supported environments.
- Set performance, availability, accessibility and recovery targets; source declarations do not establish achieved service levels.

Detailed source citations, implementation candidates and analysis limitations are in the 06-analysis folder. Evidence IDs in this document resolve through Evidence_Register.md.
